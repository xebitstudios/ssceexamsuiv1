package main

import (
	"testing"
)

func TestSplitMessageInt(t *testing.T) {
	t.Run("[1,2,3,4,5,6]", testSplitMessageIntFunc("1,2,3,4,5,6", 0))
	t.Run("[10,20,30,40,50,60]", testSplitMessageIntFunc("10,20,30,40,50,60", 0))
}

func testSplitMessageIntFunc(intline string, expected int) func(*testing.T) {
	return func(t *testing.T) {
		actual := splitMessage(intline)
		if actual != expected {
			t.Errorf("Expected the sum of %s to be %d but instead got %d!", intline, expected, actual)
		}
	}
}

func TestSplitMessageIntSingle(t *testing.T) {
	intline := "12,22,23,24,25,26"
	expected := 0
	actual := splitMessage(intline)

	if actual != expected {
		t.Errorf("Expected the sum of %s to be %d but instead got %d!", intline, expected, actual)
	}
}

func TestSplitMessageString(t *testing.T) {
	strline := "car,plane,table,fence,bungalow"
	expected := 1
	actual := splitMessage(strline)

	if actual != expected {
		t.Errorf("Expected the sum of %s to be %d but instead got %d!", strline, expected, actual)
	}
}

func TestAddNumbers(t *testing.T) {
	intmsgs := []string{"1", "2", "3", "4", "5", "6"}
	expected := 21
	actual := addNumbers(intmsgs)

	if actual != expected {
		t.Errorf("Expected the sum of %s to be %d but instead got %d!", intmsgs, expected, actual)
	}
}

func TestSortWords(t *testing.T) {
	strngs := "car,plane,table,fence,bungalow"
	expected := "bungalow,car,fence,plane,table"
	actual := sortWords(strngs)

	if actual != expected {
		t.Errorf("Expected the sum of %s to be %s but instead got %s!", strngs, expected, actual)
	}
}

func TestDisplaySumValueToConsole(t *testing.T) {
	number := 123
	expected := 123
	actual := displaySumValueToConsole(number)

	if actual != expected {
		t.Errorf("Expected the sum of %d to be %d but instead got %d!", number, expected, actual)
	}
}

func TestDisplaySortedValueToConsole(t *testing.T) {
	strng := "car,plane,table,fence,bungalow"
	expected := "car,plane,table,fence,bungalow"
	actual := displaySortedValueToConsole(strng)

	if actual != expected {
		t.Errorf("Expected the sum of %s to be %s but instead got %s!", strng, expected, actual)
	}
}
