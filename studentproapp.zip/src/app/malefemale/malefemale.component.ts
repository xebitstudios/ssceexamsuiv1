import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-malefemale',
  templateUrl: './malefemale.component.html',
  styleUrls: ['./malefemale.component.css']
})
export class MalefemaleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
