import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute, Router, Params} from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  @Input() tab: string;
  tabArray: any[] = [];
  studentid: number;
  classid: number;

  constructor(private router: Router,
              private route: ActivatedRoute) {
    // this.route.params.subscribe( params => console.log(params) );
  }

  ngOnInit() {
    console.log('tab is: ' + this.tab);
    this.tabArray = ['','','','','','','',''];
    this.tabArray[parseInt(this.tab) - 1] = 'active';    
  }

  logout(): void {
    this.router.navigate(['/login']);
  }

  schoollab(): void {
    this.router.navigate(['/mainboard']);
  }
  board(): void {
    this.router.navigate(['/landing']);
  }
  newstudent(): void {
    this.router.navigate(['/new']);
  }
  profile(studentid): void {
    this.studentid = studentid;
    this.router.navigate(['students/']);//' + this.studentid]);
  }
  classs(classid): void {
    // this.classid = classid;
    this.router.navigate(['/class/']);// + this.classid]);
  }
  tests(studentid): void {
    this.studentid = studentid;
    this.router.navigate(['/scores/' + this.studentid]);
  }
  activity(): void {
    this.router.navigate(['activity']);
  }
  support(): void {
    this.router.navigate(['support']);
  }

}
