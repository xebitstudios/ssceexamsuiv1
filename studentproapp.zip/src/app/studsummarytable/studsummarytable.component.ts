import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-studsummarytable',
  templateUrl: './studsummarytable.component.html',
  styleUrls: ['./studsummarytable.component.css']
})
export class StudsummarytableComponent implements OnInit {
  studsummary:any[] = [];
  @Input() title: string
  @Input() male: number
  @Input() female: number

  constructor() { }

  ngOnInit() {
    this.studsummary = [
      {
        'totnum': this.male + this.female,
        'fnum': this.male,
        'mnum': this.female
      }
    ];
  }

  getTotal() {
    return this.male + this.female
  }

}
