import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-sprofiledetail',
  templateUrl: './sprofiledetail.component.html',
  styleUrls: ['./sprofiledetail.component.css']
})
export class SprofiledetailComponent implements OnInit {
  fmenabled: boolean = true
  @Input() dstudent: any = []

  constructor() { }

  ngOnInit() {
    console.log('dstudent...', this.dstudent)
  }

  editstudentprofile(): void {
    console.log('editstudentprofile called...');
    this.fmenabled = false;
  }

  savestudentprofile(): void {
    console.log('savestudentprofile called...');
    // make PUT call for edited student data to the API
    this.fmenabled = true;
  }

}
