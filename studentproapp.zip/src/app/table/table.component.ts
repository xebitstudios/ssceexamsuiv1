import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { DataService } from '../services/data.service';
import * as _ from 'underscore';

@Component({
  selector: 'app-table',
  providers: [DataService],
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent implements OnInit {

  @Input() hdrs: any[]
  @Input() bdy: any[]
  @Input() btnTxt: string
  @Input() displayTxt: string

  @Output() optionClicked: EventEmitter<number> = new EventEmitter<number>()

  pagecount = 20
  pages = 0
  pagelist: any[] = []
  tbllength: number
  tblbody: any[]
  objKeys: number[]

  constructor(private service: DataService) { }

  ngOnInit() {
    // currentToken: string = localStorage.getItem('currentToken');
    this.pages = Math.floor(this.bdy.length / this.pagecount) + 1;
    for(let e=0;e < this.pages;e++) {
      if(e === 0) {
        this.pagelist.push({issel: 'active', val: e + 1});
      } else {
        this.pagelist.push({issel: '', val: e + 1});
      }
    }
    this.tblbody = _.first(this.bdy, this.pagecount);
  }

  getVal(dobj) {
    return Object.keys(dobj)
  }

  showProfile(indx): void {
    console.debug('dObject with index:' + indx + ' clicked!');
    this.optionClicked.emit(indx) // indx will be emitted to the parent
  }

  tabbed(vl): void {
    this.tblbody = [];
    for(let e =(vl * this.pagecount);e < ((vl + 1) * this.pagecount); e++) {
      if (e > this.bdy.length - 1) {

      } else {
        this.tblbody.push(this.bdy[e]);
      }
    }
    this.tbllength = this.tblbody.length
    for (let f = 0; f < this.pages; f++) {
      if (f === vl) {
        this.pagelist[f].issel = 'active';
      } else {
        this.pagelist[f].issel = '';
      }
    }
  }

}
