import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-linkcards',
  templateUrl: './linkcards.component.html',
  styleUrls: ['./linkcards.component.css']
})
export class LinkcardsComponent implements OnInit {

  @Input() classlist: string[]

  constructor() { }

  ngOnInit() {
  }

  linkCardClicked(clas) {
    console.log('linkCardClicked clicked!!!... ' + clas)
  }

}
