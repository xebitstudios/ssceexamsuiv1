import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LinkcardsComponent } from './linkcards.component';

describe('LinkcardsComponent', () => {
  let component: LinkcardsComponent;
  let fixture: ComponentFixture<LinkcardsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LinkcardsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LinkcardsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
