import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tablelistrow',
  templateUrl: './tablelistrow.component.html',
  styleUrls: ['./tablelistrow.component.css']
})
export class TablelistrowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
