import { Component, OnInit, Input } from '@angular/core';
import { DialogComponent, DialogService } from "ng2-bootstrap-modal";
import { DataService } from '../services/data.service';

export interface StudentDetailModel {
  title:string;
  message:string;
  student: StudentModel;
}
export class StudentModel {
  firstname: string;
  middlename: string;
  lastname: string;
  gender: string;
  status: string;
  entryclass: string;
  presentclass: string;
  dob: string;
  regdate: string;
  homeaddress: string;
  parents: string;
  state: string;
}

@Component({
  selector: 'app-studentdetail',
  providers: [DataService],
  templateUrl: './studentdetail.component.html',
  styleUrls: ['./studentdetail.component.css']
})
export class StudentdetailComponent extends DialogComponent<StudentDetailModel, boolean> implements OnInit, StudentDetailModel {
  @Input() student: StudentModel
  title:string;
  message:string;
  // private currentToken: string = localStorage.getItem('currentToken');

  constructor(dialogService: DialogService, private service: DataService) {
    super(dialogService);
  }

  ngOnInit() {
    // this.getStudentDetailById(this.studentid);
    this.title = this.student.firstname + ' ' + this.student.middlename + '. ' + this.student.lastname
    console.log('student...', this.student)
  }

  confirm() {
    this.result = true;
    this.close();
  }

  cancel() {
    this.close();
  }

  private getStudentDetailById(student: StudentModel) {
    return {
      'firstname': 'Perpetua',
      'middlename': 'C',
      'lastname': 'Ajulufo',
      'gender': 'F',
      'status': 'Active',
      'entryclass': 'JSS 1',
      'presentclass': 'SSS 3',
      'dob': '07/08/2001',
      'regdate': '03/04/2013',
      'homeaddress': '11 Idanre street, Ondo West',
      'parents': 'Mr and Mrs Ajulufo',
      'state': 'Ondo'
    }
  }

}
