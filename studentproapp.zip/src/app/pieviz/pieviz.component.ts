import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-pieviz',
  templateUrl: './pieviz.component.html',
  styleUrls: ['./pieviz.component.css']
})
export class PievizComponent implements OnInit {

  @Input() title: string
  @Input() male: number
  @Input() female: number
  
  constructor() { }

  ngOnInit() { }

  getPct(val) {
    if(val === 0) return 0
    return Math.round((val/(this.male + this.female)) * 100)
  }

}
