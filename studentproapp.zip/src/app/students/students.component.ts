import { Component, OnInit, Input, EventEmitter } from '@angular/core';
import { StudentdetailComponent } from '../studentdetail/studentdetail.component';
import { DialogService } from "ng2-bootstrap-modal";
import * as _ from 'underscore';

@Component({
  selector: 'app-students',
  templateUrl: './students.component.html',
  styleUrls: ['./students.component.css']
})
export class StudentsComponent implements OnInit {
  summaryTitle: string = 'Overall Students Summary'
  pieTitle: string = 'Male/Female Head Count'
  student: any = [
    {
      //'ischeck': false,
      'firstname': 'Daniel',
      'middlename': 'O',
      'lastname': 'David',
      'gender': 'M',
      'status': 'Active',
      'entryclass': 'JSS 1',
      'presentclass': 'SSS 3',
      'dob': '07/03/2003',
      'regdate': '23/04/2013',
      'homeaddress': '4 Adetoro Famuyi street, Sokoto',
      'parents': 'Mr and Mrs David',
      'state': 'Sokoto'
    }
  ]
  pieMale: number
  pieFemale: number
  studentid: number
  tblheadrs: string[] = [
    'First Name',
    'Middle Name',
    'Last Name',
    'Gender',
    'Status',
    'Entry Class',
    'Present Class',
    'D.O.B',
    'Reg. Date',
    'Address',
    'Parents',
    'State',
    ''
  ]
  classList: string[]
  students: any[] = [
    {
      //'ischeck': false,
      'firstname': 'Ayobami',
      'middlename': 'O',
      'lastname': 'Omotosho',
      'gender': 'M',
      'status': 'Active',
      'entryclass': 'JSS 1',
      'presentclass': 'SSS 3',
      'dob': '07/07/2002',
      'regdate': '13/04/2013',
      'homeaddress': '59 Market road, Warri South',
      'parents': 'Mr and Mrs Omotosho',
      'state': 'Delta'
    },
    {
      //'ischeck': false,
      'firstname': 'Perpetua',
      'middlename': 'C',
      'lastname': 'Ajulufo',
      'gender': 'F',
      'status': 'Active',
      'entryclass': 'JSS 1',
      'presentclass': 'SSS 3',
      'dob': '07/08/2001',
      'regdate': '03/04/2013',
      'homeaddress': '11 Idanre street, Ondo West',
      'parents': 'Mr and Mrs Ajulufo',
      'state': 'Ondo'
    },
    {
      //'ischeck': false,
      'firstname': 'Tania',
      'middlename': 'A',
      'lastname': 'Mark',
      'gender': 'M',
      'status': 'Active',
      'entryclass': 'JSS 1',
      'presentclass': 'SSS 3',
      'dob': '07/03/1999',
      'regdate': '23/06/2013',
      'homeaddress': '4A Makola Roundabout, Ibadan Central',
      'parents': 'Mr and Mrs Mark',
      'state': 'Oyo'
    },
    {
      //'ischeck': false,
      'firstname': 'Olayemi',
      'middlename': 'I',
      'lastname': 'Ayotunde',
      'gender': 'M',
      'status': 'Active',
      'entryclass': 'JSS 1',
      'presentclass': 'SSS 3',
      'dob': '01/03/2002',
      'regdate': '23/10/2013',
      'homeaddress': '131 Sultan Abubaka Road, Sokoto',
      'parents': 'Mr and Mrs Ayotunde',
      'state': 'Sokoto'
    },
    {
      //'ischeck': false,
      'firstname': 'Felix',
      'middlename': 'M',
      'lastname': 'Onifade',
      'gender': 'M',
      'status': 'Active',
      'entryclass': 'JSS 1',
      'presentclass': 'SSS 3',
      'dob': '17/03/2003',
      'regdate': '23/03/2013',
      'homeaddress': '279 Burnu Way, Yaba',
      'parents': 'Mr and Mrs Onifade',
      'state': 'Lagos'
    }
  ]
  btnText: string = 'View Student Profile'
  displayText: string = 'Students'
  constructor(private dialogService:DialogService) { }

  ngOnInit() {
    this.getStats()
  }

  getStats() {
    this.pieMale = (this.students.filter(e => e.gender === 'M')).length
    this.pieFemale = (this.students.filter(e => e.gender === 'F')).length
    this.classList = _.uniq(this.students.map(function(obj) { return obj.presentclass }))
    console.log('classList...', this.classList)
  }

  clickValue($event): void {
      console.log('dObject value with index:' + $event + ' clicked!');
      const disposable = this.dialogService.addDialog(StudentdetailComponent, {
                      student: this.students[$event],
                      title:'Student Detail',
                      message:'Confirm message'})
        .subscribe((isConfirmed) => {
            if(isConfirmed) {
              console.debug('OK button clicked!');
            } else {
              console.debug('Close button clicked!');
            }
        });
    }

}
