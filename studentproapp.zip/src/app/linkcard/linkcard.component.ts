import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-linkcard',
  templateUrl: './linkcard.component.html',
  styleUrls: ['./linkcard.component.css']
})
export class LinkcardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
