package main

import (
	"fmt"
	"sort"
	"strconv"
	"strings"

	"github.com/confluentinc/confluent-kafka-go/kafka"
)

func main() {
	receiveMessageFromKafka()
}

func receiveMessageFromKafka() {
	fmt.Println("Start receiving from Kafka")
	c, err := kafka.NewConsumer(&kafka.ConfigMap{
		"bootstrap.servers": "localhost:9092",
		"group.id":          "group-id-1",
		"auto.offset.reset": "earliest",
		// "debug":             "broker",
	})

	if err != nil {
		panic(err)
	}

	c.SubscribeTopics([]string{"testTopics"}, nil)

	for {
		msg, err := c.ReadMessage(-1)
		if err == nil {
			fmt.Printf("Received %s: %s\n", msg.TopicPartition, string(msg.Value))
			message := string(msg.Value)
			go splitMessage(message)
		} else {
			fmt.Printf("Consumer error: %v (%v)\n", err, msg)
			// break
		}
	}
	// defer c.Close()
}

func splitMessage(msgStr string) {
	fmt.Println("msgStrmsgStr: ", msgStr)
	messg := strings.Split(msgStr, ",")
	if _, err := strconv.Atoi(messg[0]); err == nil {
		addNumbers(messg)
	} else {
		sortWords(msgStr)
	}
}

func addNumbers(msgStr []string) {
	suum := 0
	for _, num := range msgStr {
		i, err := strconv.Atoi(num)
		if err != nil {
			fmt.Printf("number conversion error: %v (%v)\n", err, num)
		} else {
			suum += i
		}
	}
	displaySumValueToConsole(suum)
}

func sortWords(msgStr string) {
	strs := strings.Split(msgStr, ",")
	sort.Strings(strs)
	displaySortedValueToConsole(strings.Join(strs, ","))
}

func displaySumValueToConsole(lineSum int) {
	fmt.Printf("Topic sum: %d\n", lineSum)
}

func displaySortedValueToConsole(messageString string) {
	fmt.Printf("Topic sorted: %s\n", messageString)
}
