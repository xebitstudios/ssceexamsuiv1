'use strict';

const uuid = require('uuid');
const AWS = require('aws-sdk');
const dynamoDb = new AWS.DynamoDB.DocumentClient({ apiVersion: '2012-08-10' });

module.exports.create = (event, context, callback) => {
    const timestamp = new Date().getTime();
    const data = JSON.parse(event.body);
    console.log('create nworkshop data', data);

    if (typeof data.name === '') {
        console.error('workshop name Validation Failed');
        callback(new Error('Couldn\'t create the nworkshop item.'));
        return;
    }

    const params = {
        TableName: 'the-workshop-app-staging',
        Item: {
            id: uuid.v1(),
            idx: data.idx,
            featuredImage: data.featuredImage,
            title: data.title,
            body: data.body,
            saved: data.saved,
            streamUrl: data.streamUrl,
            details: data.details,
            topics: data.topics,
            questions: data.questions,
            attendees: data.attendees,
            polls: data.polls,
            createdAt: timestamp,
            updatedAt: timestamp
        }
    }

    dynamoDb.put(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t create the nworkshop item.'));
            return;
        }

        console.log('new nworkshop detail is: ', result);

        const response = {
            statusCode: 200,
            headers: { "Access-Control-Allow-Origin": "http://localhost:8100" },
            body: JSON.stringify(result.Item)
        }
        callback(null, response);
    })
}

module.exports.update = (event, context, callback) => {
    const timestamp = new Date().getTime();
    const data = JSON.parse(event.body);
    console.log('updated nworkshop data', data);

    if (typeof data.name === '') {
        console.error('name Validation Failed');
        callback(new Error('Couldn\'t update the nworkshop item.'));
        return;
    }

    const params = {
        TableName: 'the-workshop-app-staging',
        Item: {
            id: event.pathParameters.id,
            idx: data.idx,
            featuredImage: data.featuredImage,
            title: data.title,
            body: data.body,
            saved: data.saved,
            streamUrl: data.streamUrl,
            details: data.details,
            topics: data.topics,
            questions: data.questions,
            attendees: data.attendees,
            polls: data.polls,
            updatedAt: timestamp
        }
    }

    dynamoDb.put(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t update the nworkshop item.'));
            return;
        }

        console.log('updated nworkshop detail is now: ', result);

        const response = {
            statusCode: 200,
            headers: { "Access-Control-Allow-Origin": "http://localhost:8100" },
            body: JSON.stringify(result.Item)
        }
        callback(null, response);
    })
}

module.exports.list = (event, context, callback) => {
    const params = {
        TableName: 'the-workshop-app-staging'
    }

    dynamoDb.scan(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t fetch the nworkshops.'));
            return;
        }

        console.log('nworkshop list is: ', result);

        const response = {
            statusCode: 200,
            headers: { "Access-Control-Allow-Origin": "http://localhost:8100" },
            body: JSON.stringify(result.Items.filter(e => {
                if (e.idx === "none") return e;
            }))
        }
        callback(null, response);
    })
}

module.exports.get = (event, context, callback) => {
    const params = {
        TableName: 'the-workshop-app-staging',
        Key: {
            id: event.pathParameters.id
        }
    }

    dynamoDb.get(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t fetch the specific nworkshop.'));
            return;
        }

        console.log('nworkshop detail is: ', result);

        const response = {
            statusCode: 200,
            headers: { "Access-Control-Allow-Origin": "http://localhost:8100" },
            body: JSON.stringify(result.Item)
        }
        callback(null, response);
    })
}

module.exports.delete = (event, context, callback) => {
    const params = {
        TableName: 'the-workshop-app-staging',
        Key: {
            id: event.pathParameters.id
        }
    }

    dynamoDb.delete(params, (error) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t delete the specific nworkshop.'));
            return;
        }

        console.log('nworkshop detail deleted successfully');

        const response = {
            statusCode: 200,
            headers: { "Access-Control-Allow-Origin": "http://localhost:8100" },
            body: JSON.stringify({})
        }
        callback(null, response);
    })
}

module.exports.createpoll = (event, context, callback) => {
    const timestamp = new Date().getTime();
    console.log('event is: ', event.body);
    const data = JSON.parse(event.body);
    console.log('create nworkshop data', data);

    const params = {
        TableName: 'the-workshop-app-staging',
        Item: {
            id: uuid.v1(),
            idx: 'polls-' + data.idx,
            title: data.title,
            instructions: data.instructions,
            eventid: data.eventid,
            selections: data.selections,
            updatedAt: timestamp,
            stoptime: data.stoptime,
            createdAt: timestamp,
            answer: data.answer,
            answerees: data.answerees,
            type: data.type
        }
    }

    dynamoDb.put(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t create the nworkshop polls item.'));
            return;
        }

        console.log('new nworkshop polls detail is: ', result);

        const response = {
            statusCode: 200,
            headers: { "Access-Control-Allow-Origin": "http://localhost:8100" },
            body: JSON.stringify(result.Item)
        }
        callback(null, response);
    })
}

module.exports.getpoll = (event, context, callback) => {
    const params = {
        TableName: 'the-workshop-app-staging'
    }

    dynamoDb.scan(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t fetch the nworkshops.'));
            return;
        }

        console.log('nworkshop list is: ', result);

        const response = {
            statusCode: 200,
            headers: { "Access-Control-Allow-Origin": "http://localhost:8100" },
            body: JSON.stringify(result.Items.filter(e => {
                if (e.idx === event.pathParameters.idx) return e;
            }))
        }
        callback(null, response);
    })
}

module.exports.updatepoll = (event, context, callback) => {
    const timestamp = new Date().getTime();
    const data = JSON.parse(event.body);
    console.log('updated poll nworkshop data', data);

    if (typeof data.name === '') {
        console.error('poll name Validation Failed');
        callback(new Error('Couldn\'t update the nworkshop item.'));
        return;
    }

    const params = {
        TableName: 'the-workshop-app-staging',
        ExpressionAttributeValues: {
            ":idx": event.pathParameters.idx,
        },
        ConditionExpression: "idx = :idx",
        Item: {
            id: event.pathParameters.id,
            idx: event.pathParameters.idx,
            title: data.title,
            instructions: data.instructions,
            eventid: data.eventid,
            selections: data.selections,
            updatedAt: timestamp,
            stoptime: data.stoptime,
            answer: data.answer,
            answerees: data.answerees,
            type: data.type
        }
    }

    dynamoDb.put(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t update the nworkshop item.'));
            return;
        }

        console.log('updated nworkshop detail is now: ', result);

        const response = {
            statusCode: 200,
            headers: { "Access-Control-Allow-Origin": "http://localhost:8100" },
            body: JSON.stringify(result.Item)
        }
        callback(null, response);
    })
}

module.exports.createquestion = (event, context, callback) => {
    const timestamp = new Date().getTime();
    console.log('event is: ', event.body);
    const data = JSON.parse(event.body);
    console.log('create nworkshop question data', data);

    const params = {
        TableName: 'the-workshop-app-staging',
        Item: {
            id: uuid.v1(),
            idx: 'question-' + data.idx,
            userName: data.userName,
            userId: data.userId,
            questionTitle: data.questionTitle,
            topicTitle: data.topicTitle,
            topicId: data.topicId,
            answers: data.answers,
            createdAt: timestamp,
            updatedAt: timestamp
        }
    }

    dynamoDb.put(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t create the nworkshop question item.'));
            return;
        }

        console.log('new nworkshop question detail is: ', result);

        const response = {
            statusCode: 200,
            headers: { "Access-Control-Allow-Origin": "http://localhost:8100" },
            body: JSON.stringify(result.Item)
        }
        callback(null, response);
    })
}

module.exports.getquestion = (event, context, callback) => {
    const params = {
        TableName: 'the-workshop-app-staging'
    }

    dynamoDb.scan(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t fetch the nworkshops.'));
            return;
        }

        console.log('nworkshop list is: ', result);

        const response = {
            statusCode: 200,
            headers: { "Access-Control-Allow-Origin": "http://localhost:8100" },
            body: JSON.stringify(result.Items.filter(e => {
                if (e.idx === event.pathParameters.idx) return e;
            }))
        }
        callback(null, response);
    })
}

module.exports.updatequestion = (event, context, callback) => {
    const timestamp = new Date().getTime();
    const data = JSON.parse(event.body);
    console.log('updated question nworkshop data', data);

    if (typeof data.questionTitle === '') {
        console.error('question Validation Failed');
        callback(new Error('Couldn\'t update the nworkshop question item.'));
        return;
    }

    const params = {
        TableName: 'the-workshop-app-staging',
        ExpressionAttributeValues: {
            ":idx": event.pathParameters.idx,
        },
        ConditionExpression: "idx = :idx",
        Item: {
            id: event.pathParameters.id,
            idx: event.pathParameters.idx,
            userName: data.userName,
            userId: data.userId,
            questionTitle: data.questionTitle,
            topicTitle: data.topicTitle,
            topicId: data.topicId,
            answers: data.answers,
            updatedAt: timestamp
        }
    }

    dynamoDb.put(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t update the nworkshop question item.'));
            return;
        }

        console.log('updated nworkshop question detail is now: ', result);

        const response = {
            statusCode: 200,
            headers: { "Access-Control-Allow-Origin": "http://localhost:8100" },
            body: JSON.stringify(result.Item)
        }
        callback(null, response);
    })
}

module.exports.createtopic = (event, context, callback) => {
    const timestamp = new Date().getTime();
    console.log('topic is: ', event.body);
    const data = JSON.parse(event.body);
    console.log('create nworkshop topic data', data);

    const params = {
        TableName: 'the-workshop-app-staging',
        Item: {
            id: uuid.v1(),
            idx: 'topic-' + data.idx,
            eventid: data.eventid,
            title: data.title,
            speakerName: data.speakerName,
            description: data.description,
            saved: data.saved,
            socialDetails: data.socialDetails,
            speakerDetails: data.speakerDetails,
            sessions: data.sessions,
            requirements: data.requirements,
            createdAt: timestamp,
            updatedAt: timestamp
        }
    }

    dynamoDb.put(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t create the nworkshop topic item.'));
            return;
        }

        console.log('new nworkshop topic detail is: ', result);

        const response = {
            statusCode: 200,
            headers: { "Access-Control-Allow-Origin": "http://localhost:8100" },
            body: JSON.stringify(result.Item)
        }
        callback(null, response);
    })
}

module.exports.gettopic = (event, context, callback) => {
    const params = {
        TableName: 'the-workshop-app-staging'
    }

    dynamoDb.scan(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t fetch the nworkshops events.'));
            return;
        }

        console.log('nworkshop list is: ', result);

        const response = {
            statusCode: 200,
            headers: { "Access-Control-Allow-Origin": "http://localhost:8100" },
            body: JSON.stringify(result.Items.filter(e => {
                if (e.idx === event.pathParameters.idx) return e;
            }))
        }
        callback(null, response);
    })
}

module.exports.updatetopic = (event, context, callback) => {
    const timestamp = new Date().getTime();
    const data = JSON.parse(event.body);
    console.log('updated topic nworkshop data', data);

    // if (typeof data.question === '') {
    //     console.error('topic Validation Failed');
    //     callback(new Error('Couldn\'t update the nworkshop topic item.'));
    //     return;
    // }

    const params = {
        TableName: 'the-workshop-app-staging',
        ExpressionAttributeValues: {
            ":idx": event.pathParameters.idx,
        },
        ConditionExpression: "idx = :idx",
        Item: {
            id: event.pathParameters.id,
            idx: event.pathParameters.idx,
            title: data.title,
            speakerName: data.speakerName,
            description: data.description,
            saved: data.saved,
            socialDetails: data.socialDetails,
            speakerDetails: data.speakerDetails,
            sessions: data.sessions,
            requirements: data.requirements,
            updatedAt: timestamp
        }
    }

    dynamoDb.put(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t update the nworkshop event item.'));
            return;
        }

        console.log('updated nworkshop event detail is now: ', result);

        const response = {
            statusCode: 200,
            headers: { "Access-Control-Allow-Origin": "http://localhost:8100" },
            body: JSON.stringify(result.Item)
        }
        callback(null, response);
    })
}

module.exports.createenrolee = (event, context, callback) => {
    const timestamp = new Date().getTime();
    console.log('event is: ', event.body);
    const data = JSON.parse(event.body);
    console.log('create nworkshop enrolee data', data);

    const params = {
        TableName: 'the-workshop-app-staging',
        Item: {
            id: uuid.v1(),
            idx: 'enrolee-' + data.idx,
            userName: data.userName,
            userImage: data.userImage,
            userTitle: data.userTitle,
            createdAt: timestamp,
            updatedAt: timestamp
        }
    }

    dynamoDb.put(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t create the nworkshop enrolee item.'));
            return;
        }

        console.log('new nworkshop enrolee detail is: ', result);

        const response = {
            statusCode: 200,
            headers: { "Access-Control-Allow-Origin": "http://localhost:8100" },
            body: JSON.stringify(result.Item)
        }
        callback(null, response);
    })
}

module.exports.getenrolee = (event, context, callback) => {
    const params = {
        TableName: 'the-workshop-app-staging'
    }

    dynamoDb.scan(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t fetch the nworkshops enrolees.'));
            return;
        }

        console.log('nworkshop enrolees list is: ', result);

        const response = {
            statusCode: 200,
            headers: { "Access-Control-Allow-Origin": "http://localhost:8100" },
            body: JSON.stringify(result.Items.filter(e => {
                if (e.idx === event.pathParameters.idx) return e;
            }))
        }
        callback(null, response);
    })
}

module.exports.updateenrolee = (event, context, callback) => {
    const timestamp = new Date().getTime();
    const data = JSON.parse(event.body);
    console.log('updated enrolee nworkshop data', data);

    const params = {
        TableName: 'the-workshop-app-staging',
        ExpressionAttributeValues: {
            ":idx": event.pathParameters.idx,
        },
        ConditionExpression: "idx = :idx",
        Item: {
            id: event.pathParameters.id,
            idx: event.pathParameters.idx,
            userImage: data.userImage,
            userName: data.userName,
            userTitle: data.userTitle,
            updatedAt: timestamp
        }
    }

    dynamoDb.put(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t update the nworkshop enrolee item.'));
            return;
        }

        console.log('updated nworkshop enrolee detail is now: ', result);

        const response = {
            statusCode: 200,
            headers: { "Access-Control-Allow-Origin": "http://localhost:8100" },
            body: JSON.stringify(result.Item)
        }
        callback(null, response);
    })
}

module.exports.createalert = (event, context, callback) => {
    const timestamp = new Date().getTime();
    console.log('event is: ', event.body);
    const data = JSON.parse(event.body);
    console.log('create nworkshop alert data', data);

    const params = {
        TableName: 'the-workshop-app-staging',
        Item: {
            id: uuid.v1(),
            idx: 'alert-' + data.idx,
            name: data.name,
            message: data.message,
            type: data.type,
            eventId: data.eventId,
            sendTime: data.sendTime,
            status: data.status,
            alertType: data.alertType,
            createdAt: timestamp,
            updatedAt: timestamp
        }
    }

    dynamoDb.put(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t create the nworkshop alert item.'));
            return;
        }

        console.log('new nworkshop alert detail is: ', result);

        const response = {
            statusCode: 200,
            headers: { "Access-Control-Allow-Origin": "http://localhost:8100" },
            body: JSON.stringify(result.Item)
        }
        callback(null, response);
    })
}

module.exports.getalert = (event, context, callback) => {
    const params = {
        TableName: 'the-workshop-app-staging'
    }

    dynamoDb.scan(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t fetch the nworkshops alerts.'));
            return;
        }

        console.log('nworkshop alerts list is: ', result);

        const response = {
            statusCode: 200,
            headers: { "Access-Control-Allow-Origin": "http://localhost:8100" },
            body: JSON.stringify(result.Items.filter(e => {
                if (e.idx === event.pathParameters.idx) return e;
            }))
        }
        callback(null, response);
    })
}

module.exports.updatealert = (event, context, callback) => {
    const timestamp = new Date().getTime();
    const data = JSON.parse(event.body);
    console.log('updated alert nworkshop data', data);

    const params = {
        TableName: 'the-workshop-app-staging',
        ExpressionAttributeValues: {
            ":idx": event.pathParameters.idx,
        },
        ConditionExpression: "idx = :idx",
        Item: {
            id: event.pathParameters.id,
            idx: event.pathParameters.idx,
            name: data.name,
            message: data.message,
            type: data.type,
            eventId: data.eventId,
            sendTime: data.sendTime,
            status: data.status,
            alertType: data.alertType,
            updatedAt: timestamp
        }
    }

    dynamoDb.put(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t update the nworkshop alert item.'));
            return;
        }

        console.log('updated nworkshop alert detail is now: ', result);

        const response = {
            statusCode: 200,
            headers: { "Access-Control-Allow-Origin": "http://localhost:8100" },
            body: JSON.stringify(result.Item)
        }
        callback(null, response);
    })
}

module.exports.createfeedback = (event, context, callback) => {
    const timestamp = new Date().getTime();
    console.log('event is: ', event.body);
    const data = JSON.parse(event.body);
    console.log('create nworkshop feedback data', data);

    const params = {
        TableName: 'the-workshop-app-staging',
        Item: {
            id: uuid.v1(),
            idx: 'feedback-' + data.idx,
            name: data.name,
            userId: data.userId,
            message: data.message,
            postDate: data.postDate,
            public: data.public,
            createdAt: timestamp,
            updatedAt: timestamp
        }
    }

    dynamoDb.put(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t create the nworkshop feedback item.'));
            return;
        }

        console.log('new nworkshop feedback detail is: ', result);

        const response = {
            statusCode: 200,
            headers: { "Access-Control-Allow-Origin": "http://localhost:8100" },
            body: JSON.stringify(result.Item)
        }
        callback(null, response);
    })
}

module.exports.getfeedback = (event, context, callback) => {
    const params = {
        TableName: 'the-workshop-app-staging'
    }

    dynamoDb.scan(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t fetch the nworkshops feedbacks.'));
            return;
        }

        console.log('nworkshop feedbacks list is: ', result);

        const response = {
            statusCode: 200,
            headers: { "Access-Control-Allow-Origin": "http://localhost:8100" },
            body: JSON.stringify(result.Items.filter(e => {
                if (e.idx === event.pathParameters.idx) return e;
            }))
        }
        callback(null, response);
    })
}

module.exports.updatefeedback = (event, context, callback) => {
    const timestamp = new Date().getTime();
    const data = JSON.parse(event.body);
    console.log('updated feedback nworkshop data', data);

    const params = {
        TableName: 'the-workshop-app-staging',
        ExpressionAttributeValues: {
            ":id": event.pathParameters.id,
        },
        ConditionExpression: "id = :id",
        Item: {
            id: event.pathParameters.id,
            idx: event.pathParameters.idx,
            name: data.name,
            userId: data.userId,
            message: data.message,
            postDate: data.postDate,
            public: data.public,
            updatedAt: timestamp
        }
    }

    dynamoDb.put(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t update the nworkshop feedback item.'));
            return;
        }

        console.log('updated nworkshop feedback detail is now: ', result);

        const response = {
            statusCode: 200,
            headers: { "Access-Control-Allow-Origin": "http://localhost:8100" },
            body: JSON.stringify(result.Item)
        }
        callback(null, response);
    })
}