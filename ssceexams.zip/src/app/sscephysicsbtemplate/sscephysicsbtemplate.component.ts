import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sscephysicsbtemplate',
  templateUrl: './sscephysicsbtemplate.component.html',
  styleUrls: ['./sscephysicsbtemplate.component.css']
})
export class SscephysicsbtemplateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
