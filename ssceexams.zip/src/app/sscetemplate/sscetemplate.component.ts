import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sscetemplate',
  templateUrl: './sscetemplate.component.html',
  styleUrls: ['./sscetemplate.component.css']
})
export class SscetemplateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
