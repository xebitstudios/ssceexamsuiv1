import { Component, OnInit } from '@angular/core';
import { Meta, Title } from '@angular/platform-browser';
import { DataService } from '../service/data.service';
// import { AuthenticationService } from '../services/authentication.service';
import { ActivatedRoute, Router, Params} from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers: [DataService]
})
export class LoginComponent implements OnInit {

  constructor(private router: Router,
    private dataSvc: DataService, private route: ActivatedRoute, private meta: Meta, private title: Title) {
      title.setTitle('Portalworks SSCEexams');
      meta.addTags([
        {name: 'name', content: 'Portalworks SSCEexams'},
        {name: 'keywords', content: 'Portalworks, SSCEexams'},
        {name: 'description', content: 'SSCEexams Login'}
      ]);
    }

  ngOnInit() {
    this.router.navigate(['/login']);
  }

  userLogin() {
    this.router.navigate(['/mainboard']);
  }

}
