import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-testcenter',
  templateUrl: './testcenter.component.html',
  styleUrls: ['./testcenter.component.css']
})
export class TestcenterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
