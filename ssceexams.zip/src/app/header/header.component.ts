import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute, Router, Params} from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  @Input() tab: string;
  tabArray: String[] = [];
  staffid: number;
  classid: number;

  constructor(private router: Router,
              private route: ActivatedRoute) {
    // this.route.params.subscribe( params => console.log(params) );
  }

  ngOnInit() {
    console.log('tab is: ' + this.tab);
    this.tabArray = ['', '', '', '', '', '', '', ''];
    this.tabArray[parseInt(this.tab, 10) - 1] = 'active';
  }
  board(): void {
    this.router.navigate(['/mainboard']);
  }
  testcenter(): void {
    this.router.navigate(['/testcenter']);
  }
  analytics(): void {
    this.router.navigate(['/analytics']);
  }
  profile(): void {
    this.router.navigate(['/profile']);
  }
  contactus(): void {
    this.router.navigate(['/contactus']);
  }
  pricing(): void {
    this.router.navigate(['/pricing']);
  }
  logout(): void {
    this.router.navigate(['/logout']);
  }

}
