import { Component, OnInit } from '@angular/core';
import { DataService } from '../services/data.service';
import { DialogService } from "ng2-bootstrap-modal";
import { StudentdetailComponent } from '../studentdetail/studentdetail.component';
import { NoticemodalComponent } from '../noticemodal/noticemodal.component';
import { forEach } from '@angular/router/src/utils/collection';
import * as _ from 'underscore';

@Component({
  selector: 'app-activity',
  templateUrl: './activity.component.html',
  styleUrls: ['./activity.component.css'],  
  providers: [DataService]
})
export class ActivityComponent implements OnInit {
  tablename:string = 'allactive';
  calendarname:string = 'allcalendars';

  activeActivity:string = 'noticeboard';
  activenotices:number = 0;
  pausednotices:number = 0;
  expirednotices:number = 0;
  terms:any[] = [];  
  activities: any[] = [
    {
      "schoolid": "SCH1", 
      "activity": "View Tasks",
      "status": "active",
      "code": "tasks",
      "disp": ""
    },
    {
      "schoolid": "SCH1", 
      "activity": "View Meetings",
      "status": "active",
      "code": "meetings",
      "disp": ""
    },
    {
      "schoolid": "SCH1", 
      "activity": "View Noticeboard",
      "status": "active",
      "code": "noticeboard",
      "disp": "activ"
    },
    {
      "schoolid": "SCH1", 
      "activity": "View Timetable",
      "status": "active",
      "code": "timetable",
      "disp": ""
    },
    {
      "schoolid": "SCH1", 
      "activity": "View Term Calendar",
      "status": "active",
      "code": "calendar",
      "disp": ""
    },
    {
      "schoolid": "SCH1", 
      "activity": "View Notifications",
      "status": "active",
      "code": "notification",
      "disp": ""
    },
    {
      "schoolid": "SCH1", 
      "activity": "View Absentee List",
      "status": "active",
      "code": "absentee",
      "disp": ""
    },
    {
      "schoolid": "SCH1", 
      "activity": "View Vacation List",
      "status": "active",
      "code": "vacation",
      "disp": ""
    },
    {
      "schoolid": "SCH1", 
      "activity": "View Message Board",
      "status": "active",
      "code": "message",
      "disp": ""
    },
    {
      "schoolid": "SCH1", 
      "activity": "View Inventory",
      "status": "active",
      "code": "inventory",
      "disp": ""
    }
  ];

  noticeslength: number = 0;
  availablenoticeslength: number = 0;
  notices: any = {};
  actNoticeData: any = [];

  actCalendarData:any = [];
  availablecalendarlength: number = 0;
  latestCalendar:string = '';

  actTimetableData:any = [];
  availabletimetablelength: number = 0;
  availclasseslength:number = 0;
  availclasses:any[] = [];
  latestTimetable:string = 'term3 (2018) ';

  selectedNY:number = 2017;
  selectedTerm:string = 'Term 1';
  availyrnotificationslength:number = 0;
  availyrtermslength:number = 0;
  notifiergrouplength:number = 0;
  notifierNotifications:any[] = [];
  currentnotificationslength:number = 0;
  notificationYears:any = [];
  notificationyearterms:any[] = [];
  actNotificationData:any = [];
  filteredactNotificationData:any = [];
  availablenotificationlength: number = 0;

  selectedAbs:number = 2017;
  availyrabsenteeslength:number = 0;
  availyrabstermslength:number = 0;
  currentabsenteeslength:number = 0;
  absenteeYears:any = [];
  absenteeyearterms:any[] = [];
  actAbsenteeData:any = [];
  filteredactAbsenteeData:any = [];

  selectedMsg:number = 2017;
  availyrmessageslength:number = 0;
  availyrmsgtermslength:number = 0;
  currentmessageslength:number = 0;
  messageYears:any = [];
  messageyearterms:any[] = [];
  actMessageData:any = [];
  filteredactMessageData:any = [];

  selectedVac:number = 2017;
  availyrvacationslength:number = 0;
  availyrvactermslength:number = 0;
  currentvacationslength:number = 0;
  vacationYears:any = [];
  vacationyearterms:any[] = [];
  actVacationData:any = [];
  filteredactVacationData:any = [];

  selectedInv:number = 2017;
    
  constructor(
    private dataService: DataService,
    private dialogService:DialogService
  ) {
    this.getActivities();
    this.getTerms();
    this.setActiv(2);
  }

  ngOnInit() {
    console.log('activities...', this.activities)
  }

  setActiv(num) {
    for(var e=0;e<this.activities.length;e++) {
      if(e === num) {
        this.activities[e].disp = 'activ';
      } else {
        this.activities[e].disp = '';
      }
    }
  }
  
  getTerms() {
    this.dataService.getTerms()
      .subscribe(res => {
        this.terms = res;
        console.log('this.terms...', this.terms);       
      }); 
  }

  allCalendars(val) {
    console.log('setCalendarname called with...' + val);
    this.calendarname = val;
  }

  latestCalendars(val) {
    console.log('setCalendarname called with...' + val);
    this.calendarname = val;
  }

  calendarTerms(val) {
    console.log('setCalendarname called with...' + val);
    this.calendarname = val;
  }

  calendarYears(val) {
    console.log('setCalendarname called with...' + val);
    this.calendarname = val;
  }

  createCalendar(val) {
    console.log('setCalendarname called with...' + val);
    this.calendarname = val;
  }

  createHoliday(val) {
    console.log('setCalendarname called with...' + val);
    this.calendarname = val;
  }

  allNotices(val) {
    console.log('allNotices called...');
    this.actNoticeData = [];
    this.actNoticeData = this.notices;
    this.availablenoticeslength = this.actNoticeData.length;
    console.log('setTablename called with...' + val);
    this.tablename = val;
  }

  activeNotices(val) {
    console.log('activeNotices called...');
    this.actNoticeData = [];
    this.actNoticeData = this.activenotices;
    this.availablenoticeslength = this.actNoticeData.length;
    console.log('setTablename called with...' + val);
    this.tablename = val;
  }

  expiredNotices(val) {
    console.log('expiredNotices called...');
    this.actNoticeData = [];
    this.actNoticeData = this.expirednotices;
    this.availablenoticeslength = this.actNoticeData.length;
    console.log('setTablename called with...' + val);
    this.tablename = val;
  }

  pausedNotices(val) {
    console.log('pausedNotices called...');
    this.actNoticeData = [];
    this.actNoticeData = this.pausednotices;
    this.availablenoticeslength = this.actNoticeData.length;
    console.log('setTablename called with...' + val);
    this.tablename = val;
  }

  showNoticeModal(type) {
    this.dataService.noticeType = type;
    let disposable = this.dialogService.addDialog(StudentdetailComponent, {
      staffid: 9999,
      title:'Create New Notice',
      message:'Create A New Notice'
    })
    .subscribe((isConfirmed)=>{
      if(isConfirmed) {
        console.log('OK button clicked!');
      }
      else {
        console.log('Close button clicked!');
      }
    });
  }

  createNotice(val) {
    console.log('createNotice called...');
    this.showNoticeModal('New');
    console.log('setTablename called with...' + val);
    this.tablename = val;    
  }

  editNotice(val) {
    console.log('editNotice called with boardid...', val);
    this.dataService.boardid = val;
    this.showNoticeModal('Edit');
    console.log('setTablename called with...' + val);
    this.tablename = val;
  }

  editCalendar(val) {
    console.log('editCalendar called with boardid...', val);
    this.dataService.calendartermid = val;
    this.showNoticeModal('Edit');
  }

  getAbsentees(yr) {
    console.log('getAbsentees called with year...' + yr);
    this.actAbsenteeData = [];
    this.absenteeyearterms = ['All'];
    this.absenteeYears = _.unique(this.notices.absentee.map(d => {
      return d.year;
    }));
    this.availyrabstermslength = this.notices.absentee.map(d => {
      return {
        'termid': d.termid,
        'year': d.year
      }
    }).filter(s => {
      if(s.year === yr) {
        this.absenteeyearterms.push(s.termid);
        return s
      };
    }).length;
    console.log('this.availyrabstermslength...', this.availyrabstermslength);

    for(var a=0;a<this.notices.absentee.length;a++){
      if(this.notices.absentee[a].year === yr) {
        this.notices.absentee[a].absentdays.forEach(e => {
          e.term = this.notices.absentee[a].termid;
          this.actAbsenteeData.push(e);
        });        
      }
    }
    console.log('final this.actAbsenteeData...', this.actAbsenteeData);
    this.availyrabsenteeslength = this.actAbsenteeData.length;
    this.filteredactAbsenteeData = this.actAbsenteeData;
    this.currentabsenteeslength = this.filteredactAbsenteeData.length;
  }

  getMessages(yr) {
    console.log('getMessages called with year...' + yr);
    this.actMessageData = [];
    this.messageyearterms = ['All'];
    this.availyrmsgtermslength = this.notices.message.map(d => {
      return {
        'termid': d.termid,
        'year': d.year
      }
    }).filter(s => {
      if(s.year === yr) {
        this.messageyearterms.push(s.termid);
        return s
      };
    }).length;
    console.log('this.messageyearterms is...', this.messageyearterms);
    console.log('this.availyrmsgtermslength...', this.availyrmsgtermslength);

    for(var a=0;a<this.notices.message.length;a++){
      // if(this.notices.message[a].year === yr) {
        this.notices.message[a].messages.forEach(e => {
          e.term = this.notices.message[a].termid;
          this.actMessageData.push(e);
        });        
      // }
    }
    console.log('final this.actMessageData...', this.actMessageData);
    this.messageYears = [];
    this.messageYears.push('All');
    _.unique(this.actMessageData.map(d => {
      return (d.sentdate).split('/')[2];
    })).forEach(w => {
      this.messageYears.push(w);
    });
    this.availyrmessageslength = this.actMessageData.length;
    this.changeMessageYear(this.messageYears[this.messageYears.length - 1]);
    // this.filteredactMessageData = this.actMessageData;
    // this.currentmessageslength = this.filteredactMessageData.length;
  }

  changeMessageYear(yr) {
    console.log('changeMessageYear called with year...', yr);
    this.selectedMsg = yr;
    if(yr === 'All') {
      this.filteredactMessageData = this.actMessageData;
    } else {
      this.filteredactMessageData = this.actMessageData.filter(e => {
        if((e.sentdate).split('/')[2] === yr) return e;
      });
    }
    this.currentmessageslength = this.filteredactMessageData.length;
    console.log('filteredactMessageData is now...', this.filteredactMessageData);
  }

  getVacations(yr) {
    console.log('getVacations called with year...' + yr);
    this.actVacationData = [];
    this.vacationyearterms = ['All'];
    this.availyrvactermslength = this.notices.vacation.map(d => {
      return {
        'termid': d.termid,
        'year': d.year
      }
    }).filter(s => {
      if(s.year === yr) {
        this.vacationyearterms.push(s.termid);
        return s
      };
    }).length;
    console.log('this.vacationyearterms...', this.vacationyearterms);
    console.log('this.availyrvactermslength...', this.availyrvactermslength);

    for(var a=0;a<this.notices.vacation.length;a++){
      // if(this.notices.vacation[a].year === yr) {
        this.notices.vacation[a].vacations.forEach(e => {
          e.term = this.notices.vacation[a].termid;
          this.actVacationData.push(e);
        });        
      // }
    }
    console.log('final this.actVacationData...', this.actVacationData);
    this.vacationYears = [];
    this.vacationYears.push('All');
    _.unique(this.actVacationData.map(d => {
      return (d.vacationstartdate).split('/')[2];
    })).forEach(w => {
      this.vacationYears.push(w);
    });
    this.availyrvacationslength = this.actVacationData.length;
    this.changeVacationYear(this.vacationYears[this.vacationYears.length - 1]);
  }

  changeVacationYear(yr) {
    console.log('changeVacationYear called with year...', yr);
    console.log('The this.actVacationData...', this.actVacationData);
    this.selectedVac = yr;
    if(yr === 'All') {
      this.filteredactVacationData = this.actVacationData;
    } else {
      this.filteredactVacationData = this.actVacationData.filter(e => {
        if((e.vacationstartdate).split('/')[2] === yr) {
          return e;
        }
      });
    }   

    this.vacationyearterms = ['All'];
    _.unique(this.filteredactVacationData.forEach(w => {
      this.vacationyearterms.push(w.term);
    }));
    this.vacationyearterms = _.unique(this.vacationyearterms);
    console.log('ooo this.vacationyearterms...', this.vacationyearterms);
    this.currentvacationslength = this.filteredactVacationData.length;
    console.log('filteredactVacationData is now...', this.filteredactVacationData);
  }

  termVacations(term) {
    console.log('termVacations called with term...', term);
    if(term === 'All') { 
      this.filteredactVacationData = this.actVacationData.filter(e => {
        if((e.vacationstartdate).split('/')[2] === this.selectedVac) {
          return e;
        }
      });
    } else {
      this.filteredactVacationData = this.actVacationData.filter(e => {
        if(((e.vacationstartdate).split('/')[2] === this.selectedVac) && (e.term === term)) {
          return e;
        }
      });
    }
    this.currentvacationslength = this.filteredactVacationData.length;
  }

  createMessage() {
    console.log('createMessage called...')
  }

  createAbsentee() {
    console.log('createAbsentee called...')
  }

  changeAbsenteeYear(val) {
    console.log('changeAbsenteeYear called with...' + val);
    this.selectedAbs = val;
    this.getAbsentees(parseInt(val));
  }

  termAbsentees(term) {
    console.log('termAbsentees called with term...', term);
    if(term === 'All') { 
      this.filteredactAbsenteeData = this.actAbsenteeData; 
    } else {
      this.filteredactAbsenteeData = this.actAbsenteeData.filter(e => {
        if(e.term === term) return e;
      });
    }
    this.currentabsenteeslength = this.filteredactAbsenteeData.length;
  }

  getYearNotifications(yr) {
    console.log('getYearNotifications called with year...' + yr);
    this.actNotificationData = [];
    this.notificationyearterms = ['All'];
    this.notificationYears = _.unique(this.notices.notifications.map(d => {
      return d.year;
    }));
    this.availyrtermslength = this.notices.notifications.map(d => {
      return {
        'termid': d.termid,
        'year': d.year
      }
    }).filter(s => {
      if(s.year === yr) {
        this.notificationyearterms.push(s.termid);
        return s
      };
    }).length;
    console.log('this.availyrtermslength...', this.availyrtermslength);

    for(var a=0;a<this.notices.notifications.length;a++){
      if(this.notices.notifications[a].year === yr) {
        this.notices.notifications[a].allnotifications.forEach(e => {
          e.term = this.notices.notifications[a].termid;
          this.actNotificationData.push(e);
        });        
      }
    }
    console.log('final this.actNotificationData...', this.actNotificationData);
    this.availyrnotificationslength = this.actNotificationData.length;
    this.notifierNotifications = ['All'];
    this.actNotificationData.forEach(g => {
      this.notifierNotifications.push(g.senderrole);
    });
    this.notifierNotifications = _.unique(this.notifierNotifications);
    this.notifiergrouplength = this.notifierNotifications.length - 1; 
    this.filteredactNotificationData = this.actNotificationData;
    this.currentnotificationslength = this.filteredactNotificationData.length;
  }

  createNotification() {
    console.log('createNotification called...');
  }

  termNotifications(term) {
    console.log('termNotifications called with term...', term);
    if(term === 'All') { 
      this.filteredactNotificationData = this.actNotificationData; 
    } else {
      this.filteredactNotificationData = this.actNotificationData.filter(e => {
        if(e.term === term) return e;
      });
    }
    this.currentnotificationslength = this.filteredactNotificationData.length;
  }

  groupNotifications(group) {
    console.log('groupNotifications called with group...', group);
    if(group === 'All') { 
      this.filteredactNotificationData = this.actNotificationData; 
    } else {
      this.filteredactNotificationData = this.actNotificationData.filter(e => {
        if(e.senderrole === group) return e;
      });
    }
    this.currentnotificationslength = this.filteredactNotificationData.length;
  }

  changeNotificationYear(val) {
    console.log('changeNotificationYear called with...' + val);
    this.selectedNY = val;
    this.getYearNotifications(parseInt(val));
  }

  getActivities() {
    this.dataService.getActivities()
      .subscribe(res => {
        this.notices = res;
        console.log('this.notices...', this.notices);
        this.noticeslength = this.notices.noticeboard.length;
        this.activenotices = this.notices.noticeboard.filter(e => {
          if(e.status === 'active') return e;
        })
        this.pausednotices = this.notices.noticeboard.filter(e => {
          if(e.status === 'paused') return e;
        })
        this.expirednotices = this.notices.noticeboard.filter(e => {
          if(e.status === 'expired') return e;
        })
        console.log('this.activenotices...', this.activenotices)
        console.log('this.pausednotices...', this.pausednotices)
        console.log('this.expirednotices...', this.expirednotices) 
        this.actNoticeData = this.notices.noticeboard; 
        this.availablenoticeslength = this.actNoticeData.length;

        this.actCalendarData = this.notices.calendar;
        this.availablecalendarlength = this.actCalendarData.length;
        this.latestCalendar = this.actCalendarData[this.availablecalendarlength-1].termid + ' (' + this.actCalendarData[this.availablecalendarlength-1].year + ')';

        this.actTimetableData = this.notices.timetable;
        this.availabletimetablelength = this.actTimetableData.length;

        this.actNotificationData = this.notices.notifications;
        this.availablenotificationlength = this.actNotificationData.length;        
      }); 
  }

  capt(val) {
    return val.toUppercase();
  }

  getList(list) {
    return list.join(', ')
  }

  getHolidays(list) {
    let hol = []
    list.forEach(e => {
      hol.push('[' + e.holiday + ', ' + e.date + ']');
    });
    return hol.join(', ');
  }

  getSlots(list) {
    let slots = []
    for(var i=0;i<list.length;i++) {
      slots.push('[');
      for(let key of Object.keys(list[i])) {
        slots.push(', ' + list[i][key]);
      }
      slots.push(']');
    };
    return slots.join('');
  }

  getActive() {
    // console.log('getActive called...');
    return 6;
  }

  getActivity(val) {
    console.log('getActivity called with: ' + val);
    if(val === 'noticeboard') {
      this.setActiv(2);
      this.activeActivity = 'noticeboard';
    } else if(val === 'timetable') {
      this.activeActivity = 'timetable';
      this.setActiv(3);
    } else if(val === 'calendar') {
      this.activeActivity = 'calendar';
      this.setActiv(4);
    } else if(val === 'notification') {
      this.activeActivity = 'notification';
      this.setActiv(5);
      this.getYearNotifications(this.selectedNY);
    } else if(val === 'absentee') {
      this.activeActivity = 'absentee';
      this.setActiv(6);
      this.getAbsentees(this.selectedAbs);
    } else if(val === 'vacation') {
      this.activeActivity = 'vacation';
      this.setActiv(7);
      this.getVacations(this.selectedVac);
    } else if(val === 'message') {
      this.activeActivity = 'message';
      this.setActiv(8);
      this.getMessages(this.selectedMsg);
    } else if(val === 'message') {
      this.activeActivity = 'inventory';
      this.setActiv(9);
      this.getMessages(this.selectedInv);
    }
  }

}
