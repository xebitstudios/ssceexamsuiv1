import { Component, OnInit } from '@angular/core';
import { DataService } from '../services/data.service';

@Component({
  selector: 'app-configurator',
  templateUrl: './configurator.component.html',
  styleUrls: ['./configurator.component.css'], 
  providers: [DataService]
})
export class ConfiguratorComponent implements OnInit {

  tablename:string = 'classrooms';
  staff: any[] = [];
  activities: any[] = [
    {
      "schoolid": "SCH1", 
      "activity": "Class Rooms",
      "status": "active",
      "code": "classrooms",
      "disp": "activ"
    },
    {
      "schoolid": "SCH1", 
      "activity": "Staff Types",
      "status": "active",
      "code": "stafftypes",
      "disp": ""
    },
    {
      "schoolid": "SCH1", 
      "activity": "Rooms",
      "status": "active",
      "code": "rooms",
      "disp": ""
    },
    {
      "schoolid": "SCH1", 
      "activity": "Subjects",
      "status": "active",
      "code": "subjects",
      "disp": ""
    },
    {
      "schoolid": "SCH1", 
      "activity": "Score Types",
      "status": "active",
      "code": "scoretypes",
      "disp": ""
    },
    {
      "schoolid": "SCH1", 
      "activity": "Pay Groups",
      "status": "active",
      "code": "paygroups",
      "disp": ""
    },
    {
      "schoolid": "SCH1", 
      "activity": "Staff Levels",
      "status": "active",
      "code": "stafflevels",
      "disp": ""
    },
    {
      "schoolid": "SCH1", 
      "activity": "Pay Frequency",
      "status": "active",
      "code": "payfrequency",
      "disp": ""
    },
    {
      "schoolid": "SCH1", 
      "activity": "Session Terms",
      "status": "active",
      "code": "sessionterms",
      "disp": ""
    },
    {
      "schoolid": "SCH1", 
      "activity": "Payroll Items",
      "status": "active",
      "code": "payrollitems",
      "disp": ""
    },
    {
      "schoolid": "SCH1", 
      "activity": "Noticeboard Statuses",
      "status": "active",
      "code": "noticeboardstatus",
      "disp": ""
    },
    {
      "schoolid": "SCH1", 
      "activity": "Timetable Slots",
      "status": "active",
      "code": "timetableslots",
      "disp": ""
    },
    {
      "schoolid": "SCH1", 
      "activity": "Holidays",
      "status": "active",
      "code": "holidays",
      "disp": ""
    },
    {
      "schoolid": "SCH1", 
      "activity": "Notification Groups",
      "status": "active",
      "code": "notificationgroups",
      "disp": ""
    }
  ];

  configTabs:any[] = [
    {
      "title1text": "Class Rooms",
      "title1value": 12,
      "title2text": "Active Class Rooms",
      "title2value": 12,
      "newtext": "New Classroom",
      "edittext": "Edit Classroom",
      "selectkey": "classrooms"
    },
    {
      "title1text": "Staff Types",
      "title1value": 13,
      "title2text": "Active Staff Types",
      "title2value": 12,
      "newtext": "New Staff Type",
      "edittext": "Edit Staff Type",
      "selectkey": "stafftypes"
    },
    {
      "title1text": "Rooms",
      "title1value": 16,
      "title2text": "Active Rooms",
      "title2value": 16,
      "newtext": "New Room",
      "edittext": "Edit Room",
      "selectkey": "rooms"
    },
    {
      "title1text": "Subjects",
      "title1value": 26,
      "title2text": "Active Subjects",
      "title2value": 24,
      "newtext": "New Subject",
      "edittext": "Edit Subject",
      "selectkey": "subjects"
    },
    {
      "title1text": "Score Types",
      "title1value": 3,
      "title2text": "Active Score Types",
      "title2value": 3,
      "newtext": "New Score Type",
      "edittext": "Edit Score Type",
      "selectkey": "scoretypes"
    },
    {
      "title1text": "Pay Groups",
      "title1value": 2,
      "title2text": "Active Pay Groups",
      "title2value": 2,
      "newtext": "New Pay Group",
      "edittext": "Edit Pay Group",
      "selectkey": "paygroups"
    },
    {
      "title1text": "Staff Levels",
      "title1value": 5,
      "title2text": "Active Staff Levels",
      "title2value": 5,
      "newtext": "New Staff Level",
      "edittext": "Edit Staff Level",
      "selectkey": "stafflevels"
    },
    {
      "title1text": "Pay Frequencies",
      "title1value": 2,
      "title2text": "Active Pay Frequencies",
      "title2value": 2,
      "newtext": "New Pay Frequency",
      "edittext": "Edit Pay Frequency",
      "selectkey": "payfrequency"
    },
    {
      "title1text": "Session Terms",
      "title1value": 3,
      "title2text": "Active Session Terms",
      "title2value": 3,
      "newtext": "New Session Term",
      "edittext": "Edit Session Term",
      "selectkey": "sessionterms"
    },
    {
      "title1text": "Payroll Items",
      "title1value": 36,
      "title2text": "Active Payroll Items",
      "title2value": 36,
      "newtext": "New Payroll Item",
      "edittext": "Edit Payroll Item",
      "selectkey": "payrollitems"
    },
    {
      "title1text": "Noticeboard Statuses",
      "title1value": 3,
      "title2text": "Active Noticeboard Statuses",
      "title2value": 3,
      "newtext": "New Noticeboard Status",
      "edittext": "Edit Noticeboard Status",
      "selectkey": "noticeboardstatus"
    },
    {
      "title1text": "Timetable Slots",
      "title1value": 8,
      "title2text": "Active Timetable Slots",
      "title2value": 8,
      "newtext": "New Timetable Slot",
      "edittext": "Edit Timetable Slot",
      "selectkey": "timetableslots"
    },
    {
      "title1text": "Holidays",
      "title1value": 11,
      "title2text": "Active Holidays",
      "title2value": 10,
      "newtext": "New Holiday",
      "edittext": "Edit Holiday",
      "selectkey": "holidays"
    },
    {
      "title1text": "Notification Groups",
      "title1value": 4,
      "title2text": "Active Notification Groups",
      "title2value": 4,
      "newtext": "New Notification Group",
      "edittext": "Edit Notification Group",
      "selectkey": "notificationgroups"
    }
  ];

  constructor(private dataService: DataService) {
    this.getStaff();
  }

  ngOnInit() {
  }

  setTablename(val) {
    console.log('setTablename called with...' + val);
    this.tablename = val;
  }

  getStaff() {
    this.dataService.getStaff()
      .subscribe(res => {
        this.staff = res;
        console.log('this.staff...', this.staff);
      }); 
  }

}
