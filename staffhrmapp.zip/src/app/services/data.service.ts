import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';

@Injectable()
export class DataService {

  noticeType:string = '';
  boardid:string;
  calendartermid:string;
  // private uri = '../staffhrmv0/assets/apidata/staffdata.json';
  private staffListUri = '../../assets/apidata/staffdata.json';
  private studentsListUri = '../../assets/apidata/students.json';
  private classesListUri = '../../assets/apidata/classes.json';
  private termsListUri = '../../assets/apidata/terms.json';
  private activitiesUri = '../../assets/apidata/activitieslist.json';
  private payDetailsUri = '../../assets/apidata/paydetails.json';

  constructor(private http: Http) {}

  getStaff():Observable<any> {
    return this.http.get(this.staffListUri)
              .map((res: Response) => res.json());
  }

  getStudents():Observable<any> {
    return this.http.get(this.studentsListUri)
              .map((res: Response) => res.json());
  }

  getClasses():Observable<any> {
    return this.http.get(this.classesListUri)
              .map((res: Response) => res.json());
  }

  getTerms():Observable<any> {
    return this.http.get(this.termsListUri)
              .map((res: Response) => res.json());
  }

  getPayDetails():Observable<any> {
    return this.http.get(this.payDetailsUri)
              .map((res: Response) => res.json());
  }

  getActivities():Observable<any> {
    return this.http.get(this.activitiesUri)
              .map((res: Response) => res.json());
  }

}
