import { Component, OnInit } from '@angular/core';
import { DataService } from '../services/data.service';

@Component({
  selector: 'app-class',
  templateUrl: './class.component.html',
  styleUrls: ['./class.component.css'],
  providers: [DataService]
})
export class ClassComponent implements OnInit {
  classesbname:string = 'classstatistics';

  male: number = 0;
  female: number = 0;
  total: number = 0;
  allstudents: any[] = [];
  students: any[] = [];
  males: any[] = [];
  females: any[] = [];
  staff:any[] = [];  
  classes: any[] = [];
  classIndx:number = 0;
  
  constructor(
    private dataService: DataService
  ) {
    this.getStaff();
    this.getStudents();
    this.getClasses();
    setTimeout(() => {
      this.getClassStudents((this.classes[this.classIndx]).classname, this.classIndx);
    }, 2000);
  }

  ngOnInit() {
    console.log('classes...', this.classes)
  }

  getGender(val) {
    if(val === 'F') return 'female'
    if(val === 'M') return 'male'
  }

  getClassStudents(clssname, indx) {
    this.students = this.allstudents.filter(e => { if(clssname === e.presentclass) return e; });
    this.males = this.students.filter(e => { if(e.gender === 'M') return e; });
    this.male = this.males.length;
    this.females = this.students.filter(e => { if(e.gender === 'F') return e; });
    this.female = this.females.length;
    this.total = this.students.length;
    this.classIndx = indx;
  }

  classClicked(classname, indx, val) {
    console.log('classname...' + classname)
    // this.classes.forEach(clss => function(clss) {
    for(var e=0;e<this.classes.length;e++) {
      if(this.classes[e].classname === classname) {
        this.classes[e].disp = 'activ'
      } else {
        this.classes[e].disp = ''
      }
    };
    this.getClassStudents((this.classes[indx]).classname, indx);
    console.log('setTablename called with...' + val);
    this.classesbname = val;
  }

  getStaff() {
    this.dataService.getStaff()
      .subscribe(res => {
        this.staff = res;
        console.log('this.staff...', this.staff);
      }); 
  }

  getStudents() {
    this.dataService.getStudents()
      .subscribe(res => {
        this.allstudents = res;
        console.log('this.allstudents...', this.allstudents);
      }); 
  }

  getClasses() {
    this.dataService.getClasses()
      .subscribe(res => {
        this.classes = res;
        console.log('this.classes...', this.classes);
      }); 
  }

  viewScore(indx, val) {
    console.log('indx...' + indx);
    console.log('setTablename called with...' + val);
    this.classesbname = val;
  }

  createScore(indx, val) {
    console.log('indx...' + indx);
    console.log('setTablename called with...' + val);
    this.classesbname = val;
  }

}
