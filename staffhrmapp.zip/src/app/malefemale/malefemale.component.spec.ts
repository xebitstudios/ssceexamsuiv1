import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MalefemaleComponent } from './malefemale.component';

describe('MalefemaleComponent', () => {
  let component: MalefemaleComponent;
  let fixture: ComponentFixture<MalefemaleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MalefemaleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MalefemaleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
