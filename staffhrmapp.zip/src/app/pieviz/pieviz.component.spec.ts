import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PievizComponent } from './pieviz.component';

describe('PievizComponent', () => {
  let component: PievizComponent;
  let fixture: ComponentFixture<PievizComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PievizComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PievizComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
