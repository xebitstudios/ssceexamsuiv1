import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pieviz',
  templateUrl: './pieviz.component.html',
  styleUrls: ['./pieviz.component.css']
})
export class PievizComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
