import { Component, OnInit } from '@angular/core';
import { DataService } from '../services/data.service';

@Component({
  selector: 'app-staff',
  templateUrl: './staff.component.html',
  styleUrls: ['./staff.component.css'],
  providers: [DataService]
})
export class StaffComponent implements OnInit {
  staffs = [];

  constructor(private dataService: DataService) { }

  ngOnInit() {
    this.dataService.getStaff()
        .subscribe(resStaffData => this.staffs = resStaffData);
  }

}
