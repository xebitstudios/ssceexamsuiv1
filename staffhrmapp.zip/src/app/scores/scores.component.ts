import { Component, OnInit } from '@angular/core';
import { DataService } from '../services/data.service';

@Component({
  selector: 'app-scores',
  templateUrl: './scores.component.html',
  styleUrls: ['./scores.component.css'], 
  providers: [DataService]
})
export class ScoresComponent implements OnInit {

  toShow:string = 'hide';
  tabname:string = 'paygroups';
  tablename:string = 'teachers';
  selectedPayslip:string = "Jan 2017";
  selectedPayFrequency:string = 'All';
  selectedPayFrequencyPeriod:string = '';
  payrollHistory:any[] = [];
  staff: any[] = [];
  staffhistory: any[] = [];
  employee:any = {
    "empcode": "ABA814",
    "fname": "Abimbola",      
    "lname": "Aileru",
    "level": "7",
    "position": "Teacher",
    "basicpay": "43000",
    "allowance": "4000",
    "frequency": "Monthly",
    "paygroup": "Teachers",
    "payperiod": "Oct2016"
  };
  payperiods:any = [];
  payfrequency:any = ['Select', 'All', 'Monthly', 'Semi-Monthly'];
  payfrequencyperiods:any[] = [];
  activities: any[] = [
    {
      "schoolid": "SCH1", 
      "activity": "Qualifications",
      "status": "active",
      "code": "qualifications",
      "disp": ""
    },
    {
      "schoolid": "SCH1", 
      "activity": "Pay Groups",
      "status": "active",
      "code": "paygroups",
      "disp": "activ"
    },
    {
      "schoolid": "SCH1", 
      "activity": "Categories",
      "status": "active",
      "code": "categories",
      "disp": ""
    }
  ];
  paygroups:any = {
    "pgteachers": "Teaching Staff",
    "numteachers": 0,
    "btnteachers": "View Teachers",
    "pgadmin": "Non-Teaching Staff",
    "numadmin": 0,
    "btnadmin": "View Others",
    "pgothers": "Others",
    "numothers": 5,
    "btnothers": "View Types",
    "paydetails": "Your Payroll Details",
    "detailsstatus": "Complete",
    "btndetails": "View Details",
    "payslips": "Your Payslips",
    "numpayslips": 9,
    "btnpayslips": "View Payslips",
    "payhistory": "Your Payroll History",
    "historyreports": "Available",
    "btnpayhistory": "View History"
  };
  paygrps:any[] = [];
  availablePayslips:number = 0;
  paydetails: any[] = [];
  monthlypay: any[] = [];
  semimonthlypay: any[] = [];
  actdata:any[] = [
    {
      "val1": "val1",
      "val2": "val2",
      "val3": "val3",
      "val4": "val4",
      "val5": "val5",
      "val6": "val6"
    }
  ];
  teachers:any[] = [];
  admins:any[] = [];

  others:any[] = [
    {
      "empcode": "ADEG01",
      "fname": "Adebola",      
      "lname": "George",
      "level": "7",
      "position": "Teacher",
      "basicpay": "35000",
      "allowance": "2200",
      "frequency": "Monthly"
    },
    {
      "empcode": "ADEG01",
      "fname": "Adebola",      
      "lname": "George",
      "level": "7",
      "position": "Teacher",
      "basicpay": "35000",
      "allowance": "2200",
      "frequency": "Monthly"
    },
    {
      "empcode": "ADEG01",
      "fname": "Adebola",      
      "lname": "George",
      "level": "7",
      "position": "Teacher",
      "basicpay": "35000",
      "allowance": "2200",
      "frequency": "Monthly"
    },
    {
      "empcode": "ADEG01",
      "fname": "Adebola",      
      "lname": "George",
      "level": "7",
      "position": "Teacher",
      "basicpay": "35000",
      "allowance": "2200",
      "frequency": "Monthly"
    },
    {
      "empcode": "ADEG01",
      "fname": "Adebola",      
      "lname": "George",
      "level": "7",
      "position": "Teacher",
      "basicpay": "35000",
      "allowance": "2200",
      "frequency": "Monthly"
    }
  ];

  constructor(
    private dataService: DataService
  ) {
    this.getStaff();
    this.getPayDetails();
  }

  ngOnInit() {}

  getYourPaySlips() {
    console.log('getYourPaySlips called for current employee...' + this.employee.empcode)
  }

  getCode(val) {
    if(val === undefined) {
      return '';
    } else {
      return val.split('_')[1];
    }
  }

  getPayDetails() {
    this.dataService.getPayDetails()
      .subscribe(res => {
        this.paydetails = res;
        this.teachers = [];
        this.admins = [];
        console.log('this.paydetails...', this.paydetails); 
        this.paydetails[0].paydetails.forEach(ee => {
          if(ee.frequency === 'Monthly') { 
            this.monthlypay.push(ee);
            ee.paydetails.forEach(eee => {
              if(eee.type === 'teacher') {
                this.teachers.push(
                  {
                    "empcode": eee.staffid,
                    "fname": eee.firstname,      
                    "lname": eee.lastname,
                    "level": "",
                    "position": eee.type,
                    "basicpay": eee.basicpay,
                    "allowance": eee.allowances,
                    "frequency": ee.frequency,
                    "paygroup": eee.type,
                    "payperiod": this.getCode(ee.code)
                  }
                );
              } else {
                this.admins.push(
                  {
                    "empcode": eee.staffid,
                    "fname": eee.firstname,      
                    "lname": eee.lastname,
                    "level": "",
                    "position": eee.type,
                    "basicpay": eee.basicpay,
                    "allowance": eee.allowances,
                    "frequency": ee.frequency,
                    "paygroup": eee.type,
                    "payperiod": this.getCode(ee.code)
                  }
                );
              }
            });
          };
          if(ee.frequency === 'Semi-Monthly') { 
            this.semimonthlypay.push(ee);
            ee.paydetails.forEach(eee => {
              if(eee.type === 'teacher') {
                this.teachers.push(
                  {
                    "empcode": eee.staffid,
                    "fname": eee.firstname,      
                    "lname": eee.lastname,
                    "level": "",
                    "position": eee.type,
                    "basicpay": eee.basicpay,
                    "allowance": eee.allowances,
                    "frequency": ee.frequency,
                    "paygroup": eee.type,
                    "payperiod": this.getCode(ee.code)
                  }
                );
              } else {
                this.admins.push(
                  {
                    "empcode": eee.staffid,
                    "fname": eee.firstname,      
                    "lname": eee.lastname,
                    "level": "",
                    "position": eee.type,
                    "basicpay": eee.basicpay,
                    "allowance": eee.allowances,
                    "frequency": ee.frequency,
                    "paygroup": eee.type,
                    "payperiod": this.getCode(ee.code)
                  }
                );
              }
            });
          }
        });
        console.log('this.admins...', this.admins);
        console.log('this.teachers...', this.teachers);
        console.log('this.monthlypay...', this.monthlypay);
        console.log('this.semimonthlypay...', this.semimonthlypay);
        this.paygroups.numadmin = this.admins.length;
        this.paygroups.numteachers = this.teachers.length;
        this.paydetails[0].paydetails.forEach(ee => { 
          this.paygrps.push(ee.paydetails.map(ff => {
            return ff.type;
          }));
        });
        this.paygrps = [].concat.apply([], this.paygrps).filter((x, i, a) => a.indexOf(x) == i);
        console.log('paygrps...', this.paygrps);
        this.payperiods = this.getEmployeePayPeriods(this.employee.empcode, this.employee.paygroup);
        this.setEmployeePaySlip((this.employee.paygroup).toLowerCase(), this.employee.empcode, this.payperiods[this.payperiods.length - 1]);
        console.log('this.payperiods...', this.payperiods);
      });
  }

  setEmployeePaySlip(paygroup, empcode, payperiod) {
    console.log('setEmployeePaySlip called with...' + paygroup + '-' + empcode + '-' + payperiod);
    if(paygroup.toLowerCase() === 'teachers') {
      return this.teachers.filter(e => {
        if((e.empcode === empcode) && (e.payperiod === payperiod)) {
          console.log('found...', e);
          this.employee.basicpay = e.basicpay;
          this.employee.allowance = e.allowance;
          this.employee.payperiod = e.payperiod;
          this.employee.frequency = e.frequency;
          return e;
        }
      });
    } else {
      return this.admins.filter(e => {
        if((e.empcode === empcode) && (e.payperiod === payperiod)) {
          console.log('found...', e);
          this.employee.basicpay = e.basicpay;
          this.employee.allowance = e.allowance;
          this.employee.payperiod = e.payperiod;
          this.employee.frequency = e.frequency;
          return e;
        }
      });
    }
  }

  getEmployeePayPeriods(empcode, paygroup) {
    console.log('getEmployeePayPeriods called with empId...' + empcode);
    if(paygroup === 'Teachers') {
      return this.teachers.filter(e => {
        if(e.empcode === empcode) return e;
      }).map(ee => {
        return ee.payperiod;
      });
    } else {
      return this.admins.filter(e => {
        if(e.empcode === empcode) return e;
      }).map(ee => {
        return ee.payperiod;
      });
    }
  }

  getEmployeePayslip(mthyr) {
    console.log('getEmployeePayslip called for month-year...' + mthyr);
    // this.employee = API call for new payslip data
    this.setEmployeePaySlip(this.employee.paygroup, this.employee.empcode, mthyr);
  }

  getPayFrequencyPeriods(freq) {
    console.log('getPayFrequencyPeriods called for Frequency...' + freq);
    this.payfrequencyperiods = [];
    if(freq === 'All') {
      this.payfrequencyperiods = this.paydetails[0].paydetails.map(function(e) { return e.period});
    } else if(freq === 'Monthly') {
      this.payfrequencyperiods = this.monthlypay.map(function(e) { return e.period});
    } else if(freq === 'Semi-Monthly') {
      this.payfrequencyperiods = this.semimonthlypay.map(function(e) { return e.period});
    }
    console.log('this.payfrequencyperiods...', this.payfrequencyperiods);
  }

  changePayPeriod(val) {
    console.log('changePayPeriod called with...' + val);
    this.selectedPayslip = val;
    this.getEmployeePayslip(val);
  }

  changePayFrequency(val) {
    console.log('changePayFrequency called with...' + val);
    this.selectedPayFrequency = val;
    this.getPayFrequencyPeriods(val);
  }

  changePayFrequencyPeriod(val) {
    console.log('changePayFrequencyPeriod called with...' + val);
    this.selectedPayFrequencyPeriod = val;
    console.log('this.selectedPayFrequencyPeriod...', this.selectedPayFrequencyPeriod);
    this.payrollHistory = [];
    this.availablePayslips = 0;
    if(this.selectedPayFrequency === 'All') {
      this.payrollHistory = this.paydetails[0].paydetails.filter(e => { 
        if(this.selectedPayFrequencyPeriod === e.period) { return e };
      }).map(function(f) { return f.paydetails; })
    } else if(this.selectedPayFrequency === 'Monthly') {
      this.payrollHistory = this.monthlypay.filter(e => { 
        if(this.selectedPayFrequencyPeriod === e.period) { return e };
      }).map(function(f) { return f.paydetails; })
    } else if(this.selectedPayFrequency === 'Semi-Monthly') {
      this.payrollHistory = this.semimonthlypay.filter(e => { 
        if(this.selectedPayFrequencyPeriod === e.period) { return e };
      }).map(function(f) { return f.paydetails; })
    }
    console.log('this.payrollHistory...', this.payrollHistory);
    this.availablePayslips = this.payrollHistory[0].length;
  }

  setActiv(val) {
    for(var e=0;e<this.activities.length;e++) {
      if(this.activities[e].code === val) {
        this.activities[e].disp = 'activ'
      } else {
        this.activities[e].disp = ''
      }
    }
  }

  setTablename(val) {
    console.log('setTablename called with...' + val);
    this.tablename = val;
  }

  getActivity(val) {
    console.log('getActivity called with...' + val);
    this.tabname = val;
    this.setActiv(val);
  }

  printPayslip(val) {
    console.log('printPayslip for month...' + val);
  }

  getStaff() {
    this.dataService.getStaff()
      .subscribe(res => {
        this.staff = res;
        console.log('this.staff...', this.staff);
        // this.notices = this.actdata.noticeboard.length;        
      }); 
  }

  getList(list) {
    // console.log('list...' + list);
    return list.join(', ')
  }

  getActive() {
    // console.log('getActive called...');
    return 6;
  }

  viewTeachers() {
    console.log('viewTeachers called...');
  }

  viewAdmins() {
    console.log('viewAdmins called...');
  }

  viewOthers() {
    console.log('viewOthers called...');
  }

  viewPayslips() {
    console.log('viewPayslips called...');
  }

  viewPayroll() {
    console.log('viewPayroll called...');
  }

  viewPayHistory() {
    console.log('viewPayHistory called...');
  }

  viewPayHist(empcode) {
    console.log('viewPayHist called with...' + empcode);
    this.staffhistory = [
      {
        "empcode": "ADEOL01",
        "fname": "Adeyemi",      
        "lname": "Olubolade",
        "level": "7",
        "position": "Teacher",
        "basicpay": "35000",
        "allowance": "2200",
        "frequency": "Monthly",
        "paygroup": "Teachers",
        "payperiod": "Oct 2017"
      },
      {
        "empcode": "ADEOL01",
        "fname": "Adeyemi",      
        "lname": "Olubolade",
        "level": "7",
        "position": "Teacher",
        "basicpay": "35000",
        "allowance": "2200",
        "frequency": "Monthly",
        "paygroup": "Teachers",
        "payperiod": "Nov 2017"
      },
      {
        "empcode": "ADEOL01",
        "fname": "Adeyemi",      
        "lname": "Olubolade",
        "level": "7",
        "position": "Teacher",
        "basicpay": "35000",
        "allowance": "2200",
        "frequency": "Monthly",
        "paygroup": "Teachers",
        "payperiod": "Dec 2017"
      },
      {
        "empcode": "ADEOL01",
        "fname": "Adeyemi",      
        "lname": "Olubolade",
        "level": "7",
        "position": "Teacher",
        "basicpay": "35000",
        "allowance": "2200",
        "frequency": "Monthly",
        "paygroup": "Teachers",
        "payperiod": "Jan 2018"
      },
      {
        "empcode": "ADEOL01",
        "fname": "Adeyemi",      
        "lname": "Olubolade",
        "level": "7",
        "position": "Teacher",
        "basicpay": "35000",
        "allowance": "2200",
        "frequency": "Monthly",
        "paygroup": "Teachers",
        "payperiod": "Feb 2018"
      },
      {
        "empcode": "ADEOL01",
        "fname": "Adeyemi",      
        "lname": "Olubolade",
        "level": "7",
        "position": "Teacher",
        "basicpay": "35000",
        "allowance": "2200",
        "frequency": "Monthly",
        "paygroup": "Teachers",
        "payperiod": "Mar 2018"
      },
      {
        "empcode": "ADEOL01",
        "fname": "Adeyemi",      
        "lname": "Olubolade",
        "level": "7",
        "position": "Teacher",
        "basicpay": "35000",
        "allowance": "2200",
        "frequency": "Monthly",
        "paygroup": "Teachers",
        "payperiod": "Apr 2018"
      },
      {
        "empcode": "ADEOL01",
        "fname": "Adeyemi",      
        "lname": "Olubolade",
        "level": "7",
        "position": "Teacher",
        "basicpay": "35000",
        "allowance": "2200",
        "frequency": "Monthly",
        "paygroup": "Teachers",
        "payperiod": "May 2018"
      },
      {
        "empcode": "ADEOL01",
        "fname": "Adeyemi",      
        "lname": "Olubolade",
        "level": "7",
        "position": "Teacher",
        "basicpay": "35000",
        "allowance": "2200",
        "frequency": "Monthly",
        "paygroup": "Teachers",
        "payperiod": "Jun 2018"
      },
      {
        "empcode": "ADEOL01",
        "fname": "Adeyemi",      
        "lname": "Olubolade",
        "level": "7",
        "position": "Teacher",
        "basicpay": "35000",
        "allowance": "2200",
        "frequency": "Monthly",
        "paygroup": "Teachers",
        "payperiod": "Jul 2018"
      },
      {
        "empcode": "ADEOL01",
        "fname": "Adeyemi",      
        "lname": "Olubolade",
        "level": "7",
        "position": "Teacher",
        "basicpay": "35000",
        "allowance": "2200",
        "frequency": "Monthly",
        "paygroup": "Teachers",
        "payperiod": "Aug 2018"
      },
      {
        "empcode": "ADEOL01",
        "fname": "Adeyemi",      
        "lname": "Olubolade",
        "level": "7",
        "position": "Teacher",
        "basicpay": "35000",
        "allowance": "2200",
        "frequency": "Monthly",
        "paygroup": "Teachers",
        "payperiod": "Sep 2018"
      }
      // {
      //   "empcode": "NANC001",
      //   "fname": "Nancy",      
      //   "lname": "Aihigbe",
      //   "level": "8",
      //   "position": "Secretary",
      //   "basicpay": "26500",
      //   "allowance": "1620",
      //   "frequency": "Semi-Monthly",
      //   "paygroup": "Staff",
      //   "payperiod": "August 2018"
      // }
    ];
    this.tablename = 'payhistory';
  }

}
