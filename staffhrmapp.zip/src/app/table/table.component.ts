import { Component, OnInit, Input } from '@angular/core';
// import { DataService } from '../services/data.service';
import { StudentdetailComponent } from '../studentdetail/studentdetail.component';
import { DialogService } from "ng2-bootstrap-modal";
import * as _ from 'underscore';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-table',
  // providers: [DataService],
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent implements OnInit {  
  @Input() staffs;
  pagecount: number = 20;
  pages: number = 0;
  pagelist: any[] = [];
  teachers: number = 0;  
  actives: number = 0;
  inactives: number = 0;
  dstaffs: any[];
  done:boolean = false;

  constructor(private dialogService:DialogService) {}

  ngOnInit() {
    this.check();
  }

  getData() {
    if(this.staffs) {
      this.done = true;
    }
    this.pages = Math.floor(this.staffs.length/this.pagecount) + 1;
    for(var e=0;e<this.pages;e++) {
      if(e==0) { 
        this.pagelist.push({issel: "active", val: e+1});
      } else {
        this.pagelist.push({issel: "", val: e+1});
      }
    }
    this.dstaffs = _.first(this.staffs, this.pagecount);
    this.teachers = this.staffs.filter(e => { if(e.position === 'Teacher') return e; }).length;
    this.actives = this.staffs.filter(e => { if(e.position === 'Teacher') return e; }).length;
    this.inactives = this.staffs.filter(e => { if(e.position === 'Teacher') return e; }).length;
    console.log('this.staffss...', this.staffs)
    console.log('this.dstaffss...', this.dstaffs)
    console.log('this.teachers...', this.teachers)
  }

  check() {
    Observable.interval(1000)
    .takeWhile(() =>! this.done)
    .subscribe(i => { 
        this.getData();
    })

  }

  showStudentProfile(indx): void {
    console.log("Staff with index:" + indx + " clicked!");
    let disposable = this.dialogService.addDialog(StudentdetailComponent, {
                    staffid: this.teachers,
                    title:'Staff Detail',
                    message:'Confirm message'})
      .subscribe((isConfirmed)=>{
          if(isConfirmed) {
              console.log('OK button clicked!');
          }
          else {
              console.log('Close button clicked!');
          }
      });
  }

  tabbed(vl): void {
    // console.log('vl is:' + vl);
    this.dstaffs = [];
    for(var e=(vl*this.pagecount);e<((vl+1)*this.pagecount);e++) {
      if(e>this.staffs.length - 1){

      } else {
        this.dstaffs.push(this.staffs[e]);
      }
    }
    for(var f=0;f<this.pages;f++)
      if(f == vl) {
        this.pagelist[f].issel = 'active';
      } else {
        this.pagelist[f].issel = '';
      }
  }

}
