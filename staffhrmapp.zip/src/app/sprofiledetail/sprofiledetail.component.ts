import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sprofiledetail',
  templateUrl: './sprofiledetail.component.html',
  styleUrls: ['./sprofiledetail.component.css']
})
export class SprofiledetailComponent implements OnInit {

  fmenabled:string = '';

  constructor() { }

  ngOnInit() {
  }

  editstaffprofile() {
    console.log('editstaffprofile called...');
  }

  savestaffprofile() {
    console.log('savestaffprofile called...');
  }

}
