import { Component, OnInit } from '@angular/core';
import { Meta, Title } from "@angular/platform-browser";
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule }  from '@angular/forms';
import { DataService } from '../services/data.service';
import { AuthenticationService } from '../services/authentication.service';
import { ActivatedRoute, Router, Params} from '@angular/router';

// import { Workshop } from '../model/workshop';

@Component({
  selector: 'app-mainboard',
  templateUrl: './mainboard.component.html',
  styleUrls: ['./mainboard.component.css'],
  providers: [DataService, AuthenticationService]
})
export class MainboardComponent implements OnInit {

  constructor(private router: Router,
              private dataSvc: DataService,
              private authenticationService: AuthenticationService,
              private route: ActivatedRoute,
              private meta: Meta,
              private title: Title) {

    title.setTitle("Portalworks StaffHRM");
    meta.addTags([
      {
        name: 'name', content: 'Portalworks StaffHRM'
      },
      {
        name: 'keywords', content: 'Portalworks, StaffHRM'
      },
      {
        name: 'description', content: 'Portalworks StaffHRM - Staff Records Management System'
      },
      {
        name: 'viewport', content: 'width=device-width, initial-scale=1.0'
      }
    ]);
  }

  ngOnInit() {
  }

  goToLanding(): void {
    // this.router.navigate(['/detail', this.selectedHero.id]);
    this.router.navigate(['/landing']);
  }
  
  staffview(): void {
    this.router.navigate(['/landing']);
  }
  newstaff(): void {
    this.router.navigate(['/new']);
  }
  staffprofile(): void {
    this.router.navigate(['/staff']);
  }
  classview(): void {
    this.router.navigate(['/class']);
    // this.router.navigate(['/class/'+ this.classid]);
  }
  qualifications(): void {
    this.router.navigate(['/qualifications']);
  }
  activities(): void {
    this.router.navigate(['/activity']);
  }
  support(): void {
    this.router.navigate(['/support']);
  }
  configurator(): void {
    this.router.navigate(['/configurator']);
  }

}
