import { Component, OnInit } from '@angular/core';
import { DialogComponent, DialogService } from "ng2-bootstrap-modal";
import { DataService } from '../services/data.service';

export interface NoticemodalModel {
  boardid:string;
  date:string;
  expirydate:string;
  groupsconcerned:any[];
  issuer:string;
  notes:any[];
  status:string;
}

@Component({
  selector: 'app-noticemodal',
  providers: [DataService],
  templateUrl: './noticemodal.component.html',
  styleUrls: ['./noticemodal.component.css']
})
export class NoticemodalComponent extends DialogComponent<NoticemodalModel, boolean> implements OnInit, NoticemodalModel {
  title:string = "Notice Creation";
  
  boardid:string;
  date:string;
  expirydate:string;
  groupsconcerned:any[];
  issuer:string;
  notes:any[];
  status:string;

  constructor(dialogService: DialogService, private service: DataService) {
    super(dialogService);
  }

  ngOnInit() {
    if(this.service.noticeType === 'Edit') {
      this.getNoticeDetailById(this.service.boardid);
    }    
  }

  private getNoticeDetailById(boardid: string) {
    return {
      "boardid": boardid,
      "date": "string",
      "expirydate": "string",
      "groupsconcerned": [],
      "issuer": "string",
      "notes": [],
      "status": "string"
    };
  }

  confirm() {
    this.result = true;
    this.close();
  }

  cancel() {
    this.close();
  }

}
