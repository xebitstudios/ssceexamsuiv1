import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NoticemodalComponent } from './noticemodal.component';

describe('NoticemodalComponent', () => {
  let component: NoticemodalComponent;
  let fixture: ComponentFixture<NoticemodalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NoticemodalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NoticemodalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
