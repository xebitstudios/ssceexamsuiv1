import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
 
import { LoginComponent } from './login/login.component';
import { MainboardComponent } from './mainboard/mainboard.component';
import { NewComponent } from './new/new.component';
import { StaffComponent } from './staff/staff.component';
import { ClassComponent } from './class/class.component';
import { ScoresComponent } from './scores/scores.component';
import { ActivityComponent } from './activity/activity.component';
import { SupportComponent } from './support/support.component';
import { LandingComponent } from './landing/landing.component';
import { ConfiguratorComponent } from './configurator/configurator.component';
 
const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'mainboard', component: MainboardComponent },
  { path: 'landing', component: LandingComponent },
  { path: 'new', component: NewComponent },
  { path: 'staff', component: StaffComponent },
  { path: 'class', component: ClassComponent },
  { path: 'qualifications', component: ScoresComponent },
  { path: 'activity', component: ActivityComponent },
  { path: 'support', component: SupportComponent },
  { path: 'configurator', component: ConfiguratorComponent },
  { path: '**', component: LoginComponent }
];
 
@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule {}