import { Component, OnInit } from '@angular/core';
import { DataService } from '../services/data.service';
// import { Observable } from 'rxjs';

@Component({
  selector: 'app-landing',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.css'],
  providers: [DataService]
})
export class LandingComponent implements OnInit {
  staffs: any[] = [];
  columns: string[] = [
    "firstname",
    "Gender",
    "Status",
    "Class",
    "Positio",
    "Employ Date"
  ]

  constructor(
    private dataService: DataService
  ) {
    this.getStaff();
  }

  ngOnInit() {
  }

  getStaff() {
    this.dataService.getStaff()
      .subscribe(res => {
        this.staffs = res;
        console.log('this.staffs...', this.staffs);
      }); 
  }

}
