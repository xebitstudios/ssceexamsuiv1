import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TablelistrowComponent } from './tablelistrow.component';

describe('TablelistrowComponent', () => {
  let component: TablelistrowComponent;
  let fixture: ComponentFixture<TablelistrowComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TablelistrowComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TablelistrowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
