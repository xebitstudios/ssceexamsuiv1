import { Component, OnInit } from '@angular/core';
import { DataService } from '../services/data.service';
import { StudentdetailComponent } from '../studentdetail/studentdetail.component';
import { DialogService } from "ng2-bootstrap-modal";
import * as _ from 'underscore';

@Component({
  selector: 'app-stable',
  providers: [DataService],
  templateUrl: './stable.component.html',
  styleUrls: ['./stable.component.css']
})
export class StableComponent implements OnInit {

  pagecount: number = 15;
  pages: number = 0;
  pagelist: any[] = [];
  staffid: number;  
  staffs: any[] = [
    {
      "schoolid": "SCH1", 
      "ischeck": false,
      "firstname": "Daniel",
      "middlename": "O",
      "lastname": "David",
      "gender": "M",
      "status": "Active",
      "employmentdate": "07/07/2013",
      "position": "Teacher",
      "dob": "07/03/1990",
      "terminationdate": "",
      "homeaddress": "4 Adetoro Famuyi street, Sokoto",
      "parents": "Mr and Mrs David",
      "state": "Sokoto",
      "classassigned": "JSS 2A",
      "email": "danieloye@yahoo.com",
      "phone": "09023108749",
      "salary": "65000",
      "notes": "he is a long serving teacher and has been teaching for over 6 years",
      "qualification": "OND Holder"
    },
    {
      "schoolid": "SCH1", 
      "ischeck": false,
      "firstname": "Fathia",
      "middlename": "S",
      "lastname": "Balogun",
      "gender": "F",
      "status": "Active",
      "employmentdate": "01/11/2003",
      "position": "Teacher",
      "dob": "30/03/1988",
      "terminationdate": "",
      "homeaddress": "12 Wereke road, Binincity",
      "parents": "Mr and Mrs Balogun",
      "state": "Edo",
      "classassigned": "JSS 3",
      "email": "fathiab@gmail.com",
      "phone": "09045220682",
      "salary": "45000",
      "notes": "she won the district teacher of the year 2015",
      "qualification": "OND Holder"
    },
    {
      "schoolid": "SCH1", 
      "ischeck": false,
      "firstname": "Opeyemi",
      "middlename": "M",
      "lastname": "Olaiya",
      "gender": "F",
      "status": "Active",
      "employmentdate": "21/07/2010",
      "position": "Teacher",
      "dob": "19/04/1980",
      "terminationdate": "",
      "homeaddress": "22 Onwame road, Benincity",
      "parents": "Mr and Mrs Olaiya",
      "state": "Sokoto",
      "classassigned": "SSS 2",
      "email": "olaiya23@yahoo.com",
      "phone": "08023406708",
      "salary": "40000",
      "notes": "he is very effective with 20 years teaching experience",
      "qualification": "OND Holder"
    },
    {
      "schoolid": "SCH1", 
      "ischeck": false,
      "firstname": "Omowunmi",
      "middlename": "L",
      "lastname": "Ojo",
      "gender": "F",
      "status": "Active",
      "employmentdate": "30/09/2011",
      "position": "Teacher",
      "dob": "15/06/1987",
      "terminationdate": "",
      "homeaddress": "34 Batakarawa road, Kaduna",
      "parents": "Mr and Mrs Ojo",
      "state": "Kaduna",
      "classassigned": "SSS 1",
      "email": "ojo4life@yahoo.com",
      "phone": "07054389017",
      "salary": "52000",
      "notes": "shes very friendly and loved by all students",
      "qualification": "HND Holder"
    }
  ]
  dstaffs: any[] = []
  
  constructor(private service: DataService,
              private dialogService:DialogService) { }

  ngOnInit() {
    this.pages = Math.floor(this.staffs.length/this.pagecount) + 1;
    for(var e=0;e<this.pages;e++) {
      if(e==0) { 
        this.pagelist.push({issel: "active", val: e+1});
      } else {
        this.pagelist.push({issel: "", val: e+1});
      }
    }
    this.dstaffs = _.first(this.staffs, this.pagecount);
  }

  showStudentProfile(indx): void {
    console.log("Staff with index:" + indx + " clicked!");
    let disposable = this.dialogService.addDialog(StudentdetailComponent, {
                    staffid: this.staffid,
                    title:'Staff Detail',
                    message:'Confirm message'})
      .subscribe((isConfirmed)=>{
          //We get dialog result
          if(isConfirmed) {
              //console.log('OK button clicked!');
          }
          else {
              //console.log('Close button clicked!');
          }
      });
  }

  tabbed(vl): void {
    // console.log('vl is:' + vl);
    this.dstaffs = [];
    for(var e=(vl*this.pagecount);e<((vl+1)*this.pagecount);e++) {
      if(e>this.staffs.length - 1){

      } else {
        this.dstaffs.push(this.staffs[e]);
      }
    }
    for(var f=0;f<this.pages;f++)
      if(f == vl) {
        this.pagelist[f].issel = 'active';
      } else {
        this.pagelist[f].issel = '';
      }
  }

}
