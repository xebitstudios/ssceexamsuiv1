import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute, Router, Params} from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  showMenu:string = 'hide';
  @Input() tab: string;
  tabArray: any[] = [];
  staffid: number;
  classid: number;

  constructor(private router: Router,
              private route: ActivatedRoute) {
    // this.route.params.subscribe( params => console.log(params) );
  }

  ngOnInit() {
    console.log('tab is: ' + this.tab);
    this.tabArray = ['','','','','','','',''];
    this.tabArray[parseInt(this.tab) - 1] = 'active';
    if(window.outerWidth > 400) {
      this.showMenu = '';
    }
  }

  toggleMenu() {
    if(window.outerWidth > 400) {
      this.showMenu = '';
    } else {
      if(this.showMenu === 'hide') {
        this.showMenu = '';
      } else {
        this.showMenu = 'hide';
      }
    }
  }

  logout(): void {
    this.router.navigate(['/login']);
  }

  schoollab(): void {
    this.router.navigate(['/mainboard']);
  }
  board(): void {
    this.router.navigate(['/landing']);
  }
  newstaff(): void {
    this.router.navigate(['/new']);
  }
  profile(): void {
    this.router.navigate(['/staff']);
  }
  classs(): void {
    this.router.navigate(['/class']);
    // this.router.navigate(['/class/'+ this.classid]);
  }
  tests(): void {
    this.router.navigate(['/qualifications']);
  }
  activity(): void {
    this.router.navigate(['/activity']);
  }
  support(): void {
    this.router.navigate(['/support']);
  }
  configurator(): void {
    this.router.navigate(['/configurator']);
  }

}
