(function() {
    'use strict';

    angular
        .module('ssceexamsuiApp')
        .controller('SscelitinengbtemplateController', SscelitinengbtemplateController);

    // SscelitinengbtemplateController.$inject = ['$scope', '$log', '$location', '$controller', '$rootScope', 'DataStore', 'ConfigService', 'HeaderService', 'ApiService', 'TimerService', 'growl', '$timeout'];

    /* @ngInject */
    function SscelitinengbtemplateController($scope, $log, $location, $controller, $rootScope, ConfigService, DataStore, HeaderService, ApiService, TimerService, growl, $timeout, LoggingService) {

        $controller('BaseController', {$scope: $scope});
        $rootScope.baseRoute = '';
        $scope.mins = '120';
        console.log("$rootScope.yr: " + $rootScope.yr);
        console.log("$scope.mins: " + $scope.mins);
        $scope.exmid = 'liteng_B';
        $scope.seloption = '';
        var baseRoute = '';

        $scope.themodal = {
            modalShown: false
        };

        $scope.passed = 0;
        $scope.wrong = 0;
        $scope.skipped = 0;
        $scope.skippedArray = [];
        $scope.totqstlength = 0;

        $scope.intab = function() {
            LoggingService.postTrack("litengtmpl");
            console.log('Now in the SSCE LitInEnglish_B Template page!');
        };

        $scope.intab();

        $timeout(function(){
           HeaderService.setTab(1);
        }, 100);

        $scope.toggleModal = function(val) {
            console.log('$scope.toggleModal called.');
            (val == 1) ? ($scope.themodal.modalShown = !$scope.themodal.modalShown) : (console.log('modal not selected!'));
            $scope.logscope();
        };

        $scope.logscope = function() {
            console.log('$scope.qtt is: ');
            console.log($scope.qtt);
        };

        $scope.gotoTC = function() {
            LoggingService.postTrack("liteng-tc");
            $scope.resultsShow();
            $scope.themodal.modalShown = false;
            // $location.path(baseRoute + 'testcenter');
        };

        $scope.getSave = function() {
            LoggingService.postTrack("liteng-save");
            $scope.logscope();
            console.log('Save button was clicked!!!');
            console.log($scope.qtt);
            console.log($scope.qtt.SA.P1);
            console.log($scope.qtt.SA.P2);
            console.log($scope.qtt.SB.P1);
            console.log($scope.qtt.SB.P2);
            console.log($scope.qtt.SB.P3);
            console.log($scope.qtt.SB.P4);
            // $scope.qqt.Qval = _.keys($scope.qtt).length;
            // $scope.qqt.Q = _.values($scope.qtt)[_.keys($scope.qtt).length - 1];
            // console.log($scope.qqt.Qval);
            // console.log($scope.qqt.Q);
            var qArry = "";
            console.log('_.values($scope.qtt) is: ');
            // console.log(_.values($scope.qtt).sel);
            _.each(_.values($scope.qtt.SA.P1), function(obj) {
                if(obj.sel != "") {
                    qArry = qArry + obj.sel;
                } else {
                    qArry = qArry + "Z";
                }                
            });
            qArry = qArry + "X";
            _.each(_.values($scope.qtt.SA.P2), function(obj) {
                if(obj.sel != "") {
                    qArry = qArry + obj.sel;
                } else {
                    qArry = qArry + "Z";
                }                
            });
            qArry = qArry + "X";
            _.each(_.values($scope.qtt.SB.P1), function(obj) {
                if(obj.sel != "") {
                    qArry = qArry + obj.sel;
                } else {
                    qArry = qArry + "Z";
                }                
            });
            qArry = qArry + "X";
            _.each(_.values($scope.qtt.SB.P2), function(obj) {
                if(obj.sel != "") {
                    qArry = qArry + obj.sel;
                } else {
                    qArry = qArry + "Z";
                }                
            });
            qArry = qArry + "X";
            _.each(_.values($scope.qtt.SB.P3), function(obj) {
                if(obj.sel != "") {
                    qArry = qArry + obj.sel;
                } else {
                    qArry = qArry + "Z";
                }                
            });
            qArry = qArry + "X";
            _.each(_.values($scope.qtt.SB.P4), function(obj) {
                if(obj.sel != "") {
                    qArry = qArry + obj.sel;
                } else {
                    qArry = qArry + "Z";
                }                
            });
            // Save the current exam state to localStorage
            DataStore.setSavedExam($rootScope.userid, {
                tmlft: TimerService.getTL($scope.oldtime, $scope.totaltimemins),
                exmid: $scope.exmid,
                examyear: $scope.examyear,
                dt: Date().split('(')[0],
                qArry: qArry
            });
            // $scope.moveSetTime();
        };

        $scope.getFinish = function() {
            LoggingService.postTrack("liteng-finsh");
            $scope.logscope();
            console.log('Finish button was clicked!!!');
        };

        $scope.getContinue = function() {
            LoggingService.postTrack("liteng-cnte");
            $scope.logscope();
            console.log('Continue button was clicked!!!');
        };

        $scope.getPause = function() {
            LoggingService.postTrack("liteng-pause");
            $scope.logscope();
            console.log('Pause button was clicked!!!');
        };

        $scope.qstlength = function() {
            $scope.resultsShow();
            return $scope.totqstlength;
        };

        $scope.resultsShow = function() {
            // console.log('$scope.qtt is now: ');
            // console.log($scope.qtt);
            $scope.totSAP1qstlength = _.keys($scope.qtt.SA.P1).length;
            $scope.totSAP2qstlength = _.keys($scope.qtt.SA.P2).length;
            $scope.totSAqstlength = $scope.totSAP1qstlength + $scope.totSAP2qstlength;
            $scope.totSBP1qstlength = _.keys($scope.qtt.SB.P1).length;
            $scope.totSBP2qstlength = _.keys($scope.qtt.SB.P2).length;
            $scope.totSBP3qstlength = _.keys($scope.qtt.SB.P3).length;
            $scope.totSBP4qstlength = _.keys($scope.qtt.SB.P4).length;
            $scope.totSBqstlength = $scope.totSBP1qstlength + $scope.totSBP2qstlength + $scope.totSBP3qstlength + $scope.totSBP4qstlength;
            $scope.totqstlength = $scope.totSAqstlength + $scope.totSBqstlength;
            // console.log('$scope.totqstlength is: ' + $scope.totqstlength);
        };

        $scope.getSkippedArray = function() {
            LoggingService.postTrack("liteng-skparry");
            return $scope.skippedArray.join(',');
        };

        $scope.goToQstt = function(indx, val) {
            // console.log('val is now: ' + val);
            $scope.dsection = val.split('.')[0];
            $scope.dpart = val.split('.')[1];
            $scope.dquestion = val.split('.')[2];
            console.log($scope.dsection);
            console.log($scope.dpart);
            console.log($scope.dquestion);
            if($scope.dsection == "S0"){
                if($scope.dpart == "P0") {
                    $scope.sectionclick('Section 1 - Part 1');
                    $scope.sctn1PassaObjNum = $scope.dquestion.substr(1);
                    $scope.sctn1PassaObjNum = $scope.sctn1PassaObjNum + 1;
                    $scope.sctn1PassaObj = _.values(_.values(_.values($scope.qtt)[0])[0])[$scope.dquestion.substr(1)];
                    $scope.qqt = {
                        "qstarray": {},
                        "qstlist": (_.values(_.values($scope.qtt)[0])[0])
                    };
                    $scope.qtlength = _.keys($scope.qqt.qstlist).length;
                    $scope.setToZero();
                    for(var nn = 0; nn < $scope.dquestion.substr(1);nn++) {
                        $scope.getNext();
                    }
                    LoggingService.compTrack("liteng-finsh");
                    $scope.toggleModal(1);
                }
                else if($scope.dpart == "P1") {
                    $scope.sectionclick('Section 1 - Part 2');
                    $scope.sctn1PassaObjNum = $scope.dquestion.substr(1);
                    $scope.sctn1PassaObjNum = $scope.sctn1PassaObjNum + 1;
                    $scope.sctn1PassaObj = _.values(_.values(_.values($scope.qtt)[0])[1])[$scope.dquestion.substr(1)];
                    $scope.qqt = {
                        "qstarray": {},
                        "qstlist": (_.values(_.values($scope.qtt)[0])[1])
                    };
                    $scope.qtlength = _.keys($scope.qqt.qstlist).length;
                    $scope.setToZero();
                    for(var nn = 0; nn < $scope.dquestion.substr(1);nn++) {
                        $scope.getNext();
                    }
                    LoggingService.compTrack("liteng-finsh");
                    $scope.toggleModal(1);
                }
                else if($scope.dpart == "P2") {
                    $scope.sectionclick('Section 1 - Part 3');
                    $scope.sctn1PassaObjNum = $scope.dquestion.substr(1);
                    $scope.sctn1PassaObjNum = $scope.sctn1PassaObjNum + 1;
                    $scope.sctn1PassaObj = _.values(_.values(_.values($scope.qtt)[0])[2])[$scope.dquestion.substr(1)];
                    $scope.qqt = {
                        "qstarray": {},
                        "qstlist": (_.values(_.values($scope.qtt)[0])[2])
                    };
                    $scope.qtlength = _.keys($scope.qqt.qstlist).length;
                    $scope.setToZero();
                    for(var nn = 0; nn < $scope.dquestion.substr(1);nn++) {
                        $scope.getNext();
                    }
                    LoggingService.compTrack("liteng-finsh");
                    $scope.toggleModal(1);
                }
            }
            else if($scope.dsection == "S1"){
                if($scope.dpart == "P0") {
                    $scope.sectionclick('Section 2 - Part 1');
                    $scope.sctn1PassaObjNum = $scope.dquestion.substr(1);
                    $scope.sctn1PassaObjNum = $scope.sctn1PassaObjNum + 1;
                    $scope.sctn1PassaObj = _.values(_.values(_.values($scope.qtt)[1])[0])[$scope.dquestion.substr(1)];
                    $scope.qqt = {
                        "qstarray": {},
                        "qstlist": (_.values(_.values($scope.qtt)[1])[0])
                    };
                    $scope.qtlength = _.keys($scope.qqt.qstlist).length;
                    $scope.setToZero();
                    for(var nn = 0; nn < $scope.dquestion.substr(1);nn++) {
                        $scope.getNext();
                    }
                    LoggingService.compTrack("liteng-finsh");
                    $scope.toggleModal(1);
                }
                else if($scope.dpart == "P1") {
                    $scope.sectionclick('Section 2 - Part 2');
                    $scope.sctn1PassaObjNum = $scope.dquestion.substr(1);
                    $scope.sctn1PassaObjNum = $scope.sctn1PassaObjNum + 1;
                    $scope.sctn1PassaObj = _.values(_.values(_.values($scope.qtt)[1])[1])[$scope.dquestion.substr(1)];
                    $scope.qqt = {
                        "qstarray": {},
                        "qstlist": (_.values(_.values($scope.qtt)[1])[1])
                    };
                    $scope.qtlength = _.keys($scope.qqt.qstlist).length;
                    $scope.setToZero();
                    for(var nn = 0; nn < $scope.dquestion.substr(1);nn++) {
                        $scope.getNext();
                    }
                    LoggingService.compTrack("liteng-finsh");
                    $scope.toggleModal(1);
                }
                else if($scope.dpart == "P2") {
                    $scope.sectionclick('Section 2 - Part 3');
                    $scope.sctn1PassaObjNum = $scope.dquestion.substr(1);
                    $scope.sctn1PassaObjNum = $scope.sctn1PassaObjNum + 1;
                    $scope.sctn1PassaObj = _.values(_.values(_.values($scope.qtt)[1])[2])[$scope.dquestion.substr(1)];
                    $scope.qqt = {
                        "qstarray": {},
                        "qstlist": (_.values(_.values($scope.qtt)[1])[2])
                    };
                    $scope.qtlength = _.keys($scope.qqt.qstlist).length;
                    $scope.setToZero();
                    for(var nn = 0; nn < $scope.dquestion.substr(1);nn++) {
                        $scope.getNext();
                    }
                    LoggingService.compTrack("liteng-finsh");
                    $scope.toggleModal(1);
                }
                else if($scope.dpart == "P3") {
                    $scope.sectionclick('Section 2 - Part 4');
                    $scope.sctn1PassaObjNum = $scope.dquestion.substr(1);
                    $scope.sctn1PassaObjNum = $scope.sctn1PassaObjNum + 1;
                    $scope.sctn1PassaObj = _.values(_.values(_.values($scope.qtt)[1])[3])[$scope.dquestion.substr(1)];
                    $scope.qqt = {
                        "qstarray": {},
                        "qstlist": (_.values(_.values($scope.qtt)[1])[3])
                    };
                    $scope.qtlength = _.keys($scope.qqt.qstlist).length;
                    $scope.setToZero();
                    for(var nn = 0; nn < $scope.dquestion.substr(1);nn++) {
                        $scope.getNext();
                    }
                    LoggingService.compTrack("liteng-finsh");
                    $scope.toggleModal(1);
                }
            }
        };

        $scope.getpassed = function() {
            // LoggingService.postTrack("liteng-gtpssd");
            $scope.passed = 0;
            $scope.wrong = 0;
            $scope.skipped = 0;
            $scope.skippedArray = [];
            for(var k=0;k<_.keys($scope.qtt).length;k++) {
                // console.log(_.keys(_.values($scope.qtt)[k]).length);
                for(var j=0;j<_.keys(_.values($scope.qtt)[k]).length;j++) {
                    // console.log(_.keys($scope.qtt.SA.P1).length);
                    for(var i=0;i<_.keys(_.values(_.values($scope.qtt)[k])[j]).length;i++) {
                        // console.log("k: " + k + ", j: " + j + ", i: " + i);
                        $scope.vall = i+1;
                        // console.log("ans: " + _.values(_.values(_.values($scope.qtt)[k])[j])[i].ans);
                        // console.log("sel: " + _.values(_.values(_.values($scope.qtt)[k])[j])[i].sel);
                        if(_.values(_.values(_.values($scope.qtt)[k])[j])[i].sel == "") {
                            $scope.skipped = $scope.skipped + 1;
                            // console.log("Pushing into skippedArray - Q: " + $scope.vall);
                            $scope.skippedArray.push("S" + k + ".P" + j + ".Q" + $scope.vall + "");
                            // console.log("k: " + k + ", j: " + j + ", i: " + i + " - skipped");
                        } else if(_.values(_.values(_.values($scope.qtt)[k])[j])[i].ans == _.values(_.values(_.values($scope.qtt)[k])[j])[i].sel) {
                            $scope.passed = $scope.passed + 1;
                            // console.log("k: " + k + ", j: " + j + ", i: " + i + " - passed");
                        } else {
                            $scope.wrong = $scope.wrong + 1;
                            // console.log("k: " + k + ", j: " + j + ", i: " + i + " - wrong");
                        }
                    }
                }
            }
            // console.log("$scope.skippedArray is: ");
            // console.log($scope.skippedArray);

            return $scope.passed;
        };

        $scope.getpctscore = function() {
            if(($scope.wrong == 0) & ($scope.passed === 0)) { return 0; }
            return (($scope.passed/($scope.passed + $scope.wrong)) * 100).toFixed(2);
        };

        $scope.dresults = {
            correct: 0,
            wrong: 0,
            ishide: 'hide',
            hidebtn1: ''
        };

        $scope.seeresults = function() {
            LoggingService.postTrack("liteng-seersult");
            console.log('$scope.seeresults clicked!');
            $scope.dresults.correct = 36;
            $scope.dresults.wrong = 24;
            $scope.dresults.ishide = '';
            $scope.hidebtn1 = 'hide';
            $scope.hidebtn2 = '';
            $scope.dskipped.ishide = 'hide';
        };

        $scope.viewskipped = function() {
            LoggingService.postTrack("liteng-skipd");
            console.log('$scope.viewskipped clicked!');
            $scope.dskipped.ishide = '';
            $scope.dskipped.arry = [3, 14, 48];
            $scope.hidebtn1 = '';
            $scope.dresults.ishide = 'hide';
            $scope.hidebtn2 = 'hide';
        };

        $scope.restart = function() {
            LoggingService.postTrack("liteng-rstrt");
            console.log('$scope.restart clicked!');
        };

        $scope.dskipped = {
            ishide: 'hide',
            arry: []
        };

        $scope.pctused = 0;
        $scope.totaltimemins = parseInt($scope.mins);
        $scope.timegone = '0 hrs 0 mins 0 secs';
        $scope.timeleft = ' hrs ' + $scope.mins + ' mins 0 secs';
        $scope.activeNav = 'Start';
        $scope.oldtime = 0;
        $scope.lefttime = 0;
        $scope.examyear = $rootScope.litineng_selected_year;
        $scope.qtlength = 0;
        $scope.qstindx = 0;

        $scope.getStartTime = function() {
            $scope.oldtime = new Date().getTime();
            console.log('start time is: ' + $scope.oldtime);
        };

        $scope.getStartTime();

        $scope.btnsList = _.pluck(_.values($scope.navbtns), 'title');

        $scope.getNum = function() {
            return $scope.sctn1PassaObjNum;
        };

        $scope.setNum = function(val) {
            $scope.qqt.Qval = val;
        };

        $scope.clearImg = function() {
            $scope.qqt.Q.img = "";
        };

        $scope.colorBorder = function(sectn, qst, opt, reslt) {
            $scope.clearAll(sectn, qst);
            if($rootScope.rtscore) {
                // remove all the border colors on all options
                // $("#a_liteng_" + sectn + '_' + qst + "_" + opt).removeClass('redborder');
                // $("#a_liteng_" + sectn + '_' + qst + "_" + opt).removeClass('greenborder');
                // now set the specific border on the option selected
                console.log("#a_liteng_" + sectn + '_q' + qst + "_opt" + opt + ": #a_liteng_" + sectn + '_q' + qst + "_opt" + opt);
                if(reslt==true) {
                    $("#a_liteng_" + sectn + '_' + qst + "_" + opt).addClass('greenborder');
                } else {
                    $("#a_liteng_" + sectn + '_' + qst + "_" + opt).addClass('redborder');
                }
            }
        };

        $scope.clearAll = function(sectn, qst) {
            // $(".div_liteng_" + qst + " p input").prop("checked", false);
            $(".div_liteng_" + qst + " p").removeClass('redborder');
            $(".div_liteng_" + qst + " p").removeClass('greenborder');
        };

        $scope.clearOptions = function(qst) {
            $(".div_liteng_" + qst + " p input").prop("checked", false);
            $(".div_liteng_" + qst + " p").removeClass('redborder');
            $(".div_liteng_" + qst + " p").removeClass('greenborder');
        };

        $scope.optClick = function(sectn, qnum, selopt) {
            $scope.seloption = selopt;
            // console.log('element ID is: ' + 'bio' + "_" + val1 + "_" + val2);
            // console.log('qst is: ' + val1 + ', opt is: ' + val2);
            console.log('Section/Part: ' + sectn + ', Question Num: ' + qnum + ', Selected Option: ' + selopt);
            // $scope.checkSel(1);
            // if((_.values($scope.sctn1PassaObj))[0].ans == (_.values($scope.sctn1PassaObj))[0].sel) {
            //     $scope.colorBorder(sectn, qnum, selopt, false);
            // } else {
            //     $scope.colorBorder(sectn, qnum, selopt, true);
            // }
            $scope.selClickedOption(selopt);
        };

        $scope.selClickedOption = function(val2) {
            if(val2==0) { 
                console.log('checkbox A clicked!');
                (_.values($scope.sctn1PassaObj))[0].sel = 'A';
                if((_.values($scope.sctn1PassaObj))[0].ans == 'A') {
                    $scope.colorBorder($scope.getSection(), $scope.getNum(), val2, true);
                } else {
                    // $scope.colorBorder(val1, val2, false);
                    $scope.colorBorder($scope.getSection(), $scope.getNum(), val2, false);
                }
            }
            else if(val2==1) { 
                console.log('checkbox B clicked!');
                (_.values($scope.sctn1PassaObj))[0].sel = 'B';
                if((_.values($scope.sctn1PassaObj))[0].ans == 'B') {
                    // $scope.colorBorder(val1, val2, true);
                    $scope.colorBorder($scope.getSection(), $scope.getNum(), val2, true);
                } else {
                    // $scope.colorBorder(val1, val2, false);
                    $scope.colorBorder($scope.getSection(), $scope.getNum(), val2, false);
                }
            }
            else if(val2==2) { 
                console.log('checkbox C clicked!');
                (_.values($scope.sctn1PassaObj))[0].sel = 'C';
                if((_.values($scope.sctn1PassaObj))[0].ans == 'C') {
                    // $scope.colorBorder(val1, val2, true);
                    $scope.colorBorder($scope.getSection(), $scope.getNum(), val2, true);
                } else {
                    // $scope.colorBorder(val1, val2, false);
                    $scope.colorBorder($scope.getSection(), $scope.getNum(), val2, false);
                }
            }
            else if(val2==3) { 
                console.log('checkbox D clicked!');
                (_.values($scope.sctn1PassaObj))[0].sel = 'D';
                if((_.values($scope.sctn1PassaObj))[0].ans == 'D') {
                    // $scope.colorBorder(val1, val2, true);
                    $scope.colorBorder($scope.getSection(), $scope.getNum(), val2, true);
                } else {
                    // $scope.colorBorder(val1, val2, false);
                    $scope.colorBorder($scope.getSection(), $scope.getNum(), val2, false);
                }
            }
            else if(val2==4) { 
                console.log('checkbox E clicked!');
                (_.values($scope.sctn1PassaObj))[0].sel = 'E';
                if((_.values($scope.sctn1PassaObj))[0].ans == 'E') {
                    // $scope.colorBorder(val1, val2, true);
                    $scope.colorBorder($scope.getSection(), $scope.getNum(), val2, true);
                } else {
                    // $scope.colorBorder(val1, val2, false);
                    $scope.colorBorder($scope.getSection(), $scope.getNum(), val2, false);
                }
            }
            else {}
        };

        $scope.checkSel = function(val) {
            // $scope.checkSel($scope.sctn1PassaObj);
            console.log("checking the options A...");
            console.log((_.values(val))[0]);
            console.log('$scope.getSection(): ' + $scope.getSection());
            console.log('$scope.getNum(): ' + $scope.getNum());
            console.log('#div_liteng_' + $scope.getSection() + '_q' + $scope.getNum() + '_opt0 p');
            $('.litengx p input').prop('checked', false);
            $('.litengx p').removeClass('redborder');
            $('.litengx p').removeClass('greenborder');

            if((_.values(val))[0].sel != "") {
                console.log("checking the options B...");
                console.log((_.values(val))[0]);
                if((_.values(val))[0].sel == "A") { 
                    console.log("A...");   
                    $('.litengx p:eq(0) input').prop('checked', true);               
                    if($rootScope.rtscore) {
                        if((_.values(val))[0].sel == (_.values(val))[0].ans) {
                            $('.litengx p:eq(0)').addClass('greenborder');
                        } else {
                            $('.litengx p:eq(0)').addClass('redborder');
                        }
                    }
                } else if((_.values(val))[0].sel == "B") { 
                    console.log("B...");
                    $('.litengx p:eq(1) input').prop('checked', true);               
                    if($rootScope.rtscore) {
                        if((_.values(val))[0].sel == (_.values(val))[0].ans) {
                            $('.litengx p:eq(1)').addClass('greenborder');
                        } else {
                            $('.litengx p:eq(1)').addClass('redborder');
                        }
                    }
                } else if((_.values(val))[0].sel == "C") { 
                    console.log("C...");
                    $('.litengx p:eq(2) input').prop('checked', true);               
                    if($rootScope.rtscore) {
                        if((_.values(val))[0].sel == (_.values(val))[0].ans) {
                            $('.litengx p:eq(2)').addClass('greenborder');
                        } else {
                            $('.litengx p:eq(2)').addClass('redborder');
                        }
                    }
                } else if((_.values(val))[0].sel == "D") { 
                    console.log("D...");
                    $('.litengx p:eq(3) input').prop('checked', true);               
                    if($rootScope.rtscore) {
                        if((_.values(val))[0].sel == (_.values(val))[0].ans) {
                            $('.litengx p:eq(3)').addClass('greenborder');
                        } else {
                            $('.litengx p:eq(3)').addClass('redborder');
                        }
                    }
                } else if((_.values(val))[0].sel == "E") { 
                    console.log("E...");
                    $('.litengx p:eq(4) input').prop('checked', true);               
                    if($rootScope.rtscore) {
                        if((_.values(val))[0].sel == (_.values(val))[0].ans) {
                            $('.litengx p:eq(4)').addClass('greenborder');
                        } else {
                            $('.litengx p:eq(4)').addClass('redborder');
                        }
                    }
                } else {}
            }
        };

        $scope.getNext = function() {
            LoggingService.postTrack("liteng-nxt");
            console.log('getting next question...');
            console.log('$scope.qtlength: ' + $scope.qtlength);
            console.log("$scope.sctn1PassaObjNum: " + $scope.sctn1PassaObjNum);
            console.log('calling $scope.setQst() now...');
            console.log();
            if($scope.qtlength > $scope.sctn1PassaObjNum+1) {
                $scope.sctn1PassaObjNum = $scope.sctn1PassaObjNum + 1;
                $scope.setQst();
                $scope.checkSel($scope.sctn1PassaObj);
                // $scope.moveSetTime();
            } else {
                console.log('You have completed the questions in this section!');
            }
        };

        $scope.getPrev = function() {
            LoggingService.postTrack("liteng-prv");
            if($scope.sctn1PassaObjNum > 0) {
                $scope.sctn1PassaObjNum = $scope.sctn1PassaObjNum - 1;
                $scope.setQst();
            } else {
                console.log('You have reached the first question in this section!');
            }
        };

        $scope.getFirst = function() {
            LoggingService.postTrack("liteng-fst");
            $scope.sctn1PassaObjNum = 0;
            $scope.setQst();
        };

        $scope.getLast = function() {
            LoggingService.postTrack("liteng-lst");
            $scope.sctn1PassaObjNum = $scope.qtlength - 1;
            $scope.setQst();
        };

        $scope.navclick = function(navtitle) {
            $scope.activeNav = navtitle;
        };

        $scope.getImage = function(val) {
            console.log('getImage val is: ' + val);
            if(val == undefined) return false;
            if(_.contains(val.split('**'), 'img')) { return true; };
            return false;
        };

        $scope.showImage = function(val) {
            console.log('showImage val is: ' + val);
            if(val == undefined) return false;
            if(val) {
                if(_.contains(val.split('**'), 'img')) {
                    return '/img/litineng/' + val.slice(3,val.length).split('**')[1];
                }
            }
            // if(_.contains(val.split('**'), 'img')) {
            //     return '/img/litineng/' + val.slice(3,val.length).split('**')[1];
            // }
            return '';
        };

        console.log('$rootScope.litineng_selected_year is A: ' + $rootScope.litineng_selected_year);
        $scope.qtt = {};

        $scope.setToZero = function() {
            $scope.sctn1PassaObjNum = 0;
            $scope.currentQst = 0;
            $scope.setQst();
        };
        $scope.dinstruction = 'Answer All questions in this section.';

        $scope.getSection = function() {
            console.log('SSS: ' + $scope.sectionHeader.replace('Section ', 's').replace('Part ', 'p').replace(' - ', ''));
            return $scope.sectionHeader.replace('Section ', 's').replace('Part ', 'p').replace(' - ', '');
        };

        $scope.sectionclick = function(val) {
            $scope.sectionHeader = val;
            $scope.markChosen(val);
            // console.log('val is: ' + val);
            if(val == 'Section 1 - Part 1') {
                console.log("$scope.qtt.SA.P1:~~~");
                console.log($scope.qtt.SA.P1);
                $scope.dinstruction = 'Answer All questions in this section.';
                $scope.qqt = {
                    "qstarray": $scope.qtt.SA.P1.qst,
                    "qstlist": _.omit($scope.qtt.SA.P1, 'qst')
                };
                $scope.qtlength = _.keys($scope.qqt.qstlist).length;
                console.log("$scope.qqt:~~~");
                console.log($scope.qqt);
                console.log("calling next $scope.setToZero():~~~");
                $scope.setToZero();
            } else if(val == 'Section 1 - Part 2') {
                console.log("$scope.qtt.SA.P2:~~~");
                console.log($scope.qtt.SA.P2);
                $scope.dinstruction = 'Answer All questions in this section.';
                $scope.qqt = {
                    "qstarray": $scope.qtt.SA.P2.qst,
                    "qstlist": _.omit($scope.qtt.SA.P2, 'qst')
                };
                $scope.qtlength = _.keys($scope.qqt.qstlist).length;
                $scope.setToZero();
            } else if(val == 'Section 2 - Part 1') {
                $scope.qqt = {
                    "qstarray": $scope.qtt.SB.P1.qst,
                    "qstlist": _.omit($scope.qtt.SB.P1, 'qst')
                };
                // $scope.dinstruction = $scope.qqt.qstarray;
                $scope.qtlength = _.keys($scope.qqt.qstlist).length;
                $scope.setToZero();
            } else if(val == 'Section 2 - Part 2') {
                $scope.qqt = {
                    "qstarray": $scope.qtt.SB.P2.qst,
                    "qstlist": _.omit($scope.qtt.SB.P2, 'qst')
                };
                // $scope.dinstruction = $scope.qqt.qstarray;
                $scope.qtlength = _.keys($scope.qqt.qstlist).length;
                $scope.setToZero();
            } else if(val == 'Section 2 - Part 3') {
                $scope.qqt = {
                    "qstarray": $scope.qtt.SB.P3.qst,
                    "qstlist": _.omit($scope.qtt.SB.P3, 'qst')
                };
                // $scope.dinstruction = $scope.qqt.qstarray;
                $scope.qtlength = _.keys($scope.qqt.qstlist).length;
                $scope.setToZero();
            } else if(val == 'Section 2 - Part 4') {
                $scope.qqt = {
                    "qstarray": $scope.qtt.SB.P4.qst,
                    "qstlist": _.omit($scope.qtt.SB.P4, 'qst')
                };
                // $scope.dinstruction = $scope.qqt.qstarray;
                $scope.qtlength = _.keys($scope.qqt.qstlist).length;
                $scope.setToZero();
            }
        };

        $scope.sectionHeader = 'Section 1 - Part 1';        
        // console.log('$scope.qtt is now: ');
        // console.log($scope.qtt);

        $scope.sectionslist = [
            {'val' : 'Section 1 - Part 1', 'ischosen': 'chosen'},
            {'val' : 'Section 1 - Part 2', 'ischosen': ''},
            {'val' : 'Section 2 - Part 1', 'ischosen': ''},
            {'val' : 'Section 2 - Part 2', 'ischosen': ''},
            {'val' : 'Section 2 - Part 3', 'ischosen': ''},
            {'val' : 'Section 2 - Part 4', 'ischosen': ''}
        ];

        $scope.markChosen = function(val) {
            for(var e=0;e<$scope.sectionslist.length;e++) {
                $scope.sectionslist[e].ischosen = '';
            }

            if(val == 'Section 1 - Part 1') {
                $scope.sectionslist[0].ischosen = 'chosen';
            } else if(val == 'Section 1 - Part 2') {
                $scope.sectionslist[1].ischosen = 'chosen';
            }
             else if(val == 'Section 2 - Part 1') {
                $scope.sectionslist[2].ischosen = 'chosen';
            }
             else if(val == 'Section 2 - Part 2') {
                $scope.sectionslist[3].ischosen = 'chosen';
            }
             else if(val == 'Section 2 - Part 3') {
                $scope.sectionslist[4].ischosen = 'chosen';
            }
             else if(val == 'Section 2 - Part 4') {
                $scope.sectionslist[5].ischosen = 'chosen';
            }
        };

        $scope.markChosen('Section 1 - Part 1');
        $scope.selectedSection = 0;
        $scope.sctn1PassaObjNum = 0;
        $scope.currentQst = 0;

        $scope.setQst = function() {
            $scope.sctn1PassaObj = _.pick($scope.qqt.qstlist, _.keys($scope.qqt.qstlist)[$scope.sctn1PassaObjNum]);
            console.log('$scope.sctn1PassaObj is: ');
            console.log($scope.sctn1PassaObj);
            $scope.sc1PsaQst = $scope.sctn1PassaObj[_.keys($scope.sctn1PassaObj)]; 
            $scope.currentQst = $scope.sctn1PassaObjNum + 1;
            $scope.qstkey = _.keys($scope.sctn1PassaObj)[0];
            $scope.qstvalue = (_.values($scope.sctn1PassaObj)[0]).qs;
            $scope.imgvalue = (_.values($scope.sctn1PassaObj)[0]).img;
        };

        $scope.setLitInEngSectionB = function(response) {
            console.log('call successful --- response.....');
            console.log(response);
            if(response.data) {
                console.log('call successful.');
                $scope.qtt = response.data;
                if($scope.selectedSection == 0) {
                    $scope.qqt = {
                        "qstarray": $scope.qtt.SA.P1.qst,
                        "qstlist": _.omit($scope.qtt.SA.P1, 'qst')
                    };
                }

                $scope.qtlength = _.keys($scope.qqt.qstlist).length;

                $scope.setQst();
                $scope.getFirst();
            }
        };

        console.log('$rootScope.litineng_selected_year is B: ' + $rootScope.litineng_selected_year);
        
        if(DataStore.getSectionB('litineng', $rootScope.litineng_selected_year)) { 
            console.log('Found LitInEng exam set, not calling the ApiService for this!!!');
            $scope.setLitInEngSectionB(JSON.parse(window.sessionStorage.getItem('litineng_' + $rootScope.litineng_selected_year + '_sectionB')));
        }
        else { 
            console.log("LitInEng exam set Not found, calling the ApiService for data!!!");
            ApiService.getLitInEngSectionB($rootScope.litineng_selected_year)
                .then(function(response) {
                        console.log('The Api.getLitInEngSectionB() response is: ');
                        console.log(response);
                        console.log(response.data);
                        if(response.data) {
                            console.log('call successful.');
                            $scope.qtt = response.data;
                            if($scope.selectedSection == 0) {
                                $scope.qqt = {
                                    "qstarray": $scope.qtt.SA.P1.qst,
                                    "qstlist": _.omit($scope.qtt.SA.P1, 'qst')
                                };
                            }

                            $scope.qtlength = _.keys($scope.qqt.qstlist).length;

                            $scope.setQst();
                            $scope.getFirst();
                        }
                    }, function(error) {
                        console.log('error', error);
                    }
                );   
        };
    }
})();
