(function() {
    'use strict';

    angular
        .module('ssceexamsuiApp')
        .controller('PricingController', PricingController);
                    
    // PricingController.$inject = ['$scope', '$log', '$controller', '$rootScope', 'ConfigService', 'LoggingService', 'ApiService', 'growl', '$location', '$timeout', 'HeaderService'];

    /* @ngInject */
    function PricingController($scope, $log, $controller, $rootScope, ConfigService, LoggingService, ApiService, growl, $location, $timeout, HeaderService) {

        $controller('BaseController', {$scope: $scope});
        $rootScope.baseRoute = '';
        var baseRoute = '';

        $scope.inTestcenter = function() {
            console.log('Now in the Pricing page!');
        };

        $scope.inTestcenter();

        $timeout(function(){
           HeaderService.setTab(5);
        }, 100);

        $scope.gotoExam = function(subj, url) {
            LoggingService.postTrack("gotoexam-" + subj);
            $rootScope.currentSubject = subj;
            console.log('Sscetemplate link for ' + subj + ' clicked!');
            console.log('baseRoute + url is: ' + baseRoute + url);
            $location.path(baseRoute + url);
        };

        $scope.pricehref = function(val) {
            LoggingService.postTrack("subscriptin-" + val);
            $log.info('User subscription clicked: ' + val);
            $location.path(baseRoute + '/signup');
        };

        $scope.modaltxt = {
            free: {
                txt: 'Already Free!',
                perks: 'Offers 3 Examinations years from 1988 to 1990',
                note: 'Free after Joining SSCEexams',
                clr: 'ccc'
            },
            standard: {
                txt: 'Confirm Standard Upgrade',
                perks: 'Offers 12 Examinations years from 1988 to 1999',
                note: 'CODE is STANDARD1',
                clr: '2ab27b'
            },
            premium: {
                txt: 'Confirm Premium Upgrade',
                perks: 'Offers All 28 Examinations years from 1988 to 2015',
                note: 'CODE is PREMIUM2',
                clr: 'f6b63f'
            },
            school: {
                txt: 'Request School Upgrade',
                perks: 'Offers Examinations years based on school subscription',
                note: 'Please contact your School administartor for the School issued CODE',
                clr: '5D6D7E'
            },
            inst: 'Check your email for payment instructions within the next 24 hours.'
        };

        $scope.themodal = {
            modalShown: false
        };

        $scope.confirmmodal = {
            modalShown: false,
            upgrade: 'SSCEexams Upgrade Request',
            text: 'Thanks, please check your email for directions.'
        };

        $scope.toggleModal = function(val) {
            console.log('$scope.toggleModal called, val is: ' + val);
            if(val == 'standardprice') {
                $scope.mtxt = $scope.modaltxt.standard;
            } else if(val == 'premiumprice') {
                $scope.mtxt = $scope.modaltxt.premium;
            } else if(val == 'schoolprice') {
                $scope.mtxt = $scope.modaltxt.school;
            } else {
                $scope.mtxt = $scope.modaltxt.free;
            }
            $scope.themodal.modalShown = !$scope.themodal.modalShown;
            // $scope.logscope();
        };

        $scope.dashboard = function() {
            $scope.confirmmodal.modalShown = !$scope.confirmmodal.modalShown;
            $timeout(function(){
                $location.path('dashboard');
            }, 3000);
        };

        $scope.confirmUpgrade = function(val) {
            LoggingService.postTrack("confrmupg");
            console.log('Upgrade Selected is: ' + val);
            if(val == 'Confirm Standard Upgrade') {
                console.log('standardprice!!!');
                ApiService.confirmUpgrade($rootScope.userid, 'current', 'standard');
                $scope.dashboard();
            } else if(val == 'Confirm Premium Upgrade') {
                console.log('premiumprice!!!');
                ApiService.confirmUpgrade($rootScope.userid, 'current', 'premium');
                $scope.dashboard();
            } else if(val == 'Request School Upgrade') {
                console.log('schoolprice!!!');
                ApiService.confirmUpgrade($rootScope.userid, 'current', 'schools');
                $scope.dashboard();
            } else {
                console.log('freeprice - Already Free!!!');
                $location.path('dashboard');
            }     
            $scope.themodal.modalShown = !$scope.themodal.modalShown;
        };

        $scope.examsubjects = [
          {
            name: 'Free',
            btnval: 'Free at Sign up',
            href: 'freeprice',
            price: '₦0',
            btncolor: "btn-free",
            notes: 'Practice a limited number of real examinations questions covering all 11 major subjects over 4 years (1988, 1989, 1990, 2015), view your study progress and see analytics to showing how well you are progressing in your preparations.',
            side: 'Free for students as part of the SSCE examinations Student Preparatory Pack program',
            icn: 'fa fa-users fa-lg'
          },
          {
            name: 'Standard',
            btnval: 'Upgrade to standard',
            href: 'standardprice',
            price: '₦1000',
            btncolor: "btn-standard",
            notes: 'Practice real examinations questions spanning a period of 10 years over all 11 major subjects, view your study progress and see comprehensive analytics showing how well you are progressing in preparations.',
            side: 'This package allows you access to standard student metrics generator and a basic analytics dashboard',
            icn: 'fa fa-bar-chart fa-lg'
          },
          {
            name: 'Premium',
            btnval: 'Upgrade to premium',
            href: 'premiumprice',
            price: '₦2500',
            btncolor: "btn-premium",
            notes: 'Practice real examinations questions spanning a period of 28 years over all 11 major subjects, view your study progress, see and generate comprehensive analytics and progress reports showing how well you are progressing.',
            side: 'This package includes the metrics generator and a comprehensive, 360 degree analytics dashboard',
            icn: 'fa fa-tachometer fa-lg'
          },
          {
            name: 'School',
            btnval: 'Start a free School trial',
            href: 'schoolprice',
            price: '₦500',
            btncolor: "btn-school",
            notes: 'As a member of your school subscription, you can practice all available 28 years of real examinations over all 13 major subjects. View your progress reports and allow your instructors see how well you are preparing and which areas you might need extra help.',
            side: 'Sold to School organizations in packs of 50 student seats and billed annually',
            icn: 'fa fa-graduation-cap fa-lg'
          }
        ];
    }

     
})();
