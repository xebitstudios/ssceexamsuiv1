(function() {
    'use strict';

    angular
        .module('ssceexamsuiApp')
        .controller('AnalyticsController', AnalyticsController);

    // AnalyticsController.$inject = ['$scope', '$log', '$location', '$controller', '$rootScope', 'DataStore', 'ConfigService', 'ApiService', 'HeaderService', '$timeout'];

    /* @ngInject */
    function AnalyticsController($scope, $log, $location, $controller, $rootScope, DataStore, ConfigService, ApiService, HeaderService, $timeout, LoggingService) {

        $controller('BaseController', {$scope: $scope});
        $rootScope.baseRoute = '';
        $scope.activeTab = 'usersInProgress';
        $scope.pgwidth = true;
        $scope.currentpage = 1;
        $scope.chartchange = '';
        $scope.username = ConfigService.getUserId();
        console.log('user is: ' + $scope.username);
        
        $scope.chart1Subject = "";
        $scope.chart1Year = "";
        $scope.chart2Subject = "";
        $scope.chart2Year = "";
        $scope.chart3Year = "";
        $scope.chart4Year = "";
        $scope.chart5Subject = "";
        $scope.chart6Subject = "";
        // LoggingService.postTrack('chart1');
        
        $scope.hide = [
            { hideval: '' },
            { hideval: '' },
            { hideval: '' },
            { hideval: '' },
            { hideval: '' },
            { hideval: '' },
            { hideval: '' },
            { hideval: '' },
            { hideval: '' },
            { hideval: '' }
        ];

        $scope.fclick = function() {
            LoggingService.postTrack("analy-fc");
            if($scope.currentpage !== 1) {
                $scope.currentpage = 1;
                $scope.moveon($scope.currentpage);
            }
        };

        $scope.lclick = function() {
            LoggingService.postTrack("analy-lc");
            if($scope.currentpage !== 9) {
                $scope.currentpage = 9;
                $scope.moveon($scope.currentpage);
            }
        };

        $scope.nclick = function() {
            LoggingService.postTrack("analy-nc");
            if($scope.currentpage !== 9) {
                $scope.currentpage++;
                $scope.moveon($scope.currentpage);
            }
        };

        $scope.pclick = function() {
            LoggingService.postTrack("analy-pc");
            if($scope.currentpage !== 1) {
                $scope.currentpage--;
                $scope.moveon($scope.currentpage);
            }
        };

        $scope.recentexams = {};
        $scope.toprow = [];
        $scope.examscores = {};

        $scope.inAnalytics = function() {
            console.log('Now in the Analytics page!');
        };

        $scope.inAnalytics();

        $scope.closeme = function (val) {
            LoggingService.postTrack("analy-clme");
            console.log("val is: " + val);
            $('#hideme' + val + '').hide("slow");
            $('#' + val + '').hide("slow");
        };

        $scope.moveon = function(val) {
            LoggingService.postTrack("analy-mvon");
            if($scope.pgwidth) {
                for(var e=0;e<9;e++) {
                    $scope.hide[e].hideval = 'hide';
                }
                if(val==1) { $scope.hide[0].hideval = ''; }
                if(val==2) { $scope.hide[1].hideval = ''; }
                if(val==3) { $scope.hide[2].hideval = ''; }
                if(val==4) { $scope.hide[3].hideval = ''; }
                if(val==5) { $scope.hide[4].hideval = ''; }
                if(val==6) { $scope.hide[5].hideval = ''; }
                if(val==7) { $scope.hide[6].hideval = ''; }
                if(val==8) { $scope.hide[7].hideval = ''; }
                if(val==9) { $scope.hide[8].hideval = ''; }
            }
        };

        $scope.subjmonth = [
            { code: "", name: "Month" },
            { code: "Jan", name: "Jan" },
            { code: "Feb", name: "Feb" },
            { code: "Mar", name: "Mar" },           
            { code: "Apr", name: "Apr" },
            { code: "May", name: "May" },
            { code: "Jun", name: "Jun" },
            { code: "Jul", name: "Jul" },
            { code: "Aug", name: "Aug" },
            { code: "Sep", name: "Sep" },
            { code: "Oct", name: "Oct" },
            { code: "Nov", name: "Nov" },
            { code: "Dec", name: "Dec" }
        ];

        $scope.subjnumber = [
            { code: "Top3", name: "Top 3" },
            { code: "Last3", name: "Last 3" }
        ];

        $scope.subjlist = [
            { code: "", name: "Subject" },
            { code: "Physics", name: "Physics" },
            { code: "Chemistry", name: "Chemistry" },
            { code: "Mathematics", name: "Mathematics" },           
            { code: "Economics", name: "Economics" },
            { code: "Biology", name: "Biology" },
            { code: "English", name: "English" },
            { code: "Geography", name: "Geography" },
            { code: "Lit. in English", name: "Lit. in English" },
            { code: "Commerce", name: "Commerce" },
            { code: "Agric Sci", name: "Agric Sci" },
            { code: "Government", name: "Government" }
        ];

        $scope.subjyear = [
            { code: "", name: "Year" },
            { code: "1988", name: "1988" },
            { code: "1989", name: "1989" },
            { code: "1990", name: "1990" },           
            { code: "1991", name: "1991" },
            { code: "1992", name: "1992" },
            { code: "1993", name: "1993" },
            { code: "1994", name: "1994" },
            { code: "1995", name: "1995" },
            { code: "1996", name: "1996" },
            { code: "1997", name: "1997" },
            { code: "1998", name: "1998" },
            { code: "1999", name: "1999" },
            { code: "2000", name: "2000" },           
            { code: "2001", name: "2001" },
            { code: "2002", name: "2002" },
            { code: "2003", name: "2003" },
            { code: "2004", name: "2004" },
            { code: "2005", name: "2005" },
            { code: "2006", name: "2006" },
            { code: "2007", name: "2007" },
            { code: "2008", name: "2008" },
            { code: "2009", name: "2009" },
            { code: "2010", name: "2010" },           
            { code: "2011", name: "2011" },
            { code: "2012", name: "2012" },
            { code: "2013", name: "2013" },
            { code: "2014", name: "2014" },
            { code: "2015", name: "2015" }
        ];

        $scope.chart1Data = {};
        $scope.chart2Data = {};
        $scope.chart3Data = {};
        $scope.chart4Data = {};
        $scope.chart5Data = {};
        $scope.chart6Data = {};

        $scope.setChart1 = function() {
            $('#chart1').highcharts({
                chart: {
                    type: 'column'
                },
                title: {
                    text: 'Monthly Exam Completions'
                },
                xAxis: {
                    categories: ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],
                    crosshair: true
                },
                yAxis: {
                    min: 0,
                    title: {
                        text: 'Exam Completions'
                    }
                },
                tooltip: {
                    headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                    pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                        '<td style="padding:0"><b>{point.y:.1f}</b></td></tr>',
                    footerFormat: '</table>',
                    shared: true,
                    useHTML: true
                },
                plotOptions: {
                    column: {
                        pointPadding: 0.1,
                        borderWidth: 0.2
                    }
                },
                series: [{
                    name: $scope.chart1Data.dataval,
                    data: $scope.chart1Data.data
                }]
            });
        };

        $scope.setChart2 = function() {
            $('#chart2').highcharts({
                chart: {
                    type: $scope.chart2Data.typee
                },
                title: {
                    text: $scope.chart2Data.titlee
                },
                subtitle: {
                    text: '<b>' + $scope.chart2Data.subtitle + '</b>'
                },
                xAxis: {
                    allowDecimals: false,
                    labels: {
                        formatter: function () {
                            return this.value; // clean, unformatted number for year
                        }
                    }
                },
                yAxis: {
                    title: {
                        text: $scope.chart2Data.data1ylabel
                    },
                    labels: {
                        formatter: function () {
                            return this.value ;
                        }
                    }
                },
                tooltip: {
                    pointFormat: '{series.name} scored <b>{point.y:,.0f}</b> points<br/>more than the average tester'
                },
                plotOptions: {
                    area: {
                        pointStart: 1988,
                        marker: {
                            enabled: false,
                            symbol: 'circle',
                            radius: 2,
                            states: {
                                hover: {
                                    enabled: true
                                }
                            }
                        }
                    }
                },
                series: [{
                    name: $scope.chart2Data.data1xlabel,
                    data: $scope.chart2Data.data1,
                    color: $scope.chart2Data.color1
                }, {
                    name: $scope.chart2Data.data2xlabel,
                    data: $scope.chart2Data.data2,
                    color: $scope.chart2Data.color2
                }]
            });
        };

        $scope.setChart3 = function() {
            $('#chart3').highcharts({
                chart: {
                    type: $scope.chart3Data.typee
                },
                title: {
                    text: $scope.chart3Data.titlee
                },
                subtitle: {
                    text: $scope.chart3Data.subtitle
                },
                xAxis: {
                    categories: $scope.chart3Data.data2xlabel
                },
                yAxis: {
                    title: {
                        text: $scope.chart3Data.data1ylabel
                    }
                },
                plotOptions: {
                    line: {
                        dataLabels: {
                            enabled: true
                        },
                        enableMouseTracking: false
                    }
                },
                series: [{
                    name: 'You',
                    data: $scope.chart3Data.data1,
                    color: '#85929E'
                }, {
                    name: 'Average User',
                    data: $scope.chart3Data.data2,
                    color: '#F8C471'
                }]
            });
        };           

        $scope.setChart4 = function() {
            $('#chart4').highcharts({
                chart: {
                    type: "area"
                },
                title: {
                    text: $scope.chart4Data.titleval
                },
                xAxis: {
                    categories: $scope.chart4Data.category,
                    tickmarkPlacement: 'on',
                    title: {
                        enabled: false
                    }
                },
                yAxis: {
                    title: {
                        text: "Overall (%)"
                    }
                },
                tooltip: {
                    pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.percentage:.1f}%</b> ({point.y:,.0f} attempts)<br/>',
                    split: true
                },
                plotOptions: {
                    area: {
                        stacking: 'percent',
                        lineColor: '#ffffff',
                        lineWidth: 1,
                        marker: {
                            lineWidth: 1,
                            lineColor: '#ffffff'
                        }
                    }
                },
                series: [
                    {
                        name: $scope.chart4Data.dataval1,
                        data: $scope.chart4Data.data1,
                        color: $scope.chart4Data.colorval1
                    },
                    {
                        name: $scope.chart4Data.dataval2,
                        data: $scope.chart4Data.data2,
                        color: $scope.chart4Data.colorval2
                    },
                    {
                        name: $scope.chart4Data.dataval3,
                        data: $scope.chart4Data.data3,
                        color: $scope.chart4Data.colorval3
                    }
                ]
            }); 
        };

        $scope.setChart5 = function() {
            $('#chart5').highcharts({
                chart: {
                    plotBackgroundColor: null,
                    plotBorderWidth: null,
                    plotShadow: false,
                    type: 'pie'
                },
                title: {
                    text: 'Exam Attempts for Subject in Last 1 Month'
                },
                tooltip: {
                    pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
                },
                plotOptions: {
                    pie: {
                        allowPointSelect: true,
                        cursor: 'pointer',
                        dataLabels: {
                            enabled: false
                        },
                        showInLegend: true
                    }
                },
                series: [{
                    name: 'Total %',
                    colorByPoint: true,
                    data: [
                        {
                            name: 'Completed',
                            y: $scope.chart5Data.comp
                        }, 
                        {
                            name: 'Not Completed',
                            y: $scope.chart5Data.noncomp,
                            sliced: true,
                            selected: true
                        }
                    ]
                }]
            });
        };

        var categories = [' < 1996', '1996', '1997', '1998',
            '1999', '2000', '2001', '2002', '2003',
            '2004', '2005', '2006', '2007', '2008',
            '2009', '2010', '2011', '2012', '2013',
            '2014', '2015'
        ];

        $scope.setChart6 = function() {
            $('#chart6').highcharts({
                chart: {
                    type: $scope.chart6Data.typee
                },
                title: {
                    text: $scope.chart6Data.titlee
                },
                subtitle: {
                    text: $scope.chart6Data.subtitle
                },
                xAxis: [
                    {
                        categories: categories,
                        reversed: false,
                        labels: {
                            step: 1
                        }
                    }, { // mirror axis on right side
                        opposite: true,
                        reversed: false,
                        categories: categories,
                        linkedTo: 0,
                        labels: {
                            step: 1
                        }
                    }
                ],
                yAxis: {
                    title: {
                        text: null
                    },
                    labels: {
                        formatter: function () {
                            return Math.abs(this.value) + '%';
                        }
                    }
                },
                plotOptions: {
                    series: {
                        stacking: 'normal'
                    }
                },
                tooltip: {
                    formatter: function () {
                        return '<b>' + this.series.name + ', year ' + this.point.category + '</b><br/>' +
                            'Score: ' + Highcharts.numberFormat(Math.abs(this.point.y), 0);
                    }
                },
                series: [{
                    name: $scope.chart6Data.data2xlabel,
                    data: $scope.chart6Data.data2,
                    color: '#273746'
                }, {
                    name: $scope.chart6Data.data1xlabel,
                    data: $scope.chart6Data.data1,
                    color: '#E74C3C'
                }]
            });
        };

        $scope.setToprow = function(response) {
            if(response.tp1Row === undefined) {
                $scope.toprow = [];
                $scope.recentexams = {
                    name: 'Not enough test data.',
                    subjscores: []
                };
                $scope.examscores = {
                    results: [],
                    summary: {}
                };
                // showchart2subj
                // showchart2yr
                // showchart5subj
                // showchart3yr
                // showchart4topval
                // showchart1subj
                // showchart1yr
                // showchart6subj
            } else {
                $scope.toprow = [
                    {
                        rowtitle: response.tp1Row[0],
                        vall: response.tp1Row[1],
                        ind: response.tp1Row[2]
                    },
                    {
                        rowtitle: response.tp2Row[0],
                        vall: response.tp2Row[1],
                        ind: response.tp2Row[2]
                    },
                    {
                        rowtitle: response.tp3Row[0],
                        vall: response.tp3Row[1],
                        ind: response.tp3Row[2]
                    },
                    {
                        rowtitle: response.tp4Row[0],
                        vall: response.tp4Row[1],
                        ind: response.tp4Row[2]
                    }
                ];
                $scope.recentexams = {
                    name: response.rexName,
                    subjscores: [
                        {
                            subj: response.rexSs1[0],
                            year: response.rexSs1[1],
                            pct: response.rexSs1[2],
                            examday: response.rexSs1[3],
                            examtime: response.rexSs1[4],
                            daysection: response.rexSs1[5],
                            colr: response.rexSs1[6]
                        },
                        {
                            subj: response.rexSs2[0],
                            year: response.rexSs2[1],
                            pct: response.rexSs2[2],
                            examday: response.rexSs2[3],
                            examtime: response.rexSs2[4],
                            daysection: response.rexSs2[5],
                            colr: response.rexSs2[6]
                        },
                        {
                            subj: response.rexSs3[0],
                            year: response.rexSs3[1],
                            pct: response.rexSs3[2],
                            examday: response.rexSs3[3],
                            examtime: response.rexSs3[4],
                            daysection: response.rexSs3[5],
                            colr: response.rexSs3[6]
                        },
                        {
                            subj: response.rexSs4[0],
                            year: response.rexSs4[1],
                            pct: response.rexSs4[2],
                            examday: response.rexSs4[3],
                            examtime: response.rexSs4[4],
                            daysection: response.rexSs4[5],
                            colr: response.rexSs4[6]
                        },
                        {
                            subj: response.rexSs5[0],
                            year: response.rexSs5[1],
                            pct: response.rexSs5[2],
                            examday: response.rexSs5[3],
                            examtime: response.rexSs5[4],
                            daysection: response.rexSs5[5],
                            colr: response.rexSs5[6]
                        }
                    ]
                };
                $scope.examscores = {
                    results: [
                        {
                            name: response.exSc1[0],
                            attempts: response.exSc1[1],
                            avgscore: response.exSc1[2],
                            noticeval: response.exSc1[3],
                            iconval: response.exSc1[4]
                        },
                        {
                            name: response.exSc2[0],
                            attempts: response.exSc2[1],
                            avgscore: response.exSc2[2],
                            noticeval: response.exSc2[3],
                            iconval: response.exSc2[4]
                        },
                        {
                            name: response.exSc3[0],
                            attempts: response.exSc3[1],
                            avgscore: response.exSc3[2],
                            noticeval: response.exSc3[3],
                            iconval: response.exSc3[4]
                        },
                        {
                            name: response.exSc4[0],
                            attempts: response.exSc4[1],
                            avgscore: response.exSc4[2],
                            noticeval: response.exSc4[3],
                            iconval: response.exSc4[4]
                        }
                    ],
                    summary: {}
                };
            }
        };

        $scope.getUserToprow = function() {
            if(DataStore.getUserToprow()) { 
                console.log('Found it, not calling the ApiService for this!!!');
                if(window.sessionStorage.toprow !== {}) $scope.setToprow(JSON.parse(DataStore.getUserToprow()));
            }
            else { 
                console.log("Not found, calling the ApiService for data!!!");
                LoggingService.postTrack("gettoprow");
                ApiService.getUserToprow($rootScope.userid).then(function(response) {
                    if(response.username) {
                        console.log("DataStore.getUserToprow(): ")
                        DataStore.setUserToprow(JSON.stringify(response));              
                        $scope.setToprow(response);
                    } else {
                        DataStore.setUserToprow(JSON.stringify({})); 
                    }
                });   
            };                  
        };        
        $scope.getUserToprow();

        $scope.setUserChart1 = function(response) {
            console.log("chart1 is: ");
            console.log(response);
            if(response.username) {
                $scope.chart1Data = {
                    username: response.username,
                    updatedate: response.dataDate,
                    subj: response.subj,
                    yr: response.yr,
                    data: response.dataval,
                };
                $scope.showchart1 = 'hidee';
                $scope.showchart1e = 'hide';
            } else {
                $scope.showchart1 = 'hide';
                $scope.showchart1e = 'hidee';
            } 
            $('#subjmth1').find('option[value=' + response.subj  + ']').attr("selected",true);
            $('#subjyr2').find('option[value=' + response.yr  + ']').attr("selected",true);
            $scope.setChart1();                                
        };

        $scope.setUserChart2 = function(response) {
            console.log("chart2 is: ");
            console.log(response);
            if(response.username) {
                $scope.chart2Data = {
                    username: response.username,
                    updatedate: response.dataDate,
                    subj: response.subj,
                    yr: response.yr,
                    data1: response.dataval1,
                    data2: response.dataval2,
                    typee: response.typeval,
                    titlee: response.titleval,
                    subtitle: response.subtitleval,
                    data1xlabel: response.xval,
                    color1: response.colorval1,
                    data2xlabel: 'You',
                    data1ylabel: response.yval,
                    color2: response.colorval2
                };
                $scope.showchart2 = 'hidee';
                $scope.showchart2e = 'hide';
            } else {
                $scope.showchart2 = 'hide';
                $scope.showchart2e = 'hidee';
            } 
            $('#subjlst1').find('option[value=' + response.subj + ']').attr("selected",true);
            $('#subjyr1').find('option[value=' + response.yr + ']').attr("selected",true);
            $scope.setChart2();                                
        };

        $scope.setUserChart3 = function(response) {
            console.log("chart3 is: ");
            console.log(response);
            if(response.username) {
                $scope.chart3Data = {
                    username: response.username,
                    updatedate: response.dataDate,
                    yr: response.yr,
                    data1: response.dataval1,
                    data2: response.dataval2,
                    color1: response.colorval1,
                    color2: response.colorval2,
                    data1xlabel: response.xval,
                    data1ylabel: response.yval,
                    data2xlabel: response.x2val,
                    typee: response.typeval,
                    titlee: response.titleval,
                    subtitle: response.subtitleval,
                    createdAt: response.createdAt,
                    updatedAt: response.updatedAt
                };
                $scope.showchart3 = 'hidee';
                $scope.showchart3e = 'hide';
            } else {
                $scope.showchart3 = 'hide';
                $scope.showchart3e = 'hidee';
                $scope.showchart3yr = "2001";
            }
            $('#subjyr3').find('option[value=' + response.yr + ']').attr("selected",true);
            $scope.setChart3();                             
        };

        $scope.setUserChart4 = function(response) {
            console.log("chart4 is: ");
            console.log(response);
            if(response.username) {
                $scope.chart4Data = {
                    username: response.username,
                    updatedate: response.dataDate,
                    toptype: response.toptype,
                    dataval1: response.txtval1,
                    dataval2: response.txtval2,
                    dataval3: response.txtval3,
                    data1: response.dataval1,
                    data2: response.dataval2,
                    data3: response.dataval3,
                    color1: response.colorval1,
                    color2: response.colorval2,
                    color3: response.colorval3,
                    category: response.category,
                    data1ylabel: response.yval,
                    data1xlabel: response.xval,
                    typee: response.typeval,
                    titlee: response.titleval,
                    createdAt: response.createdAt,
                    updatedAt: response.updatedAt
                };
                $scope.showchart4 = 'hidee';
                $scope.showchart4e = 'hide';
            } else {
                $scope.showchart4 = 'hide';
                $scope.showchart4e = 'hidee';
                $scope.showchart4topval = 'Top3';
            }
            $('#subjnum').find('option[value="' + response.toptype + '"]').attr("selected",true);
            $scope.setChart4();
        };

        $scope.setUserChart5 = function(response) {
            console.log("chart5 is: ");
            console.log(response);
            if (response.username) {
                $scope.chart5Data = {
                    username: response.username,
                    updatedate: response.dataDate,
                    subj: response.subj,
                    comp: response.comp,
                    noncomp: response.noncomp,
                    name1: response.txtval1,
                    name2: response.txtval2,
                    colorval1: response.colorval1,
                    colorval2: response.colorval2,
                    selected: true,
                    sliced: true,
                    createdAt: response.createdAt,
                    updatedAt: response.updatedAt
                };
                $scope.showchart5 = 'hidee';
                $scope.showchart5e = 'hide';
            } else {
                $scope.showchart5 = 'hide';
                $scope.showchart5e = 'hidee';
                $scope.showchart5subj = "English";
            }
            $('#subjlst2').find('option[value="' + response.subj + '"]').attr("selected",true);
            $scope.setChart5();            
        }

        $scope.setUserChart6 = function(response) {
            console.log("chart6 is: ");
            console.log(response);
            if (response.username) {
                $scope.chart6Data = {
                    username: response.username,
                    updatedate: response.dataDate,
                    subj: response.subj,
                    data1: response.dataval1,
                    data2: response.dataval2,
                    color1: response.colorval1,
                    color2: response.colorval2,
                    data1xlabel: response.xval,
                    data1ylabel: response.yval,
                    data2xlabel: response.x2val,
                    subtitle: response.subtitleval,
                    titlee: response.titleval,
                    typee: response.typeval,
                    createdAt: response.createdAt,
                    updatedAt: response.updatedAt
                };
                $scope.showchart6 = 'hidee';
                $scope.showchart6e = 'hide';
            } else {
                $scope.showchart6 = 'hide';
                $scope.showchart6e = 'hidee';
                $scope.showchart6subj = "English";
            }
            $('#subjlst3').find('option[value="' + response.subj + '"]').attr("selected",true);
            $scope.setChart6();            
        }

        $scope.getChart1 = function(subj, yr) {
            if(DataStore.getChart1($rootScope.userid, subj, yr)) { 
                console.log('Found chart1, not calling the ApiService for this!!!');
                $scope.setUserChart1(JSON.parse(DataStore.getChart1($rootScope.userid, subj, yr)));
            }
            else { 
                LoggingService.postTrack("chart1");
                console.log("chart1 Not found, calling the ApiService for data!!!");
                $scope.showchart1 = 'hide';
                $scope.showchart1e = 'hidee';
                
                ApiService.getChart1($rootScope.userid, subj, yr).then(function(response) {
                    console.log("DataStore.getChart1(): ")
                    if(response.username) {
                        DataStore.setChart1($rootScope.userid, subj, yr, JSON.stringify(response));
                    } else {
                        DataStore.setChart1($rootScope.userid, subj, yr, JSON.stringify(response));
                    }
                    $scope.setUserChart1(response);
                    $timeout(function(){
                        $scope.chart1Update();
                    }, 500);
                });   
            };
        };
        $scope.getChart1('English', '2001');

        $scope.getChart2 = function(subj, yr) {
            if(DataStore.getChart2($rootScope.userid, subj, yr)) { 
                console.log('Found chart2, not calling the ApiService for this!!!');
                $scope.setUserChart2(JSON.parse(DataStore.getChart2($rootScope.userid, subj, yr)));
            }
            else { 
                LoggingService.postTrack("chart2");
                console.log("chart2 Not found, calling the ApiService for data!!!");
                $scope.showchart2 = 'hide';
                $scope.showchart2e = 'hidee';
                
                ApiService.getChart2($rootScope.userid, subj, yr).then(function(response) {
                    console.log("DataStore.getChart2(): ")
                    if(response.username) {
                        DataStore.setChart2($rootScope.userid, subj, yr, JSON.stringify(response));
                    } else {
                        DataStore.setChart2($rootScope.userid, subj, yr, JSON.stringify(response));
                    }
                    $scope.setUserChart2(response);
                    $timeout(function(){
                        $scope.chart2Update();
                    }, 500);
                });   
            };
        };
        $scope.getChart2('English', '2001');

        $scope.getChart3 = function(yr) {
            if(DataStore.getChart3($rootScope.userid, yr)) { 
                console.log('Found chart3, not calling the ApiService for this!!!');
                $scope.setUserChart3(JSON.parse(DataStore.getChart3($rootScope.userid, yr)));
            }
            else { 
                LoggingService.postTrack("chart3");
                console.log("chart3 Not found, calling the ApiService for data!!!");
                $scope.showchart3 = 'hide';
                $scope.showchart3e = 'hidee';
                
                ApiService.getChart3($rootScope.userid, yr).then(function(response) {
                    console.log("DataStore.getChart3(): ")
                    if(response.username) {
                        DataStore.setChart3($rootScope.userid, yr, JSON.stringify(response));
                    } else {
                        DataStore.setChart3($rootScope.userid, yr, JSON.stringify(response));
                    }
                    $scope.setUserChart3(response);
                    $timeout(function(){
                        $scope.chart3Update();
                    }, 500);
                });   
            };                    
        };
        $scope.getChart3(2001);

        $scope.getChart4 = function(tv) {
            if(DataStore.getChart4($rootScope.userid, tv)) { 
                console.log('Found chart4, not calling the ApiService for this!!!');
                $scope.setUserChart4(JSON.parse(DataStore.getChart4($rootScope.userid, tv)));
            }
            else { 
                LoggingService.postTrack("chart4");
                console.log("chart4 Not found, calling the ApiService for data!!!");
                $scope.showchart4 = 'hide';
                $scope.showchart4e = 'hidee';
                
                ApiService.getChart4($rootScope.userid, tv).then(function(response) {
                    console.log("DataStore.getChart4(): ")
                    if(response.username) {
                        DataStore.setChart4($rootScope.userid, tv, JSON.stringify(response));
                    } else {
                        DataStore.setChart4($rootScope.userid, tv, JSON.stringify(response));
                    }
                    $scope.setUserChart4(response);
                    $timeout(function(){
                        $scope.chart4Update();
                    }, 500);
                });   
            };
        };
        $scope.getChart4('top3');

        $scope.getChart5 = function(subj) {
            if(DataStore.getChart5($rootScope.userid, subj)) { 
                console.log('Found chart5, not calling the ApiService for this!!!');
                $scope.setUserChart5(JSON.parse(DataStore.getChart5($rootScope.userid, subj)));
            }
            else { 
                LoggingService.postTrack("chart5");
                console.log("chart5 Not found, calling the ApiService for data!!!");
                $scope.showchart5 = 'hide';
                $scope.showchart5e = 'hidee';
                
                ApiService.getChart5($rootScope.userid, subj).then(function(response) {
                    console.log("DataStore.getChart5(): ")
                    if(response.username) {
                        DataStore.setChart5($rootScope.userid, subj, JSON.stringify(response));
                    } else {
                        DataStore.setChart5($rootScope.userid, subj, JSON.stringify(response));
                    }
                    $scope.setUserChart5(response);
                    $timeout(function(){
                        $scope.chart5Update();
                    }, 500);                    
                });   
            };
        };
        $scope.getChart5('English');

        $scope.getChart6 = function(subj) {
            if(DataStore.getChart6($rootScope.userid, subj)) { 
                console.log('Found chart6, not calling the ApiService for this!!!');
                $scope.setUserChart6(JSON.parse(DataStore.getChart6($rootScope.userid, subj)));
            }
            else { 
                LoggingService.postTrack("chart6");
                console.log("chart6 Not found, calling the ApiService for data!!!");
                $scope.showchart6 = 'hide';
                $scope.showchart6e = 'hidee';
                
                ApiService.getChart6($rootScope.userid, subj).then(function(response) {
                    console.log("DataStore.getChart6(): ")
                    if(response.username) {
                        DataStore.setChart6($rootScope.userid, subj, JSON.stringify(response));
                    } else {
                        DataStore.setChart6($rootScope.userid, subj, JSON.stringify(response));
                    }
                    $scope.setUserChart6(response);
                    $timeout(function(){
                        $scope.chart6Update();
                    }, 500);                    
                });   
            };
        };
        $scope.getChart6('English');

        $scope.chart1Update = function() {
            LoggingService.postTrack("chart1up");
            $scope.chartchange = 'chart1';
            $scope.getChart1($('#subjmth1').val(), $('#subjyr2').val());
        };

        $scope.chart2Update = function() {
            LoggingService.postTrack("chart2up");
            $scope.chartchange = 'chart2';
            $scope.getChart2($('#subjlst1').val(), $('#subjyr1').val());
        };

        $scope.chart3Update = function() {
            LoggingService.postTrack("chart3up");
            $scope.chartchange = 'chart3';
            $scope.getChart3($('#subjyr3').val());
        };

        $scope.chart4Update = function() {
            LoggingService.postTrack("chart4up");
            $scope.chartchange = 'chart4';
            $scope.getChart4($('#subjnum').val().toLowerCase());
        };

        $scope.chart5Update = function() {
            LoggingService.postTrack("chart5up");
            $scope.chartchange = 'chart5';
            $scope.getChart5($('#subjlst2').val());
        };

        $scope.chart6Update = function() {
            LoggingService.postTrack("chart6up");
            $scope.chartchange = 'chart6';
            $scope.getChart6($('#subjlst3').val());
        };

        $timeout(function(){
            $('div svg text:contains("Highcharts.com")').addClass('hide');

            if ($('body').width() < 600) {
              $scope.pgwidth = true;
              $scope.moveon(1);
            } else {
              HeaderService.setTab(2);
              $scope.pgwidth = false;
            }
            console.log('$scope.pgwidth is: ' + $scope.pgwidth);
            $('#subjmth1').find('option[value=English]').attr("selected",true);
            $('#subjyr2').find('option[value=2001]').attr("selected",true);
            $('#subjlst1').find('option[value=English]').attr("selected",true);
            $('#subjyr1').find('option[value=2001]').attr("selected",true);
            $('#subjyr3').find('option[value=2001]').attr("selected",true);
            $('#subjnum').find('option[value=top3]').attr("selected",true);
            $('#subjlst2').find('option[value=English]').attr("selected",true);
            $('#subjlst3').find('option[value=English]').attr("selected",true);
        }, 800);

    }
})();