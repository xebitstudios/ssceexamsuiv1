(function() {
    'use strict';

    angular
        .module('ssceexamsuiApp')
        .controller('ProfileController', ProfileController);

    // ProfileController.$inject = ['$scope', '$log', '$location', '$route', '$controller', '$rootScope', 'LoggingSevice', 'DataStore', 'ConfigService', 'HeaderService', 'ApiService', 'growl', '$timeout', 'window'];

    /* @ngInject */
    function ProfileController($scope, $log, $location, $route, $controller, $rootScope, LoggingService, DataStore, ConfigService, HeaderService, ApiService, growl, $timeout, window) {

        $controller('BaseController', {$scope: $scope});
        console.log('userid: ' + $rootScope.userid);

        $rootScope.baseRoute = '';
        $scope.picUrl = "https://s3.amazonaws.com/ssceexams-user-pics/" + window.sessionStorage.username + ".jpg?cb=" + Date.now();
        $scope.showupload = "showupload";

        $scope.inProfile = function() {
            LoggingService.postTrack("inprofile");
            console.log('Now in the Profile page!');
            $rootScope.user = $rootScope.userid;
            console.log($rootScope.user);
        };

        $scope.inProfile();
        console.log("$rootScope.userid: " + $rootScope.userid);
        $rootScope.userpwd = DataStore.getpwd();
        console.log("$rootScope.userpwd: " + $rootScope.userpwd);

        if(DataStore.getUserProfile() !== '') {
            $scope.userprofileresult = JSON.parse(DataStore.getUserProfile());
            console.log("$scope.userprofileresult = DataStore.getUserProfile()");
            console.log($scope.userprofileresult);
            if ($scope.userprofileresult !== '') $scope.userprofileresult.member_since = $scope.userprofileresult.subscriptionstartdate;
        } else {
            $scope.userprofileresult.username = window.sessionStorage.username;
            $scope.userprofileresult.member_since = window.sessionStorage.memberdate;
            $scope.userprofile.user.city = '';
            $scope.userprofile.user.state = '';
            $scope.userprofile.user.fname = '';
            $scope.userprofile.user.lname = '';
            $scope.userprofile.user.straddy = '';
            $scope.userprofile.user.country = '';
            $scope.userprofile.user.phone = '';
            $scope.userprofile.user.email = window.sessionStorage.email;
        }
        
        $scope.userprofile = {
            user: {},
            sch: {}
        };

        $scope.userprofilecopy = {
            user: {},
            sch: {}
        };

        $scope.convertVal = function(val) {
            if(window.sessionStorage.memberdate) {
                return window.sessionStorage.memberdate;
            } else {
                window.sessionStorage.memberdate = val.split(' ')[0] + ', ' + val.split(' ')[1] + '/' + val.split(' ')[2] + '/' + val.split(' ')[3];
                return window.sessionStorage.memberdate;
            }            
        };

        $scope.setUserprofile = function(val) {
            console.log("val: ");
            console.log(val);
            $scope.userprofile.user.firstname = val.firstname || "NA";
            $scope.userprofile.user.lastname = val.lastname || "NA";
            $scope.userprofile.user.straddy = val.straddy || "NA";
            $scope.userprofile.user.city = val.city || "NA";
            $scope.userprofile.user.state = val.state || "NA";
            $scope.userprofile.user.country = val.country || "NA";
            $scope.userprofile.user.phone = val.phone || "NA";
            $scope.userprofile.user.email = val.email || "NA";
            $scope.userprofile.user.aboutyou = val.aboutyou || "NA";
            $scope.userprofile.user.status = val.status || "NA";

            $scope.userprofilecopy.user.username = val.username || "NA";
            $scope.userprofilecopy.user.password = val.password || "NA";
            $scope.userprofilecopy.user.firstname = val.firstname || "NA";
            $scope.userprofilecopy.user.lastname = val.lastname || "NA";
            $scope.userprofilecopy.user.straddy = val.straddy || "NA";
            $scope.userprofilecopy.user.city = val.city || "NA";
            $scope.userprofilecopy.user.state = val.state || "NA";
            $scope.userprofilecopy.user.country = val.country || "NA";
            $scope.userprofilecopy.user.phone = val.phone || "NA";
            $scope.userprofilecopy.user.email = val.email || "NA";
            $scope.userprofilecopy.user.aboutyou = val.aboutyou || "NA";
            // $scope.userprofilecopy.user = $scope.userprofile.user;
            $scope.userprofilecopy.user.subscriptionstartdate = val.subscriptionstartdate || "NA";
            $scope.userprofilecopy.user.subjectslist = val.subjectslist || "NA";
            $scope.userprofilecopy.user.joindate = val.joindate || "NA";
            $scope.userprofilecopy.user.subscriptionenddate = val.subscriptionenddate || "NA";
            $scope.userprofilecopy.user.accesscode = val.accesscode || "NA";
            $scope.userprofilecopy.user.subscriptionlevel = val.subscriptionlevel || "NA";
            $scope.userprofilecopy.user.isadmin = val.isadmin || "NA";
            $scope.userprofilecopy.user.dob = val.dob || "NA";
            $scope.userprofilecopy.user.createdAt = val.createdAt || "NA";
            $scope.userprofilecopy.user.updatedAt = val.updatedAt || "NA";
            $scope.userprofilecopy.user.status = val.status || "NA";
            // $scope.userprofilecopy.user.country = "Nigeria";

            console.log("$scope.userprofilecopy.user: ");
            console.log($scope.userprofilecopy.user);
        };

        $scope.setUserSchprofile = function(val) {
            console.log("vals: ");
            console.log(val);
            $scope.userprofile.sch.schnameaddy = val.schnameaddy || "NA";
            $scope.userprofile.sch.city = val.city || "NA";
            $scope.userprofile.sch.state = val.state || "NA";
            $scope.userprofile.sch.country = val.country || "NA";
            $scope.userprofile.sch.contactname = val.contactname || "NA";
            $scope.userprofile.sch.contactphone = val.contactphone || "NA";
            $scope.userprofile.sch.schphone = val.schphone || "NA";
            $scope.userprofile.sch.email = val.email || "NA";
            $scope.userprofile.sch.schdetails = val.schdetails || "NA";

            $scope.userprofilecopy.sch.username = val.username || "NA";
            $scope.userprofilecopy.sch.password = val.password || "NA";
            $scope.userprofilecopy.sch.schnameaddy = val.schnameaddy || "NA";
            $scope.userprofilecopy.sch.city = val.city || "NA";
            $scope.userprofilecopy.sch.state = val.state || "NA";
            $scope.userprofilecopy.sch.country = val.country || "NA";
            $scope.userprofilecopy.sch.contactname = val.contactname || "NA";
            $scope.userprofilecopy.sch.contactphone = val.contactphone || "NA";
            $scope.userprofilecopy.sch.schphone = val.schphone || "NA";
            $scope.userprofilecopy.sch.email = val.email || "NA";
            $scope.userprofilecopy.sch.schdetails = val.schdetails || "NA";
            $scope.userprofilecopy.sch.createdAt = val.createdAt || "NA";
            $scope.userprofilecopy.sch.updatedAt = val.updatedAt || "NA";
            // $scope.userprofilecopy.sch = $scope.userprofile.sch;
            console.log("$scope.userprofilecopy.sch: ");
            console.log($scope.userprofilecopy.sch);
        };

        $scope.changePic = function() {
            $scope.showupload = "";
            var file = $scope.myFile;
            console.log('changePic called...');
            var params = {
                Bucket: "ssceexams-user-pics",
                Key: window.sessionStorage.username + ".jpg",
                ContentType: file.type,
                Body: file,
                ACL: "public-read",
                Metadata: {
                    data: JSON.stringify({
                        title: window.sessionStorage.username,
                        description: 'uploaded at' + Date.now()
                    })
                }
            };
            console.log('params:....');
            console.log(params);

            $scope.uploadToS3(params);
        };

        $scope.uploadToS3 = function(params) {
            console.log("window.sessionStorage.config...");
            console.log(window.sessionStorage.config);
            AWS.config.update({
                accessKeyId: "AKIAJ7GUW7FH2V6D2ZKQ",
                secretAccessKey: "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"
            });
        
            var s3 = new AWS.S3();
            s3.putObject(params, function(err, data) {
                if(err) {
                    console.log('Something went wrong uploading your picture...');
                    console.log(err);
                } else {
                    console.log('Picture uploaded successfully...');
                    // save picture URL to user profile DDB table
                    $timeout(function(){
                        $scope.picUrl = "https://s3.amazonaws.com/ssceexams-user-pics/" + window.sessionStorage.username + ".jpg?cb=" + Date.now();
                        $scope.showupload = "showupload";
                        $route.reload;
                    }, 5000);                   
                }
            });
        };

        $scope.uploadFile = function () {
            var file = $scope.myFile;
            $scope.changePic();
        };

        $scope.getUserDetail = function() {
            $scope.setUserprofile(JSON.parse(DataStore.getUserProfile()));                    
        };        
        $scope.getUserDetail();

        $scope.getUserSchDetail = function() {
            $scope.setUserSchprofile(JSON.parse(DataStore.getUserSchProfile()));                    
        };        
        $scope.getUserSchDetail();

        $scope.editUserProfile = function() {
            LoggingService.postTrack("edituprof");
            console.log('editUserProfile clicked!');
            $('div.f14 .aboutyou').removeClass('youDisabled');
        };

        $scope.editUserSchoolProfile = function() {
            LoggingService.postTrack("editusprof");
            console.log('editUserSchoolProfile clicked!');
            $('div.f14 .aboutsch').removeClass('schDisabled');
        };

        $scope.setDisabled = function() {
            $('div.f14 .aboutyou').addClass('youDisabled');
            $('div.f14 .aboutsch').addClass('schDisabled');
        };

        $scope.schRegShow = function(cmmt, succval) {
            $scope.schregval = cmmt;
            $scope.succ = succval;
            $("#profregval").removeClass("hide");
            $timeout(function(){
                $("#profregval").addClass("hide");
                if(succval == 'succ') {
                    $location.path('dashboard');
                }
            }, 5000);
        };

        $scope.setDisabled();

        $scope.textChange = function(idx, val) {
            if(idx == "user") {
                if(val == 'fname') { $scope.addChangeBorder(val, $scope.userprofile.user.firstname, $scope.userprofilecopy.user.firstname); }
                if(val == 'lname') { $scope.addChangeBorder(val, $scope.userprofile.user.lastname, $scope.userprofilecopy.user.lastname); }
                if(val == 'straddy') { $scope.addChangeBorder(val, $scope.userprofile.user.straddy, $scope.userprofilecopy.user.straddy); }
                if(val == 'city') { $scope.addChangeBorder(val, $scope.userprofile.user.city, $scope.userprofilecopy.user.city); }
                if(val == 'state') { $scope.addChangeBorder(val, $scope.userprofile.user.state, $scope.userprofilecopy.user.state); }
                if(val == 'country') { $scope.addChangeBorder(val, $scope.userprofile.user.country, $scope.userprofilecopy.user.country); }
                if(val == 'tel') { $scope.addChangeBorder(val, $scope.userprofile.user.phone, $scope.userprofilecopy.user.phone); }
                if(val == 'email') { $scope.addChangeBorder(val, $scope.userprofile.user.email, $scope.userprofilecopy.user.email); }
                if(val == 'about') { $scope.addChangeBorder(val, $scope.userprofile.user.aboutyou, $scope.userprofilecopy.user.aboutyou); }
            } else if(idx == "sch") {
                if(val == 'schnameaddy') { $scope.addChangeBorder(val, $scope.userprofile.sch.schnameaddy, $scope.userprofilecopy.sch.schnameaddy); }
                if(val == 'cityy') { $scope.addChangeBorder(val, $scope.userprofile.sch.city, $scope.userprofilecopy.sch.city); }
                if(val == 'states') { $scope.addChangeBorder(val, $scope.userprofile.sch.state, $scope.userprofilecopy.sch.state); }
                if(val == 'countryy') { $scope.addChangeBorder(val, $scope.userprofile.sch.country, $scope.userprofilecopy.sch.country); }
                if(val == 'contactname') { $scope.addChangeBorder(val, $scope.userprofile.sch.contactname, $scope.userprofilecopy.sch.contactname); }
                if(val == 'contactphone') { $scope.addChangeBorder(val, $scope.userprofile.sch.contactphone, $scope.userprofilecopy.sch.contactphone); }
                if(val == 'schphone') { $scope.addChangeBorder(val, $scope.userprofile.sch.schphone, $scope.userprofilecopy.sch.schphone); }
                if(val == 'emaill') { $scope.addChangeBorder(val, $scope.userprofile.sch.email, $scope.userprofilecopy.sch.email); }
                if(val == 'schdetails') { $scope.addChangeBorder(val, $scope.userprofile.sch.schdetails, $scope.userprofilecopy.sch.schdetails); }
            }
        };

        $scope.addChangeBorder = function(val, val1, val2) {
            console.log("vals: " + val + ", " + val1 + ", " + val2);
            if(val1 !== val2) {
                $('#' + val).addClass('newborder');
            } else {
                $('#' + val).removeClass('newborder');
            }
        };

        $scope.saveUserProfile = function() {
            LoggingService.postTrack("saveuprof");
            console.log('saveUserProfile called...');
            console.log(_.isEqual($scope.userprofilecopy.user, $scope.userprofile.user));
            console.log($scope.userprofilecopy.user);
            if(!(_.isEqual($scope.userprofilecopy.user, $scope.userprofile.user))) {
                ApiService.saveUserProfile($scope.userprofilecopy.user)
                  .then(function(response) {
                    console.log("user response:...");
                    console.log(JSON.stringify(response));
                    if(response) {
                        if(response.status == 404) {
                            console.log('Profile Update Failed, ' + response.data.message);
                            $scope.schRegShow('Profile Update Failed, ' + response.data.message, 'errs');
                        } else if(response.status == 200) {
                            console.log(response);
                            $scope.schRegShow('Profile Updated Successfully', 'succ');
                            $('div.f14 .aboutyou').addClass('youDisabled');
                        }
                    }
                    DataStore.setUserProfile(null);
                    DataStore.setUserProfile(JSON.stringify(response));
                    $scope.schRegShow('User Profile Updated Successfully', 'succ');
                    $timeout(function(){
                        $location.path('dashboard');
                    }, 2000);                    
                }, function(error) {
                    $scope.schRegShow('Profile Updated Failed, Please Try Again!', 'errs');
                });
            } else {
                console.log('Nothing to save yet!');
                $scope.schRegShow('Profile Unchanged!', 'succ');
            }
        };

        $scope.saveUserSchoolProfile = function() {
            LoggingService.postTrack("saveusprof");
            // console.log('saveUserSchoolProfile called...');
            // console.log(_.isEqual($scope.userprofilecopy.sch, $scope.userprofile.sch));
            console.log('$scope.userprofileresult.username: ' + $scope.userprofileresult.username);
            if(!(_.isEqual($scope.userprofilecopy.sch, $scope.userprofile.sch))) {
                ApiService.saveUserSchoolProfile($scope.userprofilecopy.sch)
                  .then(function(response) {
                    console.log("sch response:...");
                    console.log(JSON.stringify(response));
                    if(response) {
                        if(response.status == 404) {
                            console.log('Profile Update Failed, ' + response.data.message);
                            $scope.schRegShow(response.data.message, 'errs');
                        } else if(response.status == 500) {
                            console.log('Profile Update Failed, ' + response.data.message);
                            $scope.schRegShow(response.data.message, 'errs');
                        } else if(response.status == 200) {
                            console.log(response);
                            $scope.schRegShow('Profile Updated Successfully', 'succ');
                            $('div.f14 .aboutsch').addClass('schDisabled');
                        }
                        DataStore.setUserSchProfile(null);
                        DataStore.setUserSchProfile(JSON.stringify(response));
                        $scope.schRegShow('School Profile Updated Successfully', 'succ');
                        $timeout(function(){
                            $location.path('dashboard');
                        }, 2000);                        
                    }
                }, function(error) {
                    $scope.schRegShow('Profile Updated Failed, Please Try Again!', 'errs');
                });
            } else {
                console.log('Nothing to save yet!');
                $scope.schRegShow('Profile Unchanged!', 'succ');
            }
        };

        $timeout(function(){
           HeaderService.setTab(3);
        }, 400);

    }
})();