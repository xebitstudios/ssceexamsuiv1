(function() {
    'use strict';

    angular
        .module('ssceexamsuiApp')
        .controller('LandingController', LandingController);

    // LandingController.$inject = ['$scope', '$log', '$location', '$controller', '$rootScope', 'ConfigService', 'DataStore', 'LoggingService', 'HeaderService', 'ApiService', 'growl', '$timeout'];

    /* @ngInject */
    function LandingController($scope, $log, $location, $controller, $rootScope, ConfigService, DataStore, LoggingService, HeaderService, ApiService, growl, $timeout) {

        $controller('BaseController', {$scope: $scope});
        $rootScope.baseRoute = '';
        var baseRoute = '';
        $scope.pgwidth = true;

        console.log('page width is: ' + $('body').width());

        $scope.testcenter = function() {
            LoggingService.postTrack("dash-tc");
            console.log('Testcenter link clicked!');
            $location.path(baseRoute + 'testcenter');
        };

        $scope.analytics = function() {
            LoggingService.postTrack("dash-analy");
            console.log('Analytics link clicked!');
            $location.path(baseRoute + 'analytics');
        };

        $scope.profile = function() {
            LoggingService.postTrack("prof");
            console.log('Profile link clicked!');
            $location.path(baseRoute + 'profile');
        };

        $scope.loginclick = function() {
            console.log('Log in link clicked!');
            $location.path(baseRoute);
        };

        $scope.signupclick = function() {
            LoggingService.postTrack("signup");
            console.log('Sign up link clicked!');
            $location.path(baseRoute + 'signup');
        };

        if(window.sessionStorage.act) {
            $scope.getTheUsers = function() {
                ApiService.getUsers();
            };
        
            ApiService.getUserToprow($rootScope.userid).then(function(response) {
                if(response.username) {
                    console.log("DataStore.getUserToprow(): ")
                    DataStore.setUserToprow(JSON.stringify(response));              
                    $scope.setToprow(response);
                } else {
                    DataStore.setUserToprow(JSON.stringify({})); 
                }
            });

            ApiService.getChart1($rootScope.userid, 'English', '2001').then(function(response) {
                console.log("Preloading DataStore.getChart1(): ")
                if(response.username) {
                    DataStore.setChart1($rootScope.userid, 'English', '2001', JSON.stringify(response));
                } else {
                    DataStore.setChart1($rootScope.userid, 'English', '2001', JSON.stringify(response));
                }
            });

            ApiService.getChart2($rootScope.userid, 'English', '2001').then(function(response) {
                console.log("Preloading DataStore.getChart2(): ")
                if(response.username) {
                    DataStore.setChart2($rootScope.userid, 'English', '2001', JSON.stringify(response));
                } else {
                    DataStore.setChart2($rootScope.userid, 'English', '2001', JSON.stringify(response));
                }
            });

            ApiService.getChart3($rootScope.userid, 2001).then(function(response) {
                console.log("Preloading DataStore.getChart3(): ")
                if(response.username) {
                    DataStore.setChart3($rootScope.userid, 2001, JSON.stringify(response));
                } else {
                    DataStore.setChart3($rootScope.userid, 2001, JSON.stringify(response));
                }
            }); 

            ApiService.getChart4($rootScope.userid, 'top3').then(function(response) {
                console.log("Preloading DataStore.getChart4(): ")
                if(response.username) {
                    DataStore.setChart4($rootScope.userid, 'top3', JSON.stringify(response));
                } else {
                    DataStore.setChart4($rootScope.userid, 'top3', JSON.stringify(response));
                }
            });

            ApiService.getChart5($rootScope.userid, 'English').then(function(response) {
                console.log("Preloading DataStore.getChart5(): ")
                if(response.username) {
                    DataStore.setChart5($rootScope.userid, 'English', JSON.stringify(response));
                } else {
                    DataStore.setChart5($rootScope.userid, 'English', JSON.stringify(response));
                }                    
            }); 

            ApiService.getChart6($rootScope.userid, 'English').then(function(response) {
                console.log("Preloading DataStore.getChart6(): ")
                if(response.username) {
                    DataStore.setChart6($rootScope.userid, 'English', JSON.stringify(response));
                } else {
                    DataStore.setChart6($rootScope.userid, 'English', JSON.stringify(response));
                }                   
            });
        };

        $timeout(function(){
           HeaderService.setTab(0);
           if ($('body').width() < 600) {
              $scope.pgwidth = false;
            } else {
              $scope.pgwidth = true;
            }          
            LoggingService.postTrack("dash");
        }, 100);
    }
})();