(function() {
	'use strict';

	angular
        .module('ssceexamsuiApp')
		.factory('LoggingService', LoggingService);

		// LoggingService.$inject = ['window'];

		/* @ngInject */
		function LoggingService($http, $q, growl, $rootScope, ApiService, DataStore, window) {

			var logss = {
				logs: []
			};

			// var sqs = window.AWS.SQS;
			// console.log("SQS...");
			// console.log(sqs);

			return {
				postTrack: postTrack,
				attTrack: attTrack,
				compTrack: compTrack
			};

			function myDate() {
				return new Date();
			}

			function httpPromise (vobj) {
				var deferred = $q.defer();
				$http(vobj)
					.success(function(response) {
						deferred.resolve(response);
					})
					.error(function() {
						deferred.reject();
					});
				return deferred.promise;
			};

			// gives "L_1_14_2018_16_11_24_747"
			function getDate() {
				return "L_" + (myDate().getMonth() + 1) + "_" +
					 myDate().getDate() + "_" + 
					 myDate().getFullYear() + '_' + 
					 myDate().getHours() + "_" + 
					 myDate().getMinutes() + "_" + 
					 myDate().getSeconds() + "_" + 
					 myDate().getMilliseconds() + '*';
			};

			function getDatee() {
				return "A_" + (myDate().getMonth() + 1) + "_" +
					 myDate().getDate() + "_" + 
					 myDate().getFullYear() + '_' + 
					 myDate().getHours() + "_" + 
					 myDate().getMinutes() + "_" + 
					 myDate().getSeconds() + "_" + 
					 myDate().getMilliseconds() + '*';
			};

			function getDatec() {
				return "C_" + (myDate().getMonth() + 1) + "_" +
					 myDate().getDate() + "_" + 
					 myDate().getFullYear() + '_' + 
					 myDate().getHours() + "_" + 
					 myDate().getMinutes() + "_" + 
					 myDate().getSeconds() + "_" + 
					 myDate().getMilliseconds() + '*';
			};

			function postTrack(val) {
				// val is the new log entry we want to store in the DataStore
				if(window.sessionStorage.act) {
					if(logss.logs.length < 1) {
						logss.logs.push(getDate() + "" + val + "**");
						DataStore.setLogs($rootScope.userid, JSON.stringify(logss));
						console.log(DataStore.getLogs());
					} else if(logss.logs.length > 10) {
						logss.logs.push(getDate() + "" + val + "**");
						console.log(logss.logs);
						DataStore.setLogs($rootScope.userid, JSON.stringify({logs: logss.logs}));
						console.log("sending out the logs now and clearing logs cache...");
						ApiService.sendLogs();
						logss.logs = [];
						console.log("All Cleeear");
						console.log(logss);
					} else {
						logss.logs.push(getDate() + "" + val + "**");
						DataStore.setLogs($rootScope.userid, JSON.stringify({logs: logss.logs}));
						console.log("Yeeep");
						console.log(logss);
					}
				}
			};

			function attTrack(val) {
				// val is the new log entry we want to store in the DataStore
				if(window.sessionStorage.act) {
					if(logss.logs.length < 1) {
						logss.logs.push(getDatee() + "" + window.sessionStorage.currentSubject + "_" + window.sessionStorage.currentYear + "**");
						DataStore.setLogs($rootScope.userid, JSON.stringify(logss));
						console.log(DataStore.getLogs());
					} else if(logss.logs.length > 10) {
						logss.logs.push(getDatee() + "" + window.sessionStorage.currentSubject + "_" + window.sessionStorage.currentYear + "**");
						console.log(logss.logs);
						DataStore.setLogs($rootScope.userid, JSON.stringify({logs: logss.logs}));
						console.log("sending out the logs now and clearing logs cache...");
						ApiService.sendLogs();
						logss.logs = [];
						console.log("All Cleeear");
						console.log(logss);
					} else {
						logss.logs.push(getDatee() + "" + window.sessionStorage.currentSubject + "_" + window.sessionStorage.currentYear + "**");
						DataStore.setLogs($rootScope.userid, JSON.stringify({logs: logss.logs}));
						console.log("Yeeep");
						console.log(logss);
					}
				}
			};

			function compTrack(val) {
				// val is the new log entry we want to store in the DataStore
				if(window.sessionStorage.act) {
					if(logss.logs.length < 1) {
						logss.logs.push(getDatec() + "" + window.sessionStorage.currentSubject + "_" + window.sessionStorage.currentYear + "**");
						DataStore.setLogs($rootScope.userid, JSON.stringify(logss));
						console.log(DataStore.getLogs());
					} else if(logss.logs.length > 10) {
						logss.logs.push(getDatec() + "" + window.sessionStorage.currentSubject + "_" + window.sessionStorage.currentYear + "**");
						console.log(logss.logs);
						DataStore.setLogs($rootScope.userid, JSON.stringify({logs: logss.logs}));
						console.log("sending out the logs now and clearing logs cache...");
						ApiService.sendLogs();
						logss.logs = [];
						console.log("All Cleeear");
						console.log(logss);
					} else {
						logss.logs.push(getDatec() + "" + window.sessionStorage.currentSubject + "_" + window.sessionStorage.currentYear + "**");
						DataStore.setLogs($rootScope.userid, JSON.stringify({logs: logss.logs}));
						console.log("Yeeep");
						console.log(logss);
					}
				}
			};
		}
})();

