(function() {
    'use strict';

    angular
        .module('ssceexamsuiApp')
        .factory('ApiService', ApiService);

    // ApiService.$inject = ['$http', '$q', 'growl', '$rootScope', 'DataStore', 'window'];

    /* @ngInject */
    function ApiService($http, $q, growl, $rootScope, DataStore, window, ConfigService) {

        return {
            getPhysicsSectionA: getPhysicsSectionA,
            getPhysicsSectionB: getPhysicsSectionB,
            getEnglishSectionB: getEnglishSectionB,
            getEconomicsSectionB: getEconomicsSectionB,
            getGeographySectionB: getGeographySectionB,
            getMathematicsSectionB: getMathematicsSectionB,
            getAgricSciSectionB: getAgricSciSectionB,
            getGovernmentSectionB: getGovernmentSectionB,
            getCommerceSectionB: getCommerceSectionB,
            getBiologySectionB: getBiologySectionB,
            getLitInEngSectionB: getLitInEngSectionB,
            getChemistrySectionB: getChemistrySectionB,
            postLoginForm: postLoginForm,
            getUserDetails: getUserDetails,
            getUserSchDetails: getUserSchDetails,
            getUserToprow: getUserToprow,
            getChart1: getChart1,
            getChart2: getChart2,
            getChart3: getChart3,
            getChart4: getChart4,
            getChart5: getChart5,
            getChart6: getChart6,
            newUser: newUser,
            // getUsers: getUsers,
            getUserById: getUserById,
            getUserByUnameAndPwd: getUserByUnameAndPwd,
            putUser: putUser,
            deleteUser: deleteUser,
            getAnalyticsdata: getAnalyticsdata,
            chart1Update: chart1Update,
            chart2Update: chart2Update,
            chart3Update: chart3Update,
            chart4Update: chart4Update,
            chart5Update: chart5Update,
            chart6Update: chart6Update,
            sendContactInfo: sendContactInfo,
            registerUser: registerUser,
            forgotpwdUser: forgotpwdUser,
            confirmUpgrade: confirmUpgrade,
            registerSchool: registerSchool,
            postImage: postImage,
            saveUserProfile: saveUserProfile,
            saveUserSchoolProfile: saveUserSchoolProfile,
            getUserProfileDetails: getUserProfileDetails,
            postUserProfileDetails: postUserProfileDetails,
            sendLogs: sendLogs
        };

        function httpPromise(vobj) {
            // vobj.headers.appid = 'ssceexms';
            console.log('vobj.url is: ' + vobj.url);
            var deferred = $q.defer();
            $http(vobj)
                .success(function(response) {
                    deferred.resolve(response);
                })
                .error(function() {
                    deferred.reject();
                });
            return deferred.promise;
        };

        function sendLogs() {
            console.log("DataStore.getLogs(window.sessionStorage.username 1 2 3)");
            console.log(DataStore.getLogs(window.sessionStorage.username));
            console.log(DataStore.getLogs(window.sessionStorage.username).logs);
            console.log(DataStore.getLogs(window.sessionStorage.username).logs.join());
            console.log('sending out logs data');
            console.log(JSON.stringify(DataStore.getLogs(window.sessionStorage.username)));
            var vObj = {
                method: 'POST',
                url: ConfigService.setapi() + 'fhose/', // /logs goes to SQS, /send goes to Kinesis streams, /fhose to firehose
                data: {
                    "DeliveryStreamName": "ssceexams_logs_delivery_stream",
                    "Record": {
                        "Data": window.sessionStorage.username + ':::' + DataStore.getLogs(window.sessionStorage.username).logs.join()
                    }
                },
                headers: {
                    'Content-Type': 'application/json;charset=UTF-8',
                    'Authorization': $rootScope.token || window.sessionStorage.act
                }
            };
            return httpPromise(vObj);
        };

        // function getUsers() {
        //     console.log('calling the getUsers data');
        //     var vObj = {
        //         method: 'GET',
        //         url: ConfigService.getapi() + '/api/users',
        //         headers: {
        //             'Content-Type': 'application/json;charset=UTF-8',
        //             'Authorization': $rootScope.token || window.sessionStorage.act
        //         }
        //     };
        //     return httpPromise(vObj);
        // };

        function postImage(val) {
            console.log('Now in ApiService.postImage()');
            console.log(val.fd);
            var deferred = $q.defer();
            $http.post(ConfigService.getapi() + '/api/postimage', val.fd, {
                    transformRequest: angular.identity,
                    headers: {
                        'Content-Type': undefined, //'multipart/form-data',
                        'Authorization': $rootScope.token || window.sessionStorage.act
                    }
                })
                .success(function(response) {
                    deferred.resolve(response);
                })
                .error(function() {
                    deferred.reject();
                });
            return deferred.promise;
        };

        function saveUserProfile(val) {
            console.log('save user profile details for user: ' + val.username);
            console.log(val);
            var vObj = {
                method: 'PUT',
                url: ConfigService.setapi() + 'student/' + val.username,
                data: JSON.stringify(val),
                headers: {
                    'Content-Type': 'application/json;charset=UTF-8',
                    'Authorization': $rootScope.token || window.sessionStorage.act
                }
            };
            return httpPromise(vObj);
        };

        function saveUserSchoolProfile(val) {
            console.log('save school profile details for user ' + window.sessionStorage.username);
            console.log(val);
            var vObj = {
                method: 'PUT',
                url: ConfigService.setapi() + 'school/' + window.sessionStorage.username,
                data: JSON.stringify(val),
                headers: {
                    'Content-Type': 'application/json;charset=UTF-8',
                    'Authorization': $rootScope.token || window.sessionStorage.act
                }
            };
            return httpPromise(vObj);
        };

        function getUserProfileDetails(userid) {
            console.log('user profile details for user: ' + userid);
            var vObj = {
                method: 'GET',
                url: ConfigService.setapi() + '/profile?uname=' + userid,
                data: userid,
                headers: {
                    'Content-Type': 'application/json;charset=UTF-8',
                    'Authorization': $rootScope.token || window.sessionStorage.act
                }
            };
            return httpPromise(vObj);
        };

        function getUserSchDetails(uname) {
            console.log('calling getUserSchDetails... with ' + uname);
            var vObj = {
                method: 'GET',
                url: ConfigService.setapi() + 'school/' + uname,
                headers: {
                    'Content-Type': 'application/json;charset=UTF-8',
                    'Authorization': $rootScope.token || window.sessionStorage.act
                }
            };
            return httpPromise(vObj);
        };

        function getUserDetails(uname, pwd) {
            console.log('calling getUserDetails... with ' + uname + ', ' + pwd);
            var vObj = {
                method: 'GET',
                url: ConfigService.setapi() + 'user/' + uname + '/' + pwd,
                headers: {
                    'Content-Type': 'application/json;charset=UTF-8',
                    'Authorization': $rootScope.token || window.sessionStorage.act
                }
            };
            return httpPromise(vObj);
        };
        
        function registerUser(userdetails) {
            console.log('registering new user with details: ');
            console.log(userdetails);
            var vObj = {
                method: 'POST',
                url: ConfigService.setapi() + 'student',
                data: JSON.stringify({
                    email: userdetails.email,
                    username: userdetails.uname,
                    password: userdetails.pword,
                    firstname: "NA",
                    lastname: "NA",
                    joindate: new Date(),
                    subscriptionlevel: "free",
                    dob: "NA",
                    status: "active",
                    accesscode: "NA",
                    subjectslist: "all",
                    subscriptionstartdate: Date(),
                    subscriptionenddate: "free",
                    isadmin: "No"
                }),
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': window.sessionStorage.act
                }
            };
            return httpPromise(vObj);
        };

        function postLoginForm(val) {
            console.log('calling postLoginForm... with ' + val.uname + ', ' + val.pwd + '.');
            var vObj = {
                method: 'GET',
                // url: ConfigService.setapi() + 'user/' + val.uname + '/' + val.pwd,
                url: ConfigService.setapi() + 'student/' + val.uname,
                headers: {
                    'Content-Type': 'application/json;charset=UTF-8',
                    'Authorization': $rootScope.token || window.sessionStorage.act
                }
            };
            return httpPromise(vObj);
        };

        function getUserToprow(val) {
            console.log('calling getUserToprow... with ' + val);
            var vObj = {
                method: 'GET',
                url: ConfigService.setapi() + 'charts/toprow/' + val,
                headers: {
                    'Content-Type': 'application/json;charset=UTF-8',
                    'Authorization': $rootScope.token || window.sessionStorage.act
                }
            };
            return httpPromise(vObj);
        };
        
        function getChart1(uname, subj, yr) {
            console.log('calling getChart1... with ' + uname + '-' + subj + '-' + yr);
            var vObj = {
                method: 'GET',
                url: ConfigService.setapi() + 'chart1/' + uname + '-' + subj + '-' + yr + '',
                headers: {
                    'Content-Type': 'application/json;charset=UTF-8',
                    'Authorization': $rootScope.token || window.sessionStorage.act
                }
            };
            return httpPromise(vObj);
        };

        function getChart2(uname, subj, yr) {
            console.log('calling getChart2... with ' + uname + '-' + subj + '-' + yr);
            var vObj = {
                method: 'GET',
                url: ConfigService.setapi() + 'chart2/' + uname + '-' + subj + '-' + yr + '',
                headers: {
                    'Content-Type': 'application/json;charset=UTF-8',
                    'Authorization': $rootScope.token || window.sessionStorage.act
                }
            };
            return httpPromise(vObj);
        };

        function getChart3(uname, yr) {
            console.log('calling getChart3... with ' + uname + '-' + yr);
            var vObj = {
                method: 'GET',
                url: ConfigService.setapi() + 'chart3/' + uname + '-' + yr,
                headers: {
                    'Content-Type': 'application/json;charset=UTF-8',
                    'Authorization': $rootScope.token || window.sessionStorage.act
                }
            };
            return httpPromise(vObj);
        };

        function getChart4(uname, topval) {
            console.log('calling getChart4... with ' + uname + '-' + topval);
            var vObj = {
                method: 'GET',
                url: ConfigService.setapi() + 'chart4/' + uname + '-' + topval,
                headers: {
                    'Content-Type': 'application/json;charset=UTF-8',
                    'Authorization': $rootScope.token || window.sessionStorage.act
                }
            };
            return httpPromise(vObj);
        };

        function getChart5(uname, subj) {
            console.log('calling getChart5... with ' + uname + '-' + subj);
            var vObj = {
                method: 'GET',
                url: ConfigService.setapi() + 'chart5/' + uname + '-' + subj,
                headers: {
                    'Content-Type': 'application/json;charset=UTF-8',
                    'Authorization': $rootScope.token || window.sessionStorage.act
                }
            };
            return httpPromise(vObj);
        };

        function getChart6(uname, subj) {
            console.log('calling getChart6... with ' + uname + '-' + subj);
            var vObj = {
                method: 'GET',
                url: ConfigService.setapi() + 'chart6/' + uname + '-' + subj,
                headers: {
                    'Content-Type': 'application/json;charset=UTF-8',
                    'Authorization': $rootScope.token || window.sessionStorage.act
                }
            };
            return httpPromise(vObj);
        };

        function registerSchool(schappdetails) {
            console.log('school application details: ');
            console.log(schappdetails);
            var vObj = {
                method: 'POST',
                url: ConfigService.setapi() + 'apply',
                data: JSON.stringify(schappdetails),
                headers: {
                    'Content-Type': 'application/json;charset=UTF-8',
                    'Authorization': $rootScope.token || window.sessionStorage.act
                }
            };
            return httpPromise(vObj);
        };

        function forgotpwdUser(userdetails) {
            console.log('password recovery for user with details: ');
            console.log(userdetails);
            var vObj = {
                method: 'POST',
                url: ConfigService.getapi() + '/api/forgotpwdUser',
                data: JSON.stringify(userdetails),
                headers: {
                    'Content-Type': 'application/json;charset=UTF-8',
                    'Authorization': $rootScope.token || window.sessionStorage.act
                }
            };
            return httpPromise(vObj);
        };

        function confirmUpgrade(userid, upgfrom, upgto) {
            console.log('upgrading user: ' + userid + ' from ' + upgfrom + ' to ' + upgto);
            var vObj = {
                method: 'POST',
                url: ConfigService.setapi() + 'upgrades/',
                data: JSON.stringify({
                    username: userid,
                    upgdate: Date(),
                    upgfrom: upgfrom,
                    upgto: upgto,
                    updatedAt: 1,
                    createdAt: 1
                }),
                headers: {
                    'Content-Type': 'application/json;charset=UTF-8',
                    'Authorization': $rootScope.token || window.sessionStorage.act
                }
            };
            return httpPromise(vObj);
        };

        function GetFormattedDate() {
            var todayTime = new Date();
            var month = todayTime.getMonth() + 1;
            var day = todayTime.getDate();
            var year = todayTime.getFullYear();
            return month + "-" + day + "-" + year;
        };

        function postUserProfileDetails(username, uemail) {
            console.log('Creating profile for new user...');
            console.log('username: ' + username);
            console.log('email: ' + uemail);
            var vObj = {
                method: 'POST',
                url: ConfigService.setapi() + 'profile/create',
                data: JSON.stringify({
                    email: uemail,
                    username: username
                }),
                headers: {
                    'Content-Type': 'application/json;charset=UTF-8',
                    'Authorization': $rootScope.token || window.sessionStorage.act
                }
            };
            return httpPromise(vObj);
        };

        function sendContactInfo(msg) {
            console.log('sending the Contact Us form data: ');
            console.log(msg);
            var vObj = {
                method: 'POST',
                url: ConfigService.setapi() + 'contactus',
                data: JSON.stringify(msg),
                headers: {
                    'Content-Type': 'application/json;charset=UTF-8',
                    'Authorization': $rootScope.token || window.sessionStorage.act
                }
            };
            return httpPromise(vObj);
        };

        function getAnalyticsdata(username) {
            console.log('calling the getAnalyticsdata with user: ' + username);
            var vObj = {
                method: 'GET',
                url: ConfigService.getapi() + '/getanalyticsdata?uname=' + username,
                headers: {
                    'Content-Type': 'application/json;charset=UTF-8',
                    'Authorization': $rootScope.token || window.sessionStorage.act
                }
            };
            return httpPromise(vObj);
        };

        function getDate() {
            return new Date().getUTCDate() + '/' + (new Date().getUTCMonth() + 1) + '/' +  new Date().getUTCFullYear();
        }

        function chart1Update(subj, yr, data, username) {
            console.log('POSTing the chart1Update');
            console.log("subj: " + subj);
            console.log("yr: " + yr);
            console.log("data: " + data);
            console.log("username: " + username);
            var vObj = {
                method: 'POST',
                url: ConfigService.getapi() + 'chart1',
                data: JSON.stringify({
                    subj: subj,
                    yr: yr,
                    data: data,
                    dataDate: getDate(),
                    username: username
                }),
                headers: {
                    'Content-Type': 'application/json;charset=UTF-8',
                    'Authorization': $rootScope.token || window.sessionStorage.act
                }
            };
            return httpPromise(vObj);
        };

        function chart2Update(subj, yr, data, username) {
            console.log('POSTing the chart2Update');
            console.log("subj: " + subj);
            console.log("yr: " + yr);
            console.log("data: " + data);
            console.log("username: " + username);
            var vObj = {
                method: 'POST',
                url: ConfigService.getapi() + 'chart2/' + username,
                data: JSON.stringify({
                    subj: subj,
                    yr: yr,
                    dataDate: getDate(),
                    username: username
                }),
                headers: {
                    'Content-Type': 'application/json;charset=UTF-8',
                    'Authorization': $rootScope.token || window.sessionStorage.act
                }
            };
            return httpPromise(vObj);
        };

        function chart3Update(yr, username) {
            console.log('POSTing the chart3Update');
            var vObj = {
                method: 'POST',
                url: ConfigService.getapi() + '/analytics/chart3?uname=' + username,
                data: JSON.stringify({
                    yr: yr,
                    username: username
                }),
                headers: {
                    'Content-Type': 'application/json;charset=UTF-8',
                    'Authorization': $rootScope.token || window.sessionStorage.act
                }
            };
            return httpPromise(vObj);
        };

        function getTopType(val) {
            return val.substr(0, val.length-1) + " " + val.substr(val.length-1, val.length);
        };

        function chart4Update(toptyp, username) {
            console.log('POSTing the chart4Update');
            var vObj = {
                method: 'POST',
                url: ConfigService.getapi() + '/analytics/chart4?uname=' + username,
                data: JSON.stringify({
                    toptype: getTopType(toptyp),
                    username: username
                }),
                headers: {
                    'Content-Type': 'application/json;charset=UTF-8',
                    'Authorization': $rootScope.token || window.sessionStorage.act
                }
            };
            return httpPromise(vObj);
        };

        function chart5Update(subj, username) {
            console.log('POSTing the chart5Update');
            var vObj = {
                method: 'POST',
                url: ConfigService.getapi() + '/analytics/chart5?uname=' + username,
                data: JSON.stringify({
                    subj: subj,
                    username: username
                }),
                headers: {
                    'Content-Type': 'application/json;charset=UTF-8',
                    'Authorization': $rootScope.token || window.sessionStorage.act
                }
            };
            return httpPromise(vObj);
        };

        function chart6Update(subj, username) {
            console.log('POSTing the chart6Update');
            var vObj = {
                method: 'POST',
                url: ConfigService.getapi() + '/analytics/chart6?uname=' + username,
                data: JSON.stringify({
                    subj: subj,
                    username: username
                }),
                headers: {
                    'Content-Type': 'application/json;charset=UTF-8',
                    'Authorization': $rootScope.token || window.sessionStorage.act
                }
            };
            return httpPromise(vObj);
        };

        function getUserById(id) {
            console.log('calling the getUser data: ' + id);
            var vObj = {
                method: 'GET',
                url: ConfigService.getapi() + '/api/user?id=' + id,
                headers: {
                    'Content-Type': 'application/json;charset=UTF-8',
                    'Authorization': $rootScope.token || window.sessionStorage.act
                }
            };
            return httpPromise(vObj);
        };

        function getUserByUnameAndPwd(uname, pwd) {
            console.log('calling the getUserByUnameAndPwd for username: ' + uname + ', password: ' + pwd);
            var vObj = {
                method: 'GET',
                url: ConfigService.getapi() + '/api/user?name=' + uname + '&password=' + pwd,
                headers: {
                    'Content-Type': 'application/json;charset=UTF-8',
                    'Authorization': $rootScope.token || window.sessionStorage.act
                }
            };
            return httpPromise(vObj);
        };

        function putUser(id, name) {
            console.log('calling the putUser, id: ' + id + ', name: ' + name);
            var vObj = {
                method: 'PUT',
                url: ConfigService.getapi() + '/api/user?id=' + id,
                data: JSON.stringify({
                    name: name
                }),
                headers: {
                    'Content-Type': 'application/json;charset=UTF-8',
                    'Authorization': $rootScope.token || window.sessionStorage.act
                }
            };
            return httpPromise(vObj);
        };

        function newUser() {
            console.log('POSTing the newUser');
            var vObj = {
                method: 'POST',
                url: ConfigService.setapi() + 'student',
                data: JSON.stringify({
                    username: window.sessionStorage.username,
                    password: window.sessionStorage.password,
                    firstname: "",
                    lastname: "",
                    status: "active",
                    dob: "NA",
                    email: window.sessionStorage.email,
                    isadmin: "No",
                    subjectslist: "all",
                    subscriptionlevel: "free",
                    subscriptionstartdate: new Date(),
                    subscriptionenddate: "free",
                    aboutyou: "",
                    city: "",
                    country: ""
                }),
                headers: {
                    'Content-Type': 'application/json;charset=UTF-8',
                    'Authorization': $rootScope.token || window.sessionStorage.act
                }
            };
            return httpPromise(vObj);
        };

        function deleteUser(id) {
            console.log('calling the deleteUser data: ' + id);
            var vObj = {
                method: 'DELETE',
                url: ConfigService.getapi() + '/api/user?id=' + id,
                headers: {
                    'Content-Type': 'application/json;charset=UTF-8',
                    'Authorization': $rootScope.token || window.sessionStorage.act
                }
            };
            return httpPromise(vObj);
        };

        // ConfigService.dataPath() + 
        function getObjYrJson(subj, yr) {
            console.log('123 calling the getObjYrJson data, subj: ' + subj + ', year: ' + yr + '.');
            // return this.http.get(this.url + subject + '/' + subject + year + '.json');
            return $http.get('https://s3.amazonaws.com/ssceexamsdata/' + subj + '/' + subj + '' + yr + '.json')
                .then(function(response) {
                    // optt.replace('assets/imgs/', 'https://s3.amazonaws.com/ssceexamsdata/imgs/')
                    for(var a=0;a<response.data.length;a++) {
                        response.data[a].qs = response.data[a].qs.replace('assets/imgs/', 'https://s3.amazonaws.com/ssceexamsdata/imgs/');
                        for(var b=0;b<response.data[a].opts.length;b++) {
                            response.data[a].opts[b] = response.data[a].opts[b].replace('assets/imgs/', 'https://s3.amazonaws.com/ssceexamsdata/imgs/');
                        }
                    }
                    console.log('API response is...', response);
                    return response;
                });
        };

        function getPhysicsSectionA(val) {
            console.log('Year selected is: ' + val);
            var vObj = {
                "Q1": {
                    "a": {
                        "q0": "(a) Explain with the aid of a diagram what is meant by the moment of a force about a point,"
                    },
                    "b": {
                        "q0": "(b) State the conditions of equilibrium for a number of coplana parallel forces. A metre rule is found to balance at the 48 cm mark. When a body of mass 60g is suspended at the 6cm mark the balance point is found to be at the 30 cm mark. Calculate",
                        "q1": "(i) the mass of the metre rule",
                        "q2": "(ii) the distance of the balance point from the zero end, if the body were moved to the 13cm mark,"
                    },
                    "c": {
                        "q0": "(c) Show that the efficiency E, the force ratio M.A. and the velocity ratio V.R of a machine are related by the equation.",
                        "q1": "E = (M.A x 100%)/V.R",
                        "q2": "The efficiency of a machine is 80%. Determine the work done by a person using this machine to raise a load of 200kg through a vertical distance of 3.0 m (Take g = 10 ms^2)."
                    }
                },
                "Q2": {
                    "a": {
                        "q0": "(a) Draw a labelled diagram of a vacuum flask. Explain how its construction minimizes heat exchange with the surroundings,"
                    },
                    "b": {
                        "q0": "(b) State Boyle’s law. A thread of mercury of length 15cm is used to trap some air in a capillary tube with uniform cross-sectional area and closed at one end with the tube vertical and the open end uppermost, the length of the trapped air column is 20 cm. Calculate the length of the air column when the tube is held: ",
                        "q1": "(i) horizontally, ",
                        "q2": "(ii) vertically with the open end underneath. (Atmospheric pressure = 76 cm of mercury),"
                    },
                    "c": {
                        "q0": "(c) Explain why it is not advisable to sterilize a clinical thermometer in boiling water at normal atmospheric pressure."
                    }
                },
                "Q3": {
                    "a": {
                        "q0": "(a) Explain with the aid of a diagram how a converging lens could be used to: ",
                        "q1": "(i) ignite a piece of carbon paper,",
                        "q2": "(ii) produce an enlarged picture on a screen,",
                        "q3": "(iii) correct an eye defect,"
                    },
                    "b": {
                        "q0": "(b) What is a mechanical wave? Describe with the aid of a diagram, an experiment to show that sound needs a material medium for transmission. State three characteristics of sound and mention the factor on which each depends."
                    }
                },
                "Q4": {
                    "a": {
                        "q0": "(a) Explain what is meant by: ",
                        "q1": "(i) electric field intensity,",
                        "q2": "(ii) electric lines of force,"
                    },
                    "b": {
                        "q0": "(b) Two similar but opposite point charges - q and + q each of magnitude 5.0 x 10' 8C are separated by a distance of 8.0cm in vacuum as shown in the diagram below.",
                        "q1": "img**phys_1998_sectiona_qst4_b_1.jpg",
                        "q2": "Calculate the magnitude and direction of the resultant electric field intensity E at the point P. Draw the lines of force due to this system of charges.",
                        "q3": "Take 1/(4ml) = 9 x 10 NmC"
                    },
                    "c": {
                        "q0": "(c) Calculate the following in the series circuit shown above: ",
                        "q1": "(i) reactance of the capacitor,",
                        "q2": "(ii) impedance of the circuit,",
                        "q3": "(iii) current through the circuit,",
                        "q4": "(iv) voltage across the capacitor,",
                        "q5": "(v) average power used in the circuit.",
                        "q6": "img**phys_1998_sectiona_qst4_c_1.jpg"
                            // "q7": "/img/physics/myimage.jpg"
                    }
                }
            };
            return vObj;
        };

        function getAgricSciSectionB(val) {
            console.log('AgricSci Year selected is: ' + val);

            if (val == 1988) {
                return getObjYrJson('agriculture', '1988');
            } else if (val == 1989) {
                return getObjYrJson('agriculture', '1989');
            } else if (val == 1990) {
                return getObjYrJson('agriculture', '1990');
            } else if (val == 2015) {
                return getObjYrJson('agriculture', '2015');
            } else {
                return getObjYrJson('agriculture', '1988');
            }
        };

        function getMathematicsSectionB(val) {
            console.log('Mathematics Year selected is: ' + val);

            if (val == 1988) {
                return getObjYrJson('maths', '1988');
            } else if (val == 1989) {
                return getObjYrJson('maths', '1989');
            } else if (val == 1990) {
                return getObjYrJson('maths', '1990');
            } else if (val == 1991) {
                return getObjYrJson('maths', '1991');
            } else if (val == 1992) {
                return getObjYrJson('maths', '1992');
            } else if (val == 1993) {
                return getObjYrJson('maths', '1993');
            } else if (val == 2012) {
                return getObjYrJson('maths', '2012');
            } else if (val == 2013) {
                return getObjYrJson('maths', '2013');
            } else if (val == 2014) {
                return getObjYrJson('maths', '2014');
            } else if (val == 2015) {
                return getObjYrJson('maths', '2015');
            } else {
                return getObjYrJson('maths', '1988');
            }
        };

        function getGeographySectionB(val) {
            console.log('Geography Year selected is: ' + val);

            if (val == 1988) {
                return getObjYrJson('geography', '1988');
            } else if (val == 1989) {
                return getObjYrJson('geography', '1989');
            } else if (val == 1990) {
                return getObjYrJson('geography', '1990');
            } else if (val == 2015) {
                return getObjYrJson('geography', '2015');
            } else {
                return getObjYrJson('geography', '1988');
            }
        };

        function getEconomicsSectionB(val) {
            console.log('Economics Year selected is: ' + val);

            if (val == 1988) {
                return getObjYrJson('economics', '1988');
            } else if (val == 1989) {
                return getObjYrJson('economics', '1989');
            } else if (val == 1990) {
                return getObjYrJson('economics', '1990');
            } else if (val == 2015) {
                return getObjYrJson('economics', '2015');
            } else {
                return getObjYrJson('economics', '1988');
            }
        };

        function getEnglishSectionB(val) {
            console.log('English Year selected is: ' + val);

            if (val == 1988) {
                return getObjYrJson('english', '1988');
            } else if (val == 1989) {
                return getObjYrJson('english', '1989');
            } else if (val == 1990) {
                return getObjYrJson('english', '1990');
            } else if (val == 2015) {
                return getObjYrJson('english', '2015');
            } else {
                return getObjYrJson('english', '1988');
            }
        };

        function getPhysicsSectionB(val) {
            console.log('Physics Year selected is: ' + val);

            if (val == 1988) {
                return getObjYrJson('physics', '1988');
            } else if (val == 1989) {
                return getObjYrJson('physics', '1989');
            } else if (val == 1990) {
                return getObjYrJson('physics', '1990');
            } else if (val == 1991) {
                return getObjYrJson('physics', '1991');
            } else if (val == 1992) {
                return getObjYrJson('physics', '1992');
            } else if (val == 1993) {
                return getObjYrJson('physics', '1993');
            } else if (val == 1994) {
                return getObjYrJson('physics', '1994');
            } else if (val == 1995) {
                return getObjYrJson('physics', '1995');
            } else if (val == 1996) {
                return getObjYrJson('physics', '1996');
            } else if (val == 1997) {
                return getObjYrJson('physics', '1997');
            } else if (val == 1998) {
                return getObjYrJson('physics', '1998');
            } else if (val == 1999) {
                return getObjYrJson('physics', '1999');
            } else if (val == 2000) {
                return getObjYrJson('physics', '2000');
            } else if (val == 2011) {
                return getObjYrJson('physics', '2011');
            } else if (val == 2012) {
                return getObjYrJson('physics', '2012');
            } else if (val == 2013) {
                return getObjYrJson('physics', '2013');
            } else if (val == 2014) {
                return getObjYrJson('physics', '2014');
            } else if (val == 2015) {
                return getObjYrJson('physics', '2015');
            } else {
                return getObjYrJson('physics', '1988');
            }
        };

        function getGovernmentSectionB(val) {
            console.log('Government Year selected is: ' + val);

            if (val == 1988) {
                return getObjYrJson('government', '1988');
            } else if (val == 1989) {
                return getObjYrJson('government', '1989');
            } else if (val == 1990) {
                return getObjYrJson('government', '1990');
            } else if (val == 2015) {
                return getObjYrJson('government', '2015');
            } else {
                return getObjYrJson('government', '1988');
            }
        };

        function getCommerceSectionB(val) {
            console.log('Commerce Year selected is: ' + val);

            if (val == 1988) {
                return getObjYrJson('commerce', '1988');
            } else if (val == 1989) {
                return getObjYrJson('commerce', '1989');
            } else if (val == 1990) {
                return getObjYrJson('commerce', '1990');
            } else if (val == 1991) {
                return getObjYrJson('commerce', '1991');
            } else if (val == 2015) {
                return getObjYrJson('commerce', '2015');
            } else {
                return getObjYrJson('commerce', '1989');
            }
        };

        function getBiologySectionB(val) {
            console.log('Biology Year selected is: ' + val);

            if (val == 1988) {
                return getObjYrJson('biology', '1988');
            } else if (val == 1989) {
                return getObjYrJson('biology', '1989');
            } else if (val == 1990) {
                return getObjYrJson('biology', '1990');
            } else if (val == 1991) {
                return getObjYrJson('biology', '1991');
            } else if (val == 1992) {
                return getObjYrJson('biology', '1992');
            } else if (val == 1993) {
                return getObjYrJson('biology', '1993');
            } else if (val == 1994) {
                return getObjYrJson('biology', '1994');
            } else if (val == 2011) {
                return getObjYrJson('biology', '2011');
            } else if (val == 2012) {
                return getObjYrJson('biology', '2012');
            } else if (val == 2013) {
                return getObjYrJson('biology', '2013');
            } else if (val == 2014) {
                return getObjYrJson('biology', '2014');
            } else if (val == 2015) {
                return getObjYrJson('biology', '2015');
            } else {
                return getObjYrJson('biology', '1988');
            }
        };

        function getLitInEngSectionB(val) {
            console.log('LitInEng Year selected is: ' + val);

            if (val == 1998) {
                return getObjYrJson('literature', '1998');
            } else if (val == 2015) {
                return getObjYrJson('literature', '2015');
            } else {
                return getObjYrJson('literature', '1998');
            }
        };

        function getChemistrySectionB(val) {
            console.log('Chemistry Year selected is: ' + val);

            if (val == 1988) {
                return getObjYrJson('chemistry', '1988');
            } else if (val == 1989) {
                return getObjYrJson('chemistry', '1989');
            } else if (val == 1990) {
                return getObjYrJson('chemistry', '1990');
            } else if (val == 1991) {
                return getObjYrJson('chemistry', '1991');
            } else if (val == 1992) {
                return getObjYrJson('chemistry', '1992');
            } else if (val == 1993) {
                return getObjYrJson('chemistry', '1993');
            } else if (val == 1994) {
                return getObjYrJson('chemistry', '1994');
            } else if (val == 1995) {
                return getObjYrJson('chemistry', '1995');
            } else if (val == 1996) {
                return getObjYrJson('chemistry', '1996');
            } else if (val == 1997) {
                return getObjYrJson('chemistry', '1997');
            } else if (val == 1998) {
                return getObjYrJson('chemistry', '1998');
            } else if (val == 1999) {
                return getObjYrJson('chemistry', '1999');
            } else if (val == 2000) {
                return getObjYrJson('chemistry', '2000');
            } else if (val == 2011) {
                return getObjYrJson('chemistry', '2011');
            } else if (val == 2012) {
                return getObjYrJson('chemistry', '2012');
            } else if (val == 2013) {
                return getObjYrJson('chemistry', '2013');
            } else if (val == 2014) {
                return getObjYrJson('chemistry', '2014');
            } else if (val == 2015) {
                return getObjYrJson('chemistry', '2015');
            } else {
                return getObjYrJson('chemistry', '1988');
            }
        };
    }
})();