import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { HttpModule } from '@angular/http';
import { APP_BASE_HREF } from '@angular/common';
import { BootstrapModalModule } from 'ng2-bootstrap-modal';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';

import { MainboardComponent } from './mainboard/mainboard.component';
import { NewComponent } from './new/new.component';
import { StaffComponent } from './staff/staff.component';
import { ClassComponent } from './class/class.component';
import { ActivityComponent } from './activity/activity.component';
import { SupportComponent } from './support/support.component';
import { LandingComponent } from './landing/landing.component';

import { AppRoutingModule }     from './app-routing.module';
import { StudentdetailComponent } from './studentdetail/studentdetail.component';
import { LoginComponent } from './login/login.component';
import { FooterComponent } from './footer/footer.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    MainboardComponent,
    NewComponent,
    StaffComponent,
    ClassComponent,
    ActivityComponent,
    SupportComponent,
    LandingComponent,
    StudentdetailComponent,
    LoginComponent,
    FooterComponent
  ],
  imports: [
    BrowserModule,
    BootstrapModalModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    AppRoutingModule
  ],
  entryComponents: [
    StudentdetailComponent
  ],
  providers: [{provide: APP_BASE_HREF, useValue : '/' }],
  bootstrap: [AppComponent]
})
export class AppModule { }
