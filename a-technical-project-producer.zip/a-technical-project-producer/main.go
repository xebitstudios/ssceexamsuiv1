package main

import (
	"encoding/csv"
	"encoding/json"
	"fmt"
	"io"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"strings"

	"github.com/confluentinc/confluent-kafka-go/kafka"
	"github.com/gorilla/mux"
)

// Csv location structure
type Csv struct {
	Location string `json:"location"`
}

func main() {
	// messages := make(chan string, 600)
	router := mux.NewRouter().StrictSlash(true)
	router.HandleFunc("/csv", csvPostHandler).Methods("POST")

	log.Fatal(http.ListenAndServe(":9090", router))
	// getCsvFile("data.csv")
}

func csvPostHandler(w http.ResponseWriter, r *http.Request) {

	//Retrieve body from http request
	b, err := ioutil.ReadAll(r.Body)
	defer r.Body.Close()
	if err != nil {
		panic(err)
	}

	//Save data into Csv struct
	var csvlocation Csv
	err = json.Unmarshal(b, &csvlocation)
	if err != nil {
		http.Error(w, err.Error(), 500)
		return
	}
	locationString := string(csvlocation.Location)
	fmt.Printf("locationString is: %s\n", locationString)

	go getCsvFile(locationString)

	//Convert csvlocation struct into json
	jsonString, err := json.Marshal(csvlocation)
	if err != nil {
		http.Error(w, err.Error(), 500)
		return
	}

	w.Header().Set("content-type", "application/json")
	w.Write(jsonString)

}

func getCsvFile(strval string) {
	messages := make(chan string, 600)
	csvFile, _ := os.Open(strval)
	reader := csv.NewReader(csvFile)
	var allLines []string
	for {
		line, error := reader.Read()
		if error == io.EOF {
			break
		} else if error != nil {
			log.Fatal(error)
		}
		newLine := strings.Join(line, ",")
		allLines = append(allLines, newLine)
		messages <- newLine
		sendLineToKafka(<-messages)
		// sendLineToKafka(newLine)
	}
	fmt.Printf("Total lines: %d", len(allLines))
}

func sendLineToKafka(line string) {
	fmt.Printf("sending line to kafka topic: %s\n", line)
	p, err := kafka.NewProducer(&kafka.ConfigMap{
		"bootstrap.servers": "localhost:9092",
	})
	if err != nil {
		panic(err)
	}

	// Produce messages to topic (asynchronously)
	topic := "testTopics"
	for _, word := range []string{string(line)} {
		p.Produce(&kafka.Message{
			TopicPartition: kafka.TopicPartition{Topic: &topic, Partition: kafka.PartitionAny},
			Value:          []byte(word),
		}, nil)
	}
	// defer p.Close()
	// p.Flush(10 * 1000)
}
