'use strict';

const uuid = require('uuid');
const AWS = require('aws-sdk');
const dynamoDb = new AWS.DynamoDB.DocumentClient({ apiVersion: '2012-08-10' });

module.exports.create = (event, context, callback) => {
    const timestamp = new Date().getTime();
    const data = JSON.parse(event.body);
    console.log('create nworkshop data', data);

    if (typeof data.name === '') {
        console.error('workshop name Validation Failed');
        callback(new Error('Couldn\'t create the nworkshop item.'));
        return;
    }

    const params = {
        TableName: 'the-workshop-app-staging',
        Item: {
            id: uuid.v1(),
            idx: data.idx,
            name: data.name,
            venue: data.venue,
            welcomemessage: data.welcomemessage,
            description: data.description,
            startdate: data.startdate,
            enddate: data.enddate,
            dresscode: data.dresscode,
            workshopimage: data.workshopimage,
            workshoptype: data.workshoptype,
            createdAt: timestamp,
            updatedAt: timestamp
        }
    }

    dynamoDb.put(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t create the nworkshop item.'));
            return;
        }

        console.log('new nworkshop detail is: ', result);

        const response = {
            statusCode: 200,
            body: JSON.stringify(result.Item)
        }
        callback(null, response);
    })
}

module.exports.update = (event, context, callback) => {
    const timestamp = new Date().getTime();
    const data = JSON.parse(event.body);
    console.log('updated nworkshop data', data);

    if (typeof data.name === '') {
        console.error('name Validation Failed');
        callback(new Error('Couldn\'t update the nworkshop item.'));
        return;
    }

    const params = {
        TableName: 'the-workshop-app-staging',
        Item: {
            id: event.pathParameters.id,
            idx: data.idx,
            name: data.name,
            venue: data.venue,
            welcomemessage: data.welcomemessage,
            description: data.description,
            startdate: data.startdate,
            enddate: data.enddate,
            dresscode: data.dresscode,
            workshopimage: data.workshopimage,
            workshoptype: data.workshoptype,
            updatedAt: timestamp
        }
    }

    dynamoDb.put(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t update the nworkshop item.'));
            return;
        }

        console.log('updated nworkshop detail is now: ', result);

        const response = {
            statusCode: 200,
            body: JSON.stringify(result.Item)
        }
        callback(null, response);
    })
}

module.exports.list = (event, context, callback) => {
    const params = {
        TableName: 'the-workshop-app-staging'
    }

    dynamoDb.scan(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t fetch the nworkshops.'));
            return;
        }

        console.log('nworkshop list is: ', result);

        const response = {
            statusCode: 200,
            body: JSON.stringify(result.Items.filter(e => {
                if (e.idx === "none") return e;
            }))
        }
        callback(null, response);
    })
}

module.exports.get = (event, context, callback) => {
    const params = {
        TableName: 'the-workshop-app-staging',
        Key: {
            id: event.pathParameters.id
        }
    }

    dynamoDb.get(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t fetch the specific nworkshop.'));
            return;
        }

        console.log('nworkshop detail is: ', result);

        const response = {
            statusCode: 200,
            body: JSON.stringify(result.Item)
        }
        callback(null, response);
    })
}

module.exports.delete = (event, context, callback) => {
    const params = {
        TableName: 'the-workshop-app-staging',
        Key: {
            id: event.pathParameters.id
        }
    }

    dynamoDb.delete(params, (error) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t delete the specific nworkshop.'));
            return;
        }

        console.log('nworkshop detail deleted successfully');

        const response = {
            statusCode: 200,
            body: JSON.stringify({})
        }
        callback(null, response);
    })
}

module.exports.createpoll = (event, context, callback) => {
    const timestamp = new Date().getTime();
    console.log('event is: ', event.body);
    const data = JSON.parse(event.body);
    console.log('create nworkshop data', data);

    const params = {
        TableName: 'the-workshop-app-staging',
        Item: {
            id: uuid.v1(),
            idx: 'polls-' + data.idx,
            qst: data.qst,
            qstanswer: data.qstanswer,
            summary: data.summary,
            answerees: data.answerees,
            instructions: data.instructions,
            type: data.type,
            eventid: data.eventid,
            status: data.status,
            stoptime: data.stoptime,
            createdAt: timestamp,
            updatedAt: timestamp
        }
    }

    dynamoDb.put(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t create the nworkshop polls item.'));
            return;
        }

        console.log('new nworkshop polls detail is: ', result);

        const response = {
            statusCode: 200,
            body: JSON.stringify(result.Item)
        }
        callback(null, response);
    })
}

module.exports.getpoll = (event, context, callback) => {
    const params = {
        TableName: 'the-workshop-app-staging'
    }

    dynamoDb.scan(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t fetch the nworkshops.'));
            return;
        }

        console.log('nworkshop list is: ', result);

        const response = {
            statusCode: 200,
            body: JSON.stringify(result.Items.filter(e => {
                if (e.idx === event.pathParameters.idx) return e;
            }))
        }
        callback(null, response);
    })
}

module.exports.updatepoll = (event, context, callback) => {
    const timestamp = new Date().getTime();
    const data = JSON.parse(event.body);
    console.log('updated poll nworkshop data', data);

    if (typeof data.name === '') {
        console.error('poll name Validation Failed');
        callback(new Error('Couldn\'t update the nworkshop item.'));
        return;
    }

    const params = {
        TableName: 'the-workshop-app-staging',
        ExpressionAttributeValues: {
            ":idx": event.pathParameters.idx,
        },
        ConditionExpression: "idx = :idx",
        Item: {
            id: event.pathParameters.id,
            idx: event.pathParameters.idx,
            instructions: data.instructions,
            eventid: data.eventid,
            summary: data.summary,
            createdAt: data.createdAt,
            qstanswer: data.qstanswer,
            answerees: data.answerees,
            qst: data.qst,
            stoptime: data.stoptime,
            type: data.type,
            updatedAt: timestamp
        }
    }

    dynamoDb.put(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t update the nworkshop item.'));
            return;
        }

        console.log('updated nworkshop detail is now: ', result);

        const response = {
            statusCode: 200,
            body: JSON.stringify(result.Item)
        }
        callback(null, response);
    })
}

module.exports.createquestion = (event, context, callback) => {
    const timestamp = new Date().getTime();
    console.log('event is: ', event.body);
    const data = JSON.parse(event.body);
    console.log('create nworkshop question data', data);

    const params = {
        TableName: 'the-workshop-app-staging',
        Item: {
            id: uuid.v1(),
            idx: 'question-' + data.idx,
            question: data.question,
            type: data.type,
            eventid: data.eventid,
            attendeeid: data.attendeeid,
            public: data.public,
            isanswered: data.isanswered,
            lock: data.lock,
            answers: data.answers,
            votes: data.votes,
            createdAt: timestamp,
            updatedAt: timestamp
        }
    }

    dynamoDb.put(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t create the nworkshop question item.'));
            return;
        }

        console.log('new nworkshop question detail is: ', result);

        const response = {
            statusCode: 200,
            body: JSON.stringify(result.Item)
        }
        callback(null, response);
    })
}

module.exports.getquestion = (event, context, callback) => {
    const params = {
        TableName: 'the-workshop-app-staging'
    }

    dynamoDb.scan(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t fetch the nworkshops.'));
            return;
        }

        console.log('nworkshop list is: ', result);

        const response = {
            statusCode: 200,
            body: JSON.stringify(result.Items.filter(e => {
                if (e.idx === event.pathParameters.idx) return e;
            }))
        }
        callback(null, response);
    })
}

module.exports.updatequestion = (event, context, callback) => {
    const timestamp = new Date().getTime();
    const data = JSON.parse(event.body);
    console.log('updated question nworkshop data', data);

    if (typeof data.question === '') {
        console.error('question Validation Failed');
        callback(new Error('Couldn\'t update the nworkshop question item.'));
        return;
    }

    const params = {
        TableName: 'the-workshop-app-staging',
        ExpressionAttributeValues: {
            ":id": event.pathParameters.id,
        },
        ConditionExpression: "id = :id",
        Item: {
            id: event.pathParameters.id,
            idx: event.pathParameters.idx,
            question: data.question,
            type: data.type,
            eventid: data.eventid,
            attendeeid: data.attendeeid,
            public: data.public,
            isanswered: data.isanswered,
            lock: data.lock,
            answers: data.answers,
            votes: data.votes,
            updatedAt: timestamp
        }
    }

    dynamoDb.put(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t update the nworkshop question item.'));
            return;
        }

        console.log('updated nworkshop question detail is now: ', result);

        const response = {
            statusCode: 200,
            body: JSON.stringify(result.Item)
        }
        callback(null, response);
    })
}

module.exports.createevent = (event, context, callback) => {
    const timestamp = new Date().getTime();
    console.log('event is: ', event.body);
    const data = JSON.parse(event.body);
    console.log('create nworkshop event data', data);

    const params = {
        TableName: 'the-workshop-app-staging',
        Item: {
            id: uuid.v1(),
            idx: 'event-' + data.idx,
            eventid: data.eventid,
            title: data.title,
            description: data.description,
            location: data.location,
            starttimedate: data.starttimedate,
            endtimedate: data.endtimedate,
            rating: data.rating,
            presenters: data.presenters,
            attendees: data.attendees,
            feedbacks: data.feedbacks,
            createdAt: timestamp,
            updatedAt: timestamp
        }
    }

    dynamoDb.put(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t create the nworkshop event item.'));
            return;
        }

        console.log('new nworkshop event detail is: ', result);

        const response = {
            statusCode: 200,
            body: JSON.stringify(result.Item)
        }
        callback(null, response);
    })
}

module.exports.getevent = (event, context, callback) => {
    const params = {
        TableName: 'the-workshop-app-staging'
    }

    dynamoDb.scan(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t fetch the nworkshops events.'));
            return;
        }

        console.log('nworkshop list is: ', result);

        const response = {
            statusCode: 200,
            body: JSON.stringify(result.Items.filter(e => {
                if (e.idx === event.pathParameters.idx) return e;
            }))
        }
        callback(null, response);
    })
}

module.exports.updateevent = (event, context, callback) => {
    const timestamp = new Date().getTime();
    const data = JSON.parse(event.body);
    console.log('updated event nworkshop data', data);

    if (typeof data.question === '') {
        console.error('event Validation Failed');
        callback(new Error('Couldn\'t update the nworkshop event item.'));
        return;
    }

    const params = {
        TableName: 'the-workshop-app-staging',
        ExpressionAttributeValues: {
            ":id": event.pathParameters.id,
        },
        ConditionExpression: "id = :id",
        Item: {
            id: event.pathParameters.id,
            idx: event.pathParameters.idx,
            eventid: data.eventid,
            title: data.title,
            description: data.description,
            location: data.location,
            starttimedate: data.starttimedate,
            endtimedate: data.endtimedate,
            rating: data.rating,
            presenters: data.presenters,
            attendees: data.attendees,
            feedbacks: data.feedbacks,
            updatedAt: timestamp
        }
    }

    dynamoDb.put(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t update the nworkshop event item.'));
            return;
        }

        console.log('updated nworkshop event detail is now: ', result);

        const response = {
            statusCode: 200,
            body: JSON.stringify(result.Item)
        }
        callback(null, response);
    })
}

module.exports.createenrolee = (event, context, callback) => {
    const timestamp = new Date().getTime();
    console.log('event is: ', event.body);
    const data = JSON.parse(event.body);
    console.log('create nworkshop enrolee data', data);

    const params = {
        TableName: 'the-workshop-app-staging',
        Item: {
            id: uuid.v1(),
            idx: 'enrolee-' + data.idx,
            enrolees: data.enrolees,
            createdAt: timestamp,
            updatedAt: timestamp
        }
    }

    dynamoDb.put(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t create the nworkshop enrolee item.'));
            return;
        }

        console.log('new nworkshop enrolee detail is: ', result);

        const response = {
            statusCode: 200,
            body: JSON.stringify(result.Item)
        }
        callback(null, response);
    })
}

module.exports.getenrolee = (event, context, callback) => {
    const params = {
        TableName: 'the-workshop-app-staging'
    }

    dynamoDb.scan(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t fetch the nworkshops enrolees.'));
            return;
        }

        console.log('nworkshop enrolees list is: ', result);

        const response = {
            statusCode: 200,
            body: JSON.stringify(result.Items.filter(e => {
                if (e.idx === event.pathParameters.idx) return e;
            }))
        }
        callback(null, response);
    })
}

module.exports.updateenrolee = (event, context, callback) => {
    const timestamp = new Date().getTime();
    const data = JSON.parse(event.body);
    console.log('updated enrolee nworkshop data', data);

    const params = {
        TableName: 'the-workshop-app-staging',
        ExpressionAttributeValues: {
            ":id": event.pathParameters.id,
        },
        ConditionExpression: "id = :id",
        Item: {
            id: event.pathParameters.id,
            idx: event.pathParameters.idx,
            enrolees: data.enrolees,
            updatedAt: timestamp
        }
    }

    dynamoDb.put(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t update the nworkshop enrolee item.'));
            return;
        }

        console.log('updated nworkshop enrolee detail is now: ', result);

        const response = {
            statusCode: 200,
            body: JSON.stringify(result.Item)
        }
        callback(null, response);
    })
}

module.exports.createalert = (event, context, callback) => {
    const timestamp = new Date().getTime();
    console.log('event is: ', event.body);
    const data = JSON.parse(event.body);
    console.log('create nworkshop alert data', data);

    const params = {
        TableName: 'the-workshop-app-staging',
        Item: {
            id: uuid.v1(),
            idx: 'alert-' + data.idx,
            name: data.name,
            message: data.message,
            type: data.type,
            eventid: data.eventid,
            sendtime: data.sendtime,
            status: data.status,
            alerttype: data.alerttype,
            createdAt: timestamp,
            updatedAt: timestamp
        }
    }

    dynamoDb.put(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t create the nworkshop alert item.'));
            return;
        }

        console.log('new nworkshop alert detail is: ', result);

        const response = {
            statusCode: 200,
            body: JSON.stringify(result.Item)
        }
        callback(null, response);
    })
}

module.exports.getalert = (event, context, callback) => {
    const params = {
        TableName: 'the-workshop-app-staging'
    }

    dynamoDb.scan(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t fetch the nworkshops alerts.'));
            return;
        }

        console.log('nworkshop alerts list is: ', result);

        const response = {
            statusCode: 200,
            body: JSON.stringify(result.Items.filter(e => {
                if (e.idx === event.pathParameters.idx) return e;
            }))
        }
        callback(null, response);
    })
}

module.exports.updatealert = (event, context, callback) => {
    const timestamp = new Date().getTime();
    const data = JSON.parse(event.body);
    console.log('updated alert nworkshop data', data);

    const params = {
        TableName: 'the-workshop-app-staging',
        ExpressionAttributeValues: {
            ":id": event.pathParameters.id,
        },
        ConditionExpression: "id = :id",
        Item: {
            id: event.pathParameters.id,
            idx: event.pathParameters.idx,
            name: data.name,
            message: data.message,
            type: data.type,
            eventid: data.eventid,
            sendtime: data.sendtime,
            status: data.status,
            alerttype: data.alerttype,
            updatedAt: timestamp
        }
    }

    dynamoDb.put(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t update the nworkshop alert item.'));
            return;
        }

        console.log('updated nworkshop alert detail is now: ', result);

        const response = {
            statusCode: 200,
            body: JSON.stringify(result.Item)
        }
        callback(null, response);
    })
}

module.exports.createfeedback = (event, context, callback) => {
    const timestamp = new Date().getTime();
    console.log('event is: ', event.body);
    const data = JSON.parse(event.body);
    console.log('create nworkshop feedback data', data);

    const params = {
        TableName: 'the-workshop-app-staging',
        Item: {
            id: uuid.v1(),
            idx: 'feedback-' + data.idx,
            name: data.name,
            message: data.message,
            postdate: data.postdate,
            public: data.public,
            createdAt: timestamp,
            updatedAt: timestamp
        }
    }

    dynamoDb.put(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t create the nworkshop feedback item.'));
            return;
        }

        console.log('new nworkshop feedback detail is: ', result);

        const response = {
            statusCode: 200,
            body: JSON.stringify(result.Item)
        }
        callback(null, response);
    })
}

module.exports.getfeedback = (event, context, callback) => {
    const params = {
        TableName: 'the-workshop-app-staging'
    }

    dynamoDb.scan(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t fetch the nworkshops feedbacks.'));
            return;
        }

        console.log('nworkshop feedbacks list is: ', result);

        const response = {
            statusCode: 200,
            body: JSON.stringify(result.Items.filter(e => {
                if (e.idx === event.pathParameters.idx) return e;
            }))
        }
        callback(null, response);
    })
}

module.exports.updatefeedback = (event, context, callback) => {
    const timestamp = new Date().getTime();
    const data = JSON.parse(event.body);
    console.log('updated feedback nworkshop data', data);

    const params = {
        TableName: 'the-workshop-app-staging',
        ExpressionAttributeValues: {
            ":id": event.pathParameters.id,
        },
        ConditionExpression: "id = :id",
        Item: {
            id: event.pathParameters.id,
            idx: event.pathParameters.idx,
            name: data.name,
            message: data.message,
            postdate: data.postdate,
            public: data.public,
            updatedAt: timestamp
        }
    }

    dynamoDb.put(params, (error, result) => {
        if (error) {
            console.error(error);
            callback(new Error('Couldn\'t update the nworkshop feedback item.'));
            return;
        }

        console.log('updated nworkshop feedback detail is now: ', result);

        const response = {
            statusCode: 200,
            body: JSON.stringify(result.Item)
        }
        callback(null, response);
    })
}