'use strict';

const uuid = require('uuid');
const AWS = require('aws-sdk');
const dynamoDb = new AWS.DynamoDB.DocumentClient({ apiVersion: '2012-08-10' });

module.exports.create = (event, context, callback) => {
    const timestamp = new Date().getTime();
    const data = JSON.parse(event.body);
    console.log('create user data', data);

    if (data.name === '') {
        console.log('user 1 name Validation Failed');
        callback(new Error('Couldn\'t create the user item.'));
        return;
    }

    const params = {
        TableName: 'the-user-app-staging',
        Item: {
            id: uuid.v1(),
            name: data.name,
            image: data.image,
            location: data.location,
            jobTitle: data.jobTitle,
            organization: data.organization,
            email: data.email,
            settings: data.settings,
            workshops: data.workshops,
            createdAt: timestamp,
            updatedAt: timestamp
        }
    }

    dynamoDb.put(params, (error, result) => {
        console.log('params...', params);
        if (error) {
            // console.error(error);
            callback(new Error('Couldn\'t create the user item.'));
            return;
        }

        // console.log('new user detail is: ', result);

        const response = {
            statusCode: 200,
            body: JSON.stringify(result.Item)
        }
        callback(null, response);
    })
}

module.exports.update = (event, context, callback) => {
    const timestamp = new Date().getTime();
    const data = JSON.parse(event.body);
    // console.log('updated user data', data);

    if (data.name === '') {
        console.error('name Validation Failed');
        callback(new Error('Couldn\'t update the user item.'));
        return;
    }

    const params = {
        TableName: 'the-user-app-staging',
        Item: {
            id: event.pathParameters.id,
            name: data.name,
            image: data.image,
            location: data.location,
            jobTitle: data.jobTitle,
            organization: data.organization,
            email: data.email,
            settings: data.settings,
            workshops: data.workshops,
            updatedAt: timestamp
        }
    }

    dynamoDb.put(params, (error, result) => {
        if (error) {
            // console.error(error);
            callback(new Error('Couldn\'t update the user item.'));
            return;
        }

        // console.log('updated user detail is now: ', result);

        const response = {
            statusCode: 200,
            body: JSON.stringify(result.Item)
        }
        callback(null, response);
    })
}

module.exports.list = (event, context, callback) => {
    const params = {
        TableName: 'the-user-app-staging'
    }

    dynamoDb.scan(params, (error, result) => {
        if (error) {
            // console.error(error);
            callback(new Error('Couldn\'t fetch the users.'));
            return;
        }

        // console.log('user list is: ', result);

        const response = {
            statusCode: 200,
            body: JSON.stringify(result.Items)
        }
        callback(null, response);
    })
}

module.exports.get = (event, context, callback) => {
    const params = {
        TableName: 'the-user-app-staging',
        Key: {
            id: event.pathParameters.id
        }
    }

    dynamoDb.get(params, (error, result) => {
        if (error) {
            // console.error(error);
            callback(new Error('Couldn\'t fetch the specific user.'));
            return;
        }

        // console.log('user detail is: ', result);

        const response = {
            statusCode: 200,
            body: JSON.stringify(result.Item)
        }
        callback(null, response);
    })
}