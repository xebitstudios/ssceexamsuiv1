module.exports = {
    host: 'https://023v419iwh.execute-api.us-west-2.amazonaws.com/dev',
    token: 'token eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpYXQiOjE0OTY5MDI5OTg3NjcsImlkIjoiWGFBMkdNWFVSZ1dRSHhyUlc5TmVoWVJsY3JINkYwVWRwTVdPQk9XaiF4ayIsIm8iOnsiZW50ZXJwcmlzZUlkIjoiZmlyc3RuYW1lLmxhc3RuYW1lIn19.fWbr6VJSyJt40EPWf6EiI1L69atTmgI80C3hbBBerio'
};