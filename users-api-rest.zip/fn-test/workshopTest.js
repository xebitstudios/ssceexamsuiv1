const request = require('supertest');
const common = require('./common.js');
const assert = require('assert');

const service = request(common.host);

describe('WORKSHOP APIs',function(){
    this.timeout(5000);
    let workshopId = '';
    describe('workshop API', function() {   
        this.timeout(5000); 
        describe('PUT /workshop', ()=>{        
            it('should create a workshop', ()=>{
                return service.put('/workshops')
                .send({
                    "description" : "workshop 1 -test",
                    "start" : 1000,
                    "end" : 10000,
                    "location" : "foo location"
                    })
                .set('Authorization', common.token)
                .expect(200)
                .then(response=>{
                    console.log(response.body);
                });
            });        
        });
        describe('GET /workshops', ()=>{
            it('should return workshops', ()=>{
                return service.get('/workshops')
                .set('Authorization', common.token)
                .expect(200)
                .then(response=>{
                    assert.ok(Array.isArray(response.body));
                    const item = response.body[0];
                    assert.ok(typeof item.id !== 'undefined');
                    workshopId = item.id;
                });
            });
        });
    });

    describe('event API', function() {            
        describe('PUT /workshop/{workshopId}/events', ()=>{        
            it('should create a workshop', ()=>{
                return service.put(`/workshops/${workshopId}/events`)
                .send({
                    "subject" : "Event Subject test",
                    "workshopId" : workshopId,
                    "start" : 1000,
                    "end" : 2000,
                    "description" : "Description foo",
                    "location" : "location",
                    "allDay" : false, 
                    "category" : "planetary",
                    "presenters" : [
                        {
                            "name" : "Presenter33 name",
                            "eid" : "firstname3.lastname3",
                            "bio" : "Presenter bio",
                            "link" : "https://example.com"
                        },
                        {
                            "name" : "Presenter2",
                            "eid" : "firstname2.lastname2",
                            "bio" : "Presenter bio22",
                            "link" : "https://example22.com"
                        }
                    ]    
                })
                .set('Authorization', common.token)
                .expect(200)
                .then(response=>{
                    console.log(response.body);
                });
            });        
        });
    }); // describe('event API', function() {   
});
