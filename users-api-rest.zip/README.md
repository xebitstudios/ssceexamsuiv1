# Overview
This repository contains the reference microservices API based on Serverless framework (using AWS).

# Run this application locally

### Pre-requisite
The tools have been tested with Node 6.8.0 (and 7.7), and NPM version 3.10.8.
 
### Run locally
```
npm install
npm run start
```

### Deploy to AWS
```
npm run deploy-sandbox
```
Or `deploy-dev`. See `package.json` for details

### Unit tests
```
npm test
```

### Functional Test
Note: this is to be converted into Typescript
```
mocha fn-test/<file>.js
```


## Directory structure
* `app` - Application code: handler.ts (entry point for Lambda functions), controllers, DAOs, and models
* `fn-test` - functional test suites based on Supertest
* `serverless` - YAML configuration file for Serverless framework
* `tests` - unit test suites
* `Jenkinsfile` - CI pipeline as code, to be consumed by Jenkins

