import { AnswerModel } from "./AnswerModel";

export class QuestionModel {
    public id: string;
    public userName: string;
    public userId: string;
    public questionTitle: string;
    public topicTitle: string;
    public topicId: string;
    public answers: AnswerModel[];
}
