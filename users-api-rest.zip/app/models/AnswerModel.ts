export class AnswerModel {
    public id: string;
    public userName: string;
    public title: string;
    public content: string;
    public userId: string;
}
