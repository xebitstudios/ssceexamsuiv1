export class SettingsModel {
  public remindersOn: boolean;
  public remindersTime: number;
  public showContactInfo: boolean;
  public allowAttendeeAnswers: boolean;
  public emailNotification: boolean;
  public roles: string[];
}
