export class AttendeeModel {
    public id: string;
    public userName: string;
    public userImage?: string;
    public userTitle: string;
}
