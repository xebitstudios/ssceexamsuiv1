export class SessionModel {
    public id: string;
    public title: string;
    public date: Date;
    public saved: boolean;
    public rooms: any[];
}
