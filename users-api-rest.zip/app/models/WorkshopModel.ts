import { AttendeeModel } from "./AttendeeModel";
import { PollsDetailsModel } from "./PollsDetailsModel";
import { QuestionModel } from "./QuestionModel";
import { TopicModel } from "./TopicModel";

export class WorkshopModel {
    public id: string;
    public idx: string;
    public featuredImage: string;
    public title: string;
    public body: string;
    public saved: boolean;
    public streamUrl: string;
    public details: {
      eventDates: Date[],
      location: string,
      hours: string,
      place: string,
      contact: string,
    };
    public topics: TopicModel[];
    public questions: QuestionModel[];
    public attendees: AttendeeModel[];
    public polls: PollsDetailsModel[];
}
