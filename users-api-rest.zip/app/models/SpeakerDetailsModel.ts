export class SpeakerDetailsModel {
    public speakerName: string;
    public speakerBio: string;
    public speakerTitle: string;
    public speakerImage: string;
    public sessions?: number;
}
