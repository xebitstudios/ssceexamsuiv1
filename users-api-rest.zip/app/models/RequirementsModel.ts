export class RequirementsModel {
    public id: string;
}
