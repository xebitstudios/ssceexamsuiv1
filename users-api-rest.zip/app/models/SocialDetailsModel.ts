export class SocialDetailsModel {
    public favoritesEndpoint?: string;
    public shareEndpoint: string;
}
