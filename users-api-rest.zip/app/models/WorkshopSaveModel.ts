export class WorkshopSaveModel {
  public id: string;
  public events: any[];
  public polls: string[];
}
