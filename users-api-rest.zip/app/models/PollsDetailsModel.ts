export class PollsDetailsModel {
    public id: string;
    public title: string;
    public instructions: string;
    public eventid: string;
    public selections: any[];
    public updatedAt: Date;
    public stoptime: Date;
    public createdAt: Date;
    public answer: string;
    public idx: string;
    public answerees: string[];
    public type: string;
}
