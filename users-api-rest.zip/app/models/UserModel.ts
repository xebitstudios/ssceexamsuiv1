import { SettingsModel } from "./SettingsModel";
import { WorkshopSaveModel } from "./WorkshopSaveModel";

export class UserModel {
  public id: string;
  public image: string;
  public name: string;
  public jobTitle: string;
  public location: string;
  public organization: string;
  public email: string;
  public settings: SettingsModel;
  public workshops: WorkshopSaveModel[];
}
