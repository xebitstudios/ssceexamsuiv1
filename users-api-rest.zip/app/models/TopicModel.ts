import { RequirementsModel } from "./RequirementsModel";
import { SessionModel } from "./SessionModel";
import { SocialDetailsModel } from "./SocialDetailsModel";
import { SpeakerDetailsModel } from "./SpeakerDetailsModel";

export class TopicModel {
    public id: string;
    public title: string;
    public speakerName: string;
    public class: string; // color assignment?
    public description: string;
    public saved: boolean;
    public socialDetails: SocialDetailsModel;
    public speakerDetails: SpeakerDetailsModel;
    public sessions: SessionModel[];
    public requirements: RequirementsModel[];
}
