import { AuthorizerMethod, Config, Logger, Response, Utility } from "@aowt/aowt-serverless-common";
import { DynamoDB } from "aws-sdk";
import { User } from "./User";

export class UserDao {
  private tableName = null;

  constructor(private stage: string, private documentClient: DynamoDB.DocumentClient
    ,         private config: Config, private logger: Logger) {
    this.tableName = `the-user-app-${this.stage}`;
  }

  public createUpdate(user: User): Promise<User> {
    // verify if User has an id
    if (user.user.id === null || user.user.id === undefined) {
      // Generate a new ID
      user.user.id = Utility.getUuid();
    }

    const params = {
      // Item: user.withIndex(),
      Item: {
        id: user.user.id,
        image: user.user.image,
        name: user.user.name,
        // tslint:disable-next-line:object-literal-sort-keys
        jobTitle: user.user.jobTitle,
        organization: user.user.organization,
        location: user.user.location,
        email: user.user.email,
        settings: user.user.settings,
        workshops: user.user.workshops,
      },
      TableName: this.tableName,
    };

    // tslint:disable-next-line:no-console
    console.log("user params is...", params);

    return this.documentClient.put(params).promise()
      .then(() => {
        return user;
      });
  }

  public getAllUsers(): Promise<User[]> {
    const params = {
      // ExpressionAttributeValues: {
      //   ":idx": "workshop",
      // },
      // IndexName: "id",
      // KeyConditionExpression: "idx = :idx",
      // Select: "ALL_ATTRIBUTES",
      TableName: this.tableName,
    };

    this.logger.log("debug", JSON.stringify(params));

    return this.documentClient.query(params).promise()
      .then((results) => {
        // Utility.log('debug', results);
        const users = new Array<User>();
        const items: any[] = results.Items;
        items.forEach((item) => {
          users.push(new User(item));
        });
        return users;
      });
  }

  public getUser(email: string): Promise<User> {

    const params = {
      Key: {
        email: email + "@accenture.com",
      },
      TableName: this.tableName,
    };

    return this.documentClient.get(params).promise()
      .then((results) => {
        if (typeof results.Item === "undefined") {
          return null;
        } else {
          return new User(results.Item);
        }
      });
  }
}
