import {AuthorizerMethod, Config, Logger, Response, Utility} from "@aowt/aowt-serverless-common";
import {Wove} from "aspect.js";
import {UserAdminAuthorizer} from "../Common/UserAdminAuthorizer";
import {User} from "./User";
import {UserDao} from "./UserDao";

@Wove({
    authorizers: [AuthorizerMethod.Custom],
    customAuthorizerType: UserAdminAuthorizer,
})
export class UserController {
    constructor(private stage: string, private userDao: UserDao
        ,       private config: Config, private logger: Logger) {

    }
    public putUser(event: any): Promise<any> {
        return Promise.resolve(true)
        .then(() => {
            const eventBody = JSON.parse(event.body);
            const user = new User(eventBody);
            // Utility.log('debug', user);
            return this.userDao.createUpdate(user);
        })
        .then((results) => {
            return new Response(200, {
                Location: `/user/${results.user.email}`,
            }, "Created");
        });
    }
    public getAllUsers(event: any): Promise<any> {
        // Utility.log('debug', event);
        // return Promise.resolve(new Response(200, null, 'Created'));
        return Promise.resolve(true)
        .then(() => {
            return this.userDao.getAllUsers();
        })
        .then((results) => {
            // Utility.log('debug', results);
            return new Response(200, {}, results);
        });
    }
    public getUser(event: any): Promise<any> {
        return Promise.resolve(true)
        .then(() => {
            const email = event.pathParameters.email;
            return this.userDao.getUser(email);
        })
        .then((results) => {
            // Utility.log('debug', results);
            return new Response(200, {}, results);
        });
    }
}
