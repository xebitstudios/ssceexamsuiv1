import { UserModel } from "models/UserModel";
import _ = require("underscore");

export class User {
  public user: UserModel;

  constructor(obj?: any) {
    if (obj) {
      // safe assign, only allowed properties only
      Object.assign(this, _.pick(obj, ["id", "image", "name", "jobTitle", "location"
      , "organization", "email", "settings", "workshops"]));
    }
  }

  public withIndex(): any {
     return Object.assign({}, this);
  }
}
