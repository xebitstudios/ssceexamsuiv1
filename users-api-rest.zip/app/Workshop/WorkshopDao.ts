import { AuthorizerMethod, Config, Logger, Response, Utility } from "@aowt/aowt-serverless-common";
import { DynamoDB } from "aws-sdk";
import { Workshop } from "./Workshop";

export class WorkshopDao {
  private tableName = null;

  constructor(private stage: string, private documentClient: DynamoDB.DocumentClient
    ,         private config: Config, private logger: Logger) {
    this.tableName = `the-workshop-app-${this.stage}`;
  }

  public createUpdate(workshop: Workshop): Promise<Workshop> {
    // verify if Workshop has an id
    if (workshop.workshop.id === null || workshop.workshop.id === undefined) {
      // Generate a new ID
      workshop.workshop.id = Utility.getUuid();
    }

    const params = {
      Item: workshop.withIndex(),
      TableName: this.tableName,
    };

    return this.documentClient.put(params).promise()
      .then(() => {
        return workshop;
      });
  }

  public getAllWorkshops(): Promise<Workshop[]> {
    const params = {
      ExpressionAttributeValues: {
        ":idx": "workshop",
      },
      IndexName: "id",
      KeyConditionExpression: "idx = :idx",
      Select: "ALL_ATTRIBUTES",
      TableName: this.tableName,
    };

    this.logger.log("debug", JSON.stringify(params));

    return this.documentClient.query(params).promise()
      .then((results) => {
        // Utility.log('debug', results);
        const workshops = new Array<Workshop>();
        const items: any[] = results.Items;
        items.forEach((item) => {
          workshops.push(new Workshop(item));
        });
        return workshops;
      });
  }

  public getWorkshop(id: string): Promise<Workshop> {

    const params = {
      Key: {
        id,
      },
      TableName: this.tableName,
    };

    return this.documentClient.get(params).promise()
      .then((results) => {
        if (typeof results.Item === "undefined") {
          return null;
        } else {
          return new Workshop(results.Item);
        }
      });
  }
}
