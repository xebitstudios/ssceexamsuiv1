import {AuthorizerMethod, Config, Logger, Response, Utility} from "@aowt/aowt-serverless-common";
import {Wove} from "aspect.js";
import {UserAdminAuthorizer} from "../Common/UserAdminAuthorizer";
import {Workshop} from "./Workshop";
import {WorkshopDao} from "./WorkshopDao";

@Wove({
    authorizers: [AuthorizerMethod.Custom],
    customAuthorizerType: UserAdminAuthorizer,
})
export class WorkshopController {
    constructor(private stage: string, private workshopDao: WorkshopDao
        ,       private config: Config, private logger: Logger) {

    }
    public putWorkshop(event: any): Promise<any> {
        return Promise.resolve(true)
        .then(() => {
            const eventBody = JSON.parse(event.body);
            const workshop = new Workshop(eventBody);
            // Utility.log('debug', workshop);
            return this.workshopDao.createUpdate(workshop);
        })
        .then((results) => {
            return new Response(200, {
                Location: `/workshop/${results.workshop.id}`,
            }, "Created");
        });
    }
    public getAllWorkshops(event: any): Promise<any> {
        // Utility.log('debug', event);
        // return Promise.resolve(new Response(200, null, 'Created'));
        return Promise.resolve(true)
        .then(() => {
            return this.workshopDao.getAllWorkshops();
        })
        .then((results) => {
            // Utility.log('debug', results);
            return new Response(200, {}, results);
        });
    }
    public getWorkshop(event: any): Promise<any> {
        return Promise.resolve(true)
        .then(() => {
            const id = event.pathParameters.id;
            return this.workshopDao.getWorkshop(id);
        })
        .then((results) => {
            // Utility.log('debug', results);
            return new Response(200, {}, results);
        });
    }
}
