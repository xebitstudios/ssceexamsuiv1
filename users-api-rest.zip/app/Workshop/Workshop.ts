import _ = require("underscore");
import { WorkshopModel } from "../models/WorkshopModel";

export class Workshop {
  public workshop: WorkshopModel;

  constructor(obj?: any) {
    if (obj) {
      // safe assign, only allowed properties only
      Object.assign(this, _.pick(obj, ["idx", "featuredImage", "title", "body", "saved"
      , "streamUrl", "details", "topics", "questions", "attendees", "polls"]));
    }
  }

  public withIndex(): any {
     return Object.assign({idx: "workshop"}, this);
  }
}
