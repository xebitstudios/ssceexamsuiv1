/**
 * This script initialize instances of classes with dependency injection.
 */

import {Config, Logger, LoggerFilter} from "@aowt/aowt-serverless-common";
import {config as AWSConfig, DynamoDB} from "aws-sdk";
import process = require("process");

// import workshop controller and dao classes
import {WorkshopController, WorkshopDao} from "./Workshop";

// import questions controller and dao clasess
import {UserController, UserDao} from "./User";

/*************
 * Stage
 *************/
export const stage = process.env.function_stage;
if (!stage) {
  throw new Error("function_stage is not defined in environment variable");
}

/*************
 * config
 *************/
import configObj = require("./config.json");
export const config: Config = new Config(stage, configObj);

/*************
 * AWS clients
 * documentClient
 *************/
if (!config || !config.get("aws")) {
  throw new Error("AWS not defined in config file");
}
const awsConfig = config.get("aws");
if (!awsConfig.region) {
  throw new Error("AWS region not defined in config file");
}
// export const awsAsync:AwsAsync = new AwsAsync(config.get('aws').region);
AWSConfig.update({ region: config.get("aws").region});
export const documentClient: DynamoDB.DocumentClient = new DynamoDB.DocumentClient();

/*************
 * logger
 *************/
const loggerFilter = config.get("logger-filter");
export const logger = new Logger(loggerFilter as LoggerFilter);

/*************
 * workshopDao
 * workshopController
 *************/
export const workshopDao = new WorkshopDao(stage, documentClient, config, logger);
export const workshopController = new WorkshopController(stage, workshopDao, config, logger);

/*************
 * userDao
 * userController
 *************/
export const userDao = new UserDao(stage, documentClient, config, logger);
export const userController = new UserController(stage, userDao, config, logger);
