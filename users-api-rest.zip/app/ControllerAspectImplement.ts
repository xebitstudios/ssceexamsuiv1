import {ControllerAspect, Response} from "@aowt/aowt-serverless-common";
import {beforeMethod, Metadata} from "aspect.js";

import configObj = require("./config.json");

/**
 * This class implements AOP on all methods that matches the naming convention below.
 * Aspect.js will intercept method invocations and calls the custom code below, before invoking the actual method
 */
export class ControllerAspectImplement extends ControllerAspect {
    @beforeMethod({
      classNamePattern: /.*Controller$/, // ends with Controller
      methodNamePattern: /^(get|put|post|delete)/, // starts with get|put|post|delete
    })
    public invokeBeforeMethod(meta: Metadata) {
      this.invokeControllerMethod(meta, {configObj}); // common initialization code
    }
}
