import {Config, CustomAuthorizer, Logger} from "@aowt/aowt-serverless-common";
import {Metadata} from "aspect.js";

/**
 * Authorizer for workshop app. Examine the claim in the event and match a list of users in config file
 */
export class UserAdminAuthorizer implements CustomAuthorizer {
  constructor(private config: Config, private logger: Logger) {

  }
  public authorize(event: any, meta: any): Promise<boolean> {
    return Promise.resolve(true)
    .then(() => {
      // first, get the authorizer claim for cognito in the event object
      if (!event || !event.requestContext || !event.requestContext.authorizer || !event.requestContext.authorizer.claims
        || !event.requestContext.authorizer.claims["cognito:username"]) {
        return Promise.reject("Cognito claim not found in event");
      }
      const userInClaim = event.requestContext.authorizer.claims["cognito:username"];

      // then get current method name
      const method = `${meta.className}.${meta.method.name}`;

      // then, get the list of users
      if (!this.config.get("admins")) {
        return Promise.reject("admin users not defined in config file");
      }
      const admins: any = this.config.get("admins");

      // then get a list of methods requiring admin access
      if (!this.config.get("admin-access-required")) {
        return Promise.reject("list of methods requiring admin access not defined in config file");
      }
      const adminAccessRequired = this.config.get("admin-access-required");

      this.logger.debug(`authorize: ${userInClaim} ${method} ${JSON.stringify(admins)} ` +
      `${JSON.stringify(adminAccessRequired)}`);

      // if this method requires admin access but user is not admin, not authorized
      if (adminAccessRequired[method] && (!admins[userInClaim])) {
        this.logger.info(`access denied ${userInClaim}`);
        return Promise.resolve(false);
      }
      this.logger.debug(`access granted ${userInClaim}`);
      return Promise.resolve(true);
    });
  }
}
