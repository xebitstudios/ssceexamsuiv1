import chai = require("chai");
import chaiAsPormised = require("chai-as-promised");
import "mocha";
import sinon = require("sinon");

chai.use(chaiAsPormised);
const assert:any = chai.assert;

import {Config, Logger} from "@aowt/aowt-serverless-common";
import { WorkshopAdminAuthorizer } from "./WorkshopAdminAuthorizer";

describe("WorkshopAdminAuthorizer", () => {
  describe("#authorize()", () => {
    const mockConfig:any = {
      get: sinon.stub(),
    };
    const mockLogger:any = {
      debug: sinon.stub(),
      info: sinon.stub(),
    };
    const adminAuthorizer = new WorkshopAdminAuthorizer(mockConfig, mockLogger);
    it("should return a rejected promise if cognito claim is not included in" +
    " the request context - null event", () => {
      const event = null;
      const meta = {};
      return assert.isRejected(adminAuthorizer.authorize(event, meta), /Cognito claim not found in event/);
    });
    it("should return a rejected promise if cognito claim is not included in " +
    "the request context - null requestContext", () => {
      const event = {
      };
      const meta = {};
      return assert.isRejected(adminAuthorizer.authorize(event, meta), /Cognito claim not found in event/);
    });
    it("should return a rejected promise if cognito claim is not included in " +
    "the request context - null authorizer", () => {
      const event = {
        requestContext: {},
      };
      const meta = {};
      return assert.isRejected(adminAuthorizer.authorize(event, meta), /Cognito claim not found in event/);
    });
    it("should return a rejected promise if cognito claim is not included in " +
    "the request context - null claims", () => {
      const event = {
        requestContext: {
          authorizer: {},
        },
      };
      const meta = {};
      return assert.isRejected(adminAuthorizer.authorize(event, meta), /Cognito claim not found in event/);
    });
    it("should return a rejected promise if cognito claim is not included in " +
    "the request context - null cognito:username", () => {
      const event = {
        requestContext: {
          authorizer: {
            claims: {},
          },
        },
      };
      const meta = {};
      return assert.isRejected(adminAuthorizer.authorize(event, meta), /Cognito claim not found in event/);
    });
    const mockEvent = {
      requestContext: {
        authorizer: {
          claims: {
            "cognito:username" : "foouser",
          },
        },
      },
    };
    it("should return a rejected promise if admin list is not defined in config file", () => {
      const meta = {
        className: "fooClass",
        method: {
          name: "fooMethod",
        },
      };
      mockConfig.get.withArgs("admins").returns(null);
      return assert.isRejected(adminAuthorizer.authorize(mockEvent, meta), /admin users not defined in config file/);
    });
    it("should return a rejected promise if admin list is not defined in config file", () => {
      const meta = {
        className: "fooClass",
        method: {
          name: "fooMethod",
        },
      };
      mockConfig.get.withArgs("admins").returns(["fooAdmin"]);
      mockConfig.get.withArgs("admin-access-required").returns(null);
      return assert.isRejected(adminAuthorizer.authorize(mockEvent, meta),
       /list of methods requiring admin access not defined in config file/);
    });
    it("should return a resolved promise with false value, if admin access is " +
    "required for a method but the user does not have access", () => {
      const meta = {
        className: "fooClass",
        method: {
          name: "fooMethod",
        },
      };
      mockConfig.get.withArgs("admins").returns({fooAdmin: true});
      mockConfig.get.withArgs("admin-access-required").returns({"fooClass.fooMethod": true});
      return assert.eventually.equal(adminAuthorizer.authorize(mockEvent, meta), false)
      .then(() => {
        assert.ok(mockLogger.info.calledOnce, "Access denied is logged as info");
        assert.equal(mockLogger.info.getCall(0).args[0], "access denied foouser");
      });
    });
    it("should return a resolved promise with true value, if admin access is not required", () => {
      const meta = {
        className: "fooClass",
        method: {
          name: "fooMethod",
        },
      };
      mockConfig.get.withArgs("admins").returns({fooAdmin: true});
      mockConfig.get.withArgs("admin-access-required").returns({"fooClass.barMethod": true});
      mockLogger.info.reset();
      return assert.eventually.equal(adminAuthorizer.authorize(mockEvent, meta), true);
    });
    it("should return a resolved promise with true value, if admin access is required and user is admin", () => {
      const meta = {
        className: "fooClass",
        method: {
          name: "fooMethod",
        },
      };
      mockConfig.get.withArgs("admins").returns({foouser: true});
      mockConfig.get.withArgs("admin-access-required").returns({"fooClass.fooMethod": true});
      mockLogger.info.reset();
      return assert.eventually.equal(adminAuthorizer.authorize(mockEvent, meta), true);
    });
  });
});
