import sourcemap = require("source-map-support");
import "./ControllerAspectImplement";
import {userController, workshopController} from "./dependencies";
sourcemap.install();

// tslint:disable-next-line:jsdoc-format
/**workshops handler functions****/
export const getAllWorkshops = (event, context, cb) => {
  workshopController.getAllWorkshops.apply(workshopController, [event, context, cb]);
};
export const putWorkshop = (event, context, cb) => {
  workshopController.putWorkshop.apply(workshopController, [event, context, cb]);
};
export const getWorkshop = (event, context, cb) => {
  workshopController.getWorkshop.apply(workshopController, [event, context, cb]);
};

// tslint:disable-next-line:jsdoc-format
/**users handler functions****/
export const getAllUsers = (event, context, cb) => {
  userController.getAllUsers.apply(userController, [event, context, cb]);
};

export const putUser = (event, context, cb) => {
  userController.putUser.apply(userController, [event, context, cb]);
};
export const getUser = (event, context, cb) => {
  userController.getUser.apply(userController, [event, context, cb]);
};
