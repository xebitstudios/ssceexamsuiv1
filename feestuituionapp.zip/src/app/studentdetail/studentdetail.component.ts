import { Component, OnInit } from '@angular/core';
import { DialogComponent, DialogService } from "ng2-bootstrap-modal";
import { DataService } from '../services/data.service';

export interface StudentDetailModel {
  studentid:number;
  title:string;
  message:string;
}

@Component({
  selector: 'app-studentdetail',
  providers: [DataService],
  templateUrl: './studentdetail.component.html',
  styleUrls: ['./studentdetail.component.css']
})
export class StudentdetailComponent extends DialogComponent<StudentDetailModel, boolean> implements OnInit, StudentDetailModel {
  studentid: number;
  title:string;
  message:string;
  // private currentToken: string = localStorage.getItem('currentToken');

  constructor(dialogService: DialogService, private service: DataService) {
    super(dialogService);
  }

  ngOnInit() {
    this.getStudentDetailById(this.studentid);
  }

  confirm() {
    this.result = true;
    this.close();
  }

  cancel() {
    this.close();
  }

  private getStudentDetailById(studentid: number) {
    return {
      "ischeck": false,
      "firstname": "Hector",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "M",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    };
  }

}
