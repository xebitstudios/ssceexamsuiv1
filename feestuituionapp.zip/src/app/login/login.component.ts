import { Component, OnInit } from '@angular/core';
import { Meta, Title } from "@angular/platform-browser";
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule }  from '@angular/forms';
import { DataService } from '../services/data.service';
import { AuthenticationService } from '../services/authentication.service';
import { ActivatedRoute, Router, Params} from '@angular/router';

// import { Workshop } from '../model/workshop';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers: [DataService, AuthenticationService]
})
export class LoginComponent implements OnInit {

  // public workshops: Workshop[];
  // private currentToken: string= localStorage.getItem('currentToken');

  constructor(private router: Router,
              private dataSvc: DataService,
              private authenticationService: AuthenticationService,
              private route: ActivatedRoute,
              private meta: Meta,
              private title: Title) {

    title.setTitle("Portalworks Fees&Tuition");
    meta.addTags([
      {
        name: 'name', content: 'Portalworks feestuition'
      },
      {
        name: 'keywords', content: 'Portalworks, feestuition'
      },
      {
        name: 'description', content: 'Portalworks feestuition - Staff Records Management System'
      },
      {
        name: 'viewport', content: 'width=device-width, initial-scale=1.0'
      }
    ]);
  }

  ngOnInit() {
  }

  login: any;

  loginForm = new FormGroup({
      username: new FormControl(),
      password: new FormControl()
  });

  submitForm(): void {
    // this.router.navigate(['/detail', this.selectedHero.id]);
    this.router.navigate(['/mainboard']);
  }

}
