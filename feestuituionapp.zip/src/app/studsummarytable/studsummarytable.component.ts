import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-studsummarytable',
  templateUrl: './studsummarytable.component.html',
  styleUrls: ['./studsummarytable.component.css']
})
export class StudsummarytableComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
