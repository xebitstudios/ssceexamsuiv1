import { Component, OnInit } from '@angular/core';
import { DataService } from '../services/data.service';
import { StudentdetailComponent } from '../studentdetail/studentdetail.component';
import { DialogService } from "ng2-bootstrap-modal";
import * as _ from 'underscore';

@Component({
  selector: 'app-stable',
  providers: [DataService],
  templateUrl: './stable.component.html',
  styleUrls: ['./stable.component.css']
})
export class StableComponent implements OnInit {

  pagecount: number = 15;
  pages: number = 0;
  pagelist: any[] = [];
  studentid: number;  
  students: any[] = [
    {
      "ischeck": false,
      "firstname": "Hector 1",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "M",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "M",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "M",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "M",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "F",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "M",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "M",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "M",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "M",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "F",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector 2",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "M",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "M",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "F",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "F",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "M",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "M",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "F",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "M",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "F",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "M",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector 3",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "M",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "M",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "F",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "F",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "M",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "M",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "F",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "M",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "F",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "M",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "F",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector 4",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "M",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "M",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "M",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "M",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "M",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "M",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "M",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "M",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "M",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "M",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "M",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "M",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "M",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "M",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "M",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    },
    {
      "ischeck": false,
      "firstname": "Hector",
      "middlename": "Adrian",
      "lastname": "Morales",
      "gender": "M",
      "status": "Active",
      "entryclass": "01/01/2014",
      "presentclass": "JSS 1",
      "dob": "JSS 3",
      "regdate": "09/25/2003",
      "homeaddress": "802 Adeline Street, Ifako",
      "state": "Lagos"
    }
  ];
  dstudents: any[];

  constructor(private service: DataService,
              private dialogService:DialogService) { }

  ngOnInit() {
    this.pages = Math.floor(this.students.length/this.pagecount) + 1;
    for(var e=0;e<this.pages;e++) {
      if(e==0) { 
        this.pagelist.push({issel: "active", val: e+1});
      } else {
        this.pagelist.push({issel: "", val: e+1});
      }
    }
    this.dstudents = _.first(this.students, this.pagecount);
  }

  showStudentProfile(indx): void {
    console.log("Student with index:" + indx + " clicked!");
    let disposable = this.dialogService.addDialog(StudentdetailComponent, {
                    studentid: this.studentid,
                    title:'Student Detail',
                    message:'Confirm message'})
      .subscribe((isConfirmed)=>{
          //We get dialog result
          if(isConfirmed) {
              //console.log('OK button clicked!');
          }
          else {
              //console.log('Close button clicked!');
          }
      });
  }

  tabbed(vl): void {
    // console.log('vl is:' + vl);
    this.dstudents = [];
    for(var e=(vl*this.pagecount);e<((vl+1)*this.pagecount);e++) {
      if(e>this.students.length - 1){

      } else {
        this.dstudents.push(this.students[e]);
      }
    }
    for(var f=0;f<this.pages;f++)
      if(f == vl) {
        this.pagelist[f].issel = 'active';
      } else {
        this.pagelist[f].issel = '';
      }
  }

}
