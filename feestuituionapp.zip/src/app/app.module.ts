import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { HttpModule } from '@angular/http';
import { RouterModule } from '@angular/router';
import { APP_BASE_HREF } from '@angular/common';
import { BootstrapModalModule } from 'ng2-bootstrap-modal';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { TableComponent } from './table/table.component';
import { TablelistComponent } from './tablelist/tablelist.component';
import { TablelistrowComponent } from './tablelistrow/tablelistrow.component';
import { PievizComponent } from './pieviz/pieviz.component';
import { MalefemaleComponent } from './malefemale/malefemale.component';
import { StudsummarytableComponent } from './studsummarytable/studsummarytable.component';

import { MainboardComponent } from './mainboard/mainboard.component';
import { NewComponent } from './new/new.component';
import { StaffComponent } from './staff/staff.component';
import { ClassComponent } from './class/class.component';
import { ScoresComponent } from './scores/scores.component';
import { ActivityComponent } from './activity/activity.component';
import { SupportComponent } from './support/support.component';
import { LandingComponent } from './landing/landing.component';

import { AppRoutingModule }     from './app-routing.module';
import { ProfilesearchComponent } from './profilesearch/profilesearch.component';
import { SprofiledetailComponent } from './sprofiledetail/sprofiledetail.component';
import { StableComponent } from './stable/stable.component';
import { StudentdetailComponent } from './studentdetail/studentdetail.component';
import { LoginComponent } from './login/login.component';
import { FooterComponent } from './footer/footer.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    TableComponent,
    TablelistComponent,
    TablelistrowComponent,
    PievizComponent,
    MalefemaleComponent,
    StudsummarytableComponent,
    MainboardComponent,
    NewComponent,
    StaffComponent,
    ClassComponent,
    ScoresComponent,
    ActivityComponent,
    SupportComponent,
    LandingComponent,
    ProfilesearchComponent,
    SprofiledetailComponent,
    StableComponent,
    StudentdetailComponent,
    LoginComponent,
    FooterComponent
  ],
  imports: [
    BrowserModule,
    BootstrapModalModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    AppRoutingModule
  ],
  entryComponents: [
    StudentdetailComponent
  ],
  providers: [{provide: APP_BASE_HREF, useValue : '/' }],
  bootstrap: [AppComponent]
})
export class AppModule { }
