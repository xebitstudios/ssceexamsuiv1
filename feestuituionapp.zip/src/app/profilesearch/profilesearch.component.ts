import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profilesearch',
  templateUrl: './profilesearch.component.html',
  styleUrls: ['./profilesearch.component.css']
})
export class ProfilesearchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
