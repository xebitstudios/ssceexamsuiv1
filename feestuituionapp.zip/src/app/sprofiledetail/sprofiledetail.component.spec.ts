import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SprofiledetailComponent } from './sprofiledetail.component';

describe('SprofiledetailComponent', () => {
  let component: SprofiledetailComponent;
  let fixture: ComponentFixture<SprofiledetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SprofiledetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SprofiledetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
