import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sprofiledetail',
  templateUrl: './sprofiledetail.component.html',
  styleUrls: ['./sprofiledetail.component.css']
})
export class SprofiledetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
