import { StudentproappPage } from './app.po';

describe('studentproapp App', () => {
  let page: StudentproappPage;

  beforeEach(() => {
    page = new StudentproappPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!');
  });
});
